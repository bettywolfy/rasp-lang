import { NodeKind } from "./parser.js";
import { global_scope as svm_global_scope } from "../vm/main.js";
import * as path from "jsr:@std/path";

class Scope {
  syms = new Map();
  constructor(parent = null, can_break = null, can_return = null) {
    this.parent = parent;
    if(can_break===null) {
      if(parent) can_break = parent.can_break;
      else can_break = false;
    }
    this.can_break = can_break;
    if(can_return===null) {
      if(parent) can_return = parent.can_return;
      else can_return = false;
    }
    this.can_return = can_return;
  }
  declare(name, meta) {
    if(this.syms.has(name)) {
      throw new SyntaxError(`redefinition of '${name}' is not allowed!`);
    }
    this.syms.set(name, meta);
  }
  init(name) {
    if(this.syms.has(name)) {
      const val = this.syms.get(name);
      val.is_init = true;
      return val;
    }
    if(this.parent) {
      return this.parent.init(name);
    }
    throw new ReferenceError(`'${name}' is not defined`);
  }
  lookup(name) {
    if(this.syms.has(name)) {
      const val = this.syms.get(name);
      if(!val.is_init) {
        throw new ReferenceError(`use of '${name}' before it's initialization is not allowed!`);
      }
      return val;
    }
    if(this.parent) return this.parent.lookup(name);
    throw new ReferenceError(`'${name}' is not defined`);
    /*const val = { is_init: true, is_const: true };
    this.syms.set(name, val);
    return val;*/
  }
}

function recursiveFind(node, kind) {
  if(typeof kind==="function" && kind(node)) return node;
  if(node.kind===kind) return node;
  switch(node.kind) {
    case NodeKind.Program: {
      for(const stmt of node.body) {
        const found = recursiveFind(stmt, kind);
        if(found) return found;
      }
      return false;
    }
    case NodeKind.Export: {
      return recursiveFind(node.stmt, kind);
    }
    case NodeKind.BlockStmt:
    case NodeKind.Block: {
      for(const stmt of node.stmts) {
        const found = recursiveFind(stmt, kind);
        if(found) return found;
      }
      return false;
    }
    case NodeKind.IfStmt: {
      const res = recursiveFind(node.body, kind);
      if(res) return res;
      if(node.alt) return recursiveFind(node.alt, kind);
      return false;
    }
    case NodeKind.ForStmt:
    case NodeKind.ElseStmt:
    case NodeKind.WhileStmt:
    case NodeKind.FunctionDef:
    case NodeKind.Lambda: {
      if(node.is_native) return false;
      return recursiveFind(node.body, kind);
    }
    default:
      return false;
  }
}

function analyzeDec(node, scope) {
  switch(node.kind) {
    case NodeKind.VarDef: {
      for(const def of node.defs) {
        scope.declare(def.name, {
          is_init: false,
          is_const: node.is_const
        });
      }
      break;
    }
    case NodeKind.EnumDef: {
      const stored = new Set();
      for(const name of node.names) {
        if(stored.has(name)) {
          throw new SyntaxError("each enum value should be unique");
        }
        stored.add(name);
      }
      scope.declare(node.name, { is_init: false, is_const: true });
      break;
    }
    case NodeKind.Native: {
      scope.declare(node.name, { is_init: true, is_const: true });
      break;
    }
    case NodeKind.Import: {
      if(node.all) {
        scope.declare(node.name, { is_init: true, is_const: true });
      } else {
        for(const name of node.names) {
          scope.declare(name, { is_init: true, is_const: true });
        }
      }
      break;
    }
    case NodeKind.FunctionDef: {
      scope.declare(node.name, {
        is_init: false,
        is_const: true
      });
      break;
    }
  }
}

function analyzeBody(node, scope) {
  switch(node.kind) {
    case NodeKind.FunctionDef: {
      if(node.is_native) break;
      const fscope = new Scope(scope, false, true);
      for(const param of node.params) {
        fscope.declare(param, { is_init: true, is_const: false });
      }
      fscope.declare("self", { is_init: true, is_const: false });
      fscope.declare("arguments", { is_init: true, is_const: false });
      analyze(node.body, fscope);
      break;
    }
  }
}

function analyze(node, scope) {
  switch(node.kind) {
    case NodeKind.Export: {
      analyzeDec(node.stmt, scope);
      analyze(node.stmt, scope);
      analyzeBody(node.stmt, scope);
      break;
    }
    case NodeKind.Program: {
      for(const stmt of node.body) {
        analyzeDec(stmt, scope);
      }
      for(const stmt of node.body) {
        analyze(stmt, scope);
      }
      for(const stmt of node.body) {
        analyzeBody(stmt, scope);
      }
      break;
    }
    
    case NodeKind.TemplateString: {
      for(const expr of node.exprs) {
        analyze(expr, scope);
      }
      break;
    }
    case NodeKind.NumberLiteral:
    case NodeKind.BoolLiteral: {
      break;
    }
    case NodeKind.BinaryExpr: {
      analyze(node.left, scope);
      analyze(node.right, scope);
      break;
    }
    case NodeKind.MemberExpr: {
      analyze(node.object, scope);
      break;
    }
    case NodeKind.IndexExpr: {
      analyze(node.object, scope);
      analyze(node.property, scope);
      break;
    }
    case NodeKind.Identifier: {
      const val = scope.lookup(node.name);
      break;
    }
    case NodeKind.CallExpr:
    case NodeKind.New:
    case NodeKind.AtExpr: {
      analyze(node.callee, scope);
      for(const arg of node.args) {
        analyze(arg, scope);
      }
      break;
    }
    case NodeKind.ArrayExpr: {
      for(const item of node.items) {
        analyze(item, scope);
      }
      break;
    }
    
    case NodeKind.EnumDef: {
      scope.init(node.name);
      break;
    }
    case NodeKind.ExprStmt: {
      analyze(node.expr, scope);
      break;
    }
    case NodeKind.ReturnStmt: {
      if(!scope.can_return) {
        throw new SyntaxError("illegal return-statement");
      }
      if(!node.value) break;
      analyze(node.value, scope);
      break;
    }
    case NodeKind.Break: {
      if(!scope.can_break) {
        throw new SyntaxError("illegal break-statement");
      }
      break;
    }
    case NodeKind.Continue: {
      if(!scope.can_break) {
        throw new SyntaxError("illegal continue-statement");
      }
      break;
    }
    case NodeKind.ElseStmt: {
      analyze(node.body, scope);
      break;
    }
    case NodeKind.BlockStmt:
    case NodeKind.Block: {
      if(node.kind===NodeKind.BlockStmt) {
        scope = new Scope(scope);
      }
      for(const stmt of node.stmts) {
        analyzeDec(stmt, scope);
      }
      for(const stmt of node.stmts) {
        analyze(stmt, scope);
      }
      for(const stmt of node.stmts) {
        analyzeBody(stmt, scope);
      }
      break;
    }
    case NodeKind.IfStmt: {
      analyze(node.condition, scope);
      analyze(node.body, new Scope(scope));
      if(node.alt) {
        analyze(node.alt, new Scope(scope));
      }
      break;
    }
    case NodeKind.WhileStmt: {
      analyze(node.condition, scope);
      const wscope = new Scope(scope, true);
      analyze(node.body, wscope);
      break;
    }
    case NodeKind.ForStmt: {
      analyze(node.cycles, scope);
      if(node.step) analyze(node.step, scope);
      if(node.iota) analyze(node.iota, scope);
      const fscope =  new Scope(scope, true);
      fscope.declare(node.counter, { is_init: true, is_const: true });
      analyze(node.body, fscope);
      break;
    }
    case NodeKind.VarAssign: {
      analyze(node.left, scope);
      analyze(node.right, scope);
      if(node.left.kind===NodeKind.Identifier) {
        const left = scope.lookup(node.left.name);
        if(left.is_const) {
          throw new TypeError(`assignment to constant '${node.left.name}' is not allowed!`);
        }
      }
      break;
    }
    case NodeKind.VarDef: {
      for(const def of node.defs) {
        analyze(def.init, scope);
        scope.init(def.name);
      }
      break;
    }
    case NodeKind.Lambda:
    case NodeKind.FunctionDef: {
      if(node.kind===NodeKind.FunctionDef) {
        scope.init(node.name);
      }
      /*if(node.is_native) break;
      if(node.is_void) {
        const returns = recursiveFind(
          node.body,
          a => (a.kind===NodeKind.ReturnStmt && a.value!==null)
        );
        if(returns) {
          throw new TypeError(
            ((node.kind===NodeKind.Lambda)
              ? "lambda function"
              : `function '${node.name}'`
            )+` is of type void and must not return a value`
          );
        }
      } else {
        let flagged = true;
        
        let returns = recursiveFind(
          node.body,
          a => (a.kind===NodeKind.ReturnStmt && a.value===null)
        );
        if(!returns) {
          flagged = false;
        }
        
        if(!flagged) {
          // stills need to check toplevel of function
          flagged = true;
          if(node.body.kind===NodeKind.Block) {
            for(const stmt of node.body.stmts) {
              if(stmt.kind===NodeKind.ReturnStmt) {
                flagged = stmt.value===null;
                break;
              }
            }
          } else {
            flagged = (
              node.body.kind!==NodeKind.ReturnStmt ||
              node.body.value===null
            );
          }
        }
        
        if(flagged) {
          throw new TypeError(
            ((node.kind===NodeKind.Lambda)
              ? "lambda function"
              : `function '${node.name}'`
            )+` is not of type void and must return a value`
          );
        }
      }*/
      break;
    }
  }
}

const global_scope = new Scope();

export function analyzeAST(program) {
  const scope = new Scope(global_scope);
  for(const name of svm_global_scope.syms.keys()) {
    scope.declare(name, {
      is_init: true,
      is_const: svm_global_scope.consts.has(name)
    });
  }
  analyze(program, scope);
}
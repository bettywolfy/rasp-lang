export const TokenKind = {
  String: "string",
  TemplateString: "template string",
  RegexLiteral: "regular expression",
  Number: "number",
  Identifier: "identifier",
  Bool: "boolean",
  Nil: "nil",
  NaN: "nan",
  // Void: "void",
  
  At: "@",
  
  Star: "*", Slash: "/", Modulo: "%",
  DoubleSlash: "//", Caret: "^",
  Plus: "+", Dash: "-", Concat: "..",
  Hash: "#",
  
  LessThan: "<", GreaterThan: ">",
  LessThanEqual: "<=", GreaterThanEqual: ">=",
  Equal: "==", NotEqual: "!=",
  
  LogicalAnd: "&&", LogicalOr: "||",
  
  LeftParen: "(",
  RightParen: ")",
  LeftBrace: "{",
  RightBrace: "}",
  LeftBracket: "[",
  RightBracket: "]",
  Semicolon: ";",
  Question: "?",
  Colon: ":",
  Path: "::",
  Bang: "!",
  Tilde: "~",
  Dot: ".",
  Comma: ",",
  
  Assign: "=",
  AssignAdd: "+=",
  AssignSub: "-=",
  AssignMul: "*=",
  AssignDiv: "/=",
  AssignIDiv: "//=",
  AssignMod: "%=",
  AssignCon: "..=",
  
  Native: "native",
  Import: "import",
  Export: "export",
  Function: "fun",
  Var: "var",
  For: "for",
  While: "while",
  If: "if",
  Elif: "elif",
  Else: "else",
  Return: "return",
  Break: "break",
  Continue: "continue",
  Enum: "enum",
};

const lexer_symbols = [
  ["@", TokenKind.At],
  
  ["+", TokenKind.Plus],
  ["-", TokenKind.Dash],
  ["*", TokenKind.Star],
  ["/", TokenKind.Slash],
  ["%", TokenKind.Modulo],
  ["//", TokenKind.DoubleSlash],
  ["^", TokenKind.Caret],
  ["..", TokenKind.Concat],
  ["#", TokenKind.Hash],
  
  ["<", TokenKind.LessThan],
  ["<=", TokenKind.LessThanEqual],
  [">", TokenKind.GreaterThan],
  [">=", TokenKind.GreaterThanEqual],
  ["==", TokenKind.Equal],
  ["!=", TokenKind.NotEqual],
  
  ["&&", TokenKind.LogicalAnd],
  ["||", TokenKind.LogicalOr],
  
  ["(", TokenKind.LeftParen],
  [")", TokenKind.RightParen],
  ["{", TokenKind.LeftBrace],
  ["}", TokenKind.RightBrace],
  ["[", TokenKind.LeftBracket],
  ["]", TokenKind.RightBracket],
  [";", TokenKind.Semicolon],
  [":", TokenKind.Colon],
  ["::", TokenKind.Path],
  ["?", TokenKind.Question],
  ["!", TokenKind.Bang],
  ["~", TokenKind.Tilde],
  [".", TokenKind.Dot],
  [",", TokenKind.Comma],
  
  ["=", TokenKind.Assign],
  ["+=", TokenKind.AssignAdd],
  ["-=", TokenKind.AssignSub],
  ["*=", TokenKind.AssignMul],
  ["/=", TokenKind.AssignDiv],
  ["//=", TokenKind.AssignIDiv],
  ["%=", TokenKind.AssignMod],
  ["..=", TokenKind.AssignCon],
].toSorted((i, j) => j[0].length-i[0].length);

const reserved_names = new Map([
  ["native", TokenKind.Native],
  ["import", TokenKind.Import],
  ["export", TokenKind.Export],
  ["fun", TokenKind.Function],
  ["var", TokenKind.Var],
  ["for", TokenKind.For],
  ["while", TokenKind.While],
  ["if", TokenKind.If],
  ["elif", TokenKind.Elif],
  ["else", TokenKind.Else],
  // ["void", TokenKind.Void],
  ["return", TokenKind.Return],
  ["break", TokenKind.Break],
  ["continue", TokenKind.Continue],
  ["enum", TokenKind.Enum],
  ["nil", TokenKind.Nil],
  ["nan", TokenKind.NaN],
]);

// Lexer
export class Lexer {
  error_at(msg, idx) {
    let col = 0, row = 1;
    for(let i = 0; i<=idx; ++i) {
      if(this.text[i]==="\n") {
        col = 0;
        ++row;
      } else {
        ++col;
      }
    }
    --col;
    throw new SyntaxError(`${row}:${col} → ${msg}`);
  }
  ended() {
    return this.idx>=this.text.length;
  }
  is_at(code) {
    return this.text.slice(this.idx, this.idx+code.length)==code;
  }
  consumeIgnorable() {
    if(/\s/.test(this.text[this.idx])) {
      while(!this.ended() && /\s/.test(this.text[this.idx])) ++this.idx;
      return true;
    }
    
    if(this.is_at("---")) {
      let start = this.idx;
      this.idx += 3;
      while(!this.ended() && !this.is_at("\n")) {
        ++this.idx;
      }
      this.comments.push({
        value: this.text.slice(start+3, this.idx),
        raw: this.text.slice(start, this.idx),
        start, end: this.idx
      });
      return true;
    }
    if(this.is_at("-*")) {
      let start = this.idx, depth = 1;
      this.idx += 2;
      while(!this.ended() && depth) {
        if(this.is_at("*-")) ++this.idx, --depth;
        else if(this.is_at("-*")) ++this.idx, ++depth;
        ++this.idx;
      }
      if(depth) {
        this.error_at(
          "multiline comment didn't found a closing pair",
          start
        );
      }
      this.comments.push({
        value: this.text.slice(start+2, this.idx-2),
        raw: this.text.slice(start, this.idx),
        start, end: this.idx
      });
      return true;
    }
    return false;
  }
  // TODO: a better way to handle bases
  consumeNumbers() {
    // binary
    if(this.is_at("0b")) {
      const start = this.idx;
      this.idx += 2;
      let is_float = false;
      while(!this.ended() && /[01]/.test(this.text[this.idx])) {
        ++this.idx;
      }
      if(this.is_at(".")) {
        is_float = true;
        ++this.idx;
        while(!this.ended() && /[01]/.test(this.text[this.idx])) {
          ++this.idx;
        }
      }
      if(this.is_at("f")) {
        is_float = true;
        ++this.idx;
      }
      if(!this.ended() && /[\p{ID_Start}_$]/u.test(this.text[this.idx])) {
        this.error_at(
          "identifier is too close to number",
          start
        );
      }
      const raw = this.text.slice(start+2, this.idx);
      if(raw==="") {
        this.error_at("expected characters after number base prefix → 0b", start);
      }
      
      let dec = raw.indexOf(".");
      dec = (dec===-1) ? 0 : (raw.length-1-dec);
      dec = 2**dec;
      const value = parseInt(raw.replace(".", ""), 2)/dec;
      
      this.tokens.push({
        kind: TokenKind.Number,
        start, end: this.idx,
        raw: ("0b"+raw), value,
        is_float
      });
      return true;
    }
    // octo
    if(this.is_at("0o")) {
      const start = this.idx;
      this.idx += 2;
      let is_float = false;
      while(!this.ended() && /[0-7]/.test(this.text[this.idx])) {
        ++this.idx;
      }
      if(this.is_at(".")) {
        is_float = true;
        ++this.idx;
        while(!this.ended() && /[0-7]/.test(this.text[this.idx])) {
          ++this.idx;
        }
      }
      if(this.is_at("f")) {
        is_float = true;
        ++this.idx;
      }
      if(!this.ended() && /[\p{ID_Start}_$]/u.test(this.text[this.idx])) {
        this.error_at(
          "identifier is too close to number",
          start
        );
      }
      const raw = this.text.slice(start+2, this.idx);
      if(raw==="") {
        this.error_at("expected characters after number base prefix → 0o", start);
      }
      
      let dec = raw.indexOf(".");
      dec = (dec===-1) ? 0 : (raw.length-1-dec);
      dec = 8**dec;
      const value = parseInt(raw.replace(".", ""), 8)/dec;
      
      this.tokens.push({
        kind: TokenKind.Number,
        start, end: this.idx,
        raw: ("0o"+raw), value,
        is_float
      });
      return true;
    }
    // hexa
    if(this.is_at("0x")) {
      const start = this.idx;
      this.idx += 2;
      let is_float = false;
      while(!this.ended() && /[0-9a-zA-Z]/.test(this.text[this.idx])) {
        ++this.idx;
      }
      if(this.is_at(".")) {
        is_float = true;
        ++this.idx;
        while(!this.ended() && /[0-9a-zA-Z]/.test(this.text[this.idx])) {
          ++this.idx;
        }
      }
      if(this.is_at(".f")) {
        is_float = true;
        this.idx += 2;
      }
      if(!this.ended() && /[\p{ID_Start}_$]/u.test(this.text[this.idx])) {
        this.error_at(
          "identifier is too close to number",
            start
        );
      }
      const raw = this.text.slice(start+2, this.idx);
      if(raw==="") {
        this.error_at("expected characters after number base prefix → 0x", start);
      }
      let dec = raw.indexOf(".");
      dec = (dec===-1) ? 0 : (raw.length-1-dec);
      dec = 16**dec;
      const value = parseInt(raw.replace(".", ""), 16)/dec;
      
      this.tokens.push({
        kind: TokenKind.Number,
        start, end: this.idx,
        raw: ("0x"+raw), value,
        is_float
      });
      return true;
    }
    // decimal
    
    if(
      /[0-9]/.test(this.text[this.idx])
      || (
        this.is_at(".")
        && (this.text.length<1
        || /[0-9]/.test(this.text[this.idx+1]))
      )
    ) {
      const start = this.idx;
      
      let is_float = false;
      while(!this.ended() && /[0-9]/.test(this.text[this.idx])) {
        ++this.idx;
      }
      if(this.is_at(".")) {
        is_float = true;
        ++this.idx;
        while(!this.ended() && /[0-9]/.test(this.text[this.idx])) {
          ++this.idx;
        }
      }
      
      if(this.is_at("e")) {
        ++this.idx;
        if(!this.is_at("+") && !this.is_at("-")) {
          this.error_at(
            "expected exponential sign",
            start
          );
        }
        ++this.idx;
        if(this.ended() || !/[0-9]/.test(this.text[this.idx])) {
          this.error_at(
            "expected exponential value",
            start
          );
        }
        while(!this.ended() && /[0-9]/.test(this.text[this.idx])) ++this.idx; 
      }
      
      if(this.is_at("f")) {
        is_float = true;
        ++this.idx;
      }
      
      if(!this.ended() && /[\p{ID_Start}_]/u.test(this.text[this.idx])) {
        this.error_at(
          "identifier is too close to number",
          start
        );
      }
      const raw = this.text.slice(start, this.idx);
      const value = parseFloat(raw);
      this.tokens.push({
        kind: TokenKind.Number,
        start, end: this.idx,
        raw, value, is_float
      });
      return true;
    }
    return false;
  }
  consumeStrings() {
    if(this.is_at("`")) {
      let start = this.idx++;
      let value = "", is_head = true;
      while(!this.ended() && !this.is_at("`")) {
        if(this.is_at("\\")) {
          ++this.idx;
          if(this.ended()) {
            this.error_at(
              "string didn't found a character after backslash escape",
              start
            );
          }
          const esc = this.text[this.idx++];
          switch(esc) {
            case "t": { value += "\t"; break; }
            case "r": { value += "\r"; break; }
            case "n": { value += "\n"; break; }
            case "b": { value += "\b"; break; }
            case "e": { value += "\x1b"; break; }
            case "0": { value += "\0"; break; }
            case "\\": { value += "\\"; break; }
            case "`": { value += "`"; break; }
            
            case "{": {
              this.tokens.push({
                kind: TokenKind.TemplateString,
                raw: this.text.slice(start, this.idx-2),
                start, end: this.idx-2,
                value, is_head, is_tail: false
              });
              start = this.idx;
              is_head = false;
              value = "";
              while(!this.ended() && !this.is_at("}")) {
                this.consumeNext();
              }
              if(!this.is_at("}")) {
                this.error_at(
                  "template string expression must end with a right brace",
                  start
                );
              }
              ++this.idx;
              break;
            }
            
            case "u": {
              if(this.ended()) {
                this.error_at(
                  "string didn't found a character after unicode escape",
                  start
                );
              }
              let cdp = "";
              while(!this.ended() && /[0-9a-fA-F]/.test(this.text[this.idx])) {
                cdp += this.text[this.idx++];
                if(this.is_at(";")) {
                  ++this.idx;
                  break;
                }
              }
              value += String.fromCodePoint(parseInt(cdp, 16));
              break;
            }
            
            case "x": {
              if(this.idx+2>this.text.length) {
                this.error_at(
                  "string didn't found enough characters after hexadecimal escape",
                  start
                );
              }
              const code = this.text.slice(this.idx, this.idx += 2);
              const val = parseInt(code, 16);
              if(Number.isNaN(val)) {
                this.error_at(`'${code}' is not a valid hexadecimal number`, start);
              }
              value += String.fromCodePoint(val);
              break;
            }
            
            default:
              this.error_at(`'\\${esc}' is not a invalid character escape sequence`, this.idx);
          }
          continue;
        }
        value += this.text[this.idx++];
      }
      if(!this.is_at("`")) {
        this.error_at(
          "string didn't found a closing pair",
          start
        );
      }
      this.tokens.push({
        kind: TokenKind.TemplateString,
        is_head,
        is_tail: true,
        value, raw: this.text.slice(start, ++this.idx),
        start, end: this.idx
      });
      return true;
    }
    if(this.is_at('"')) {
      const start = this.idx++;
      let value = "";
      while(!this.ended() && !this.is_at('"')) {
        if(this.is_at('\\"') || this.is_at("\\\\")) {
          value += this.text[++this.idx];
          ++this.idx;
          continue;
        }
        value += this.text[this.idx++];
      }
      if(!this.is_at('"')) {
        this.error_at(
          "string didn't found a closing pair",
          start
        );
      }
      ++this.idx;
      this.tokens.push({
        kind: TokenKind.String,
        raw: this.text.slice(start, this.idx),
        value,
        start, end: this.idx
      });
      return true;
    }
    return false;
  }
  consumeIdentifier() {
    if(/[\p{ID_Start}_$]/u.test(this.text[this.idx])) {
      const start = this.idx;
      while(!this.ended() && /[\p{ID_Continue}$]/u.test(this.text[this.idx])) {
        ++this.idx;
      }
      const raw = this.text.slice(start, this.idx);
      if(raw==="true" || raw==="false") {
        this.tokens.push({
          kind: TokenKind.Bool,
          value: raw==="true",
          start, end: this.idx,
          raw
        });
        return true; 
      }
      
      const kind = reserved_names.get(raw)
        ?? TokenKind.Identifier;
      
      const tok = {
        kind,
        start, end: this.idx,
        raw
      };
      if(kind===TokenKind.Identifier) {
        tok.name = raw;
      }
      
      this.tokens.push(tok);
      return true;
    }
    return false;
  }
  consumeSymbols() {
    if(this.is_at("+/")) {
      let start = this.idx;
      this.idx += 2;
      while(!this.ended() && !this.is_at("/")) {
        if(this.is_at("\\")) {
          ++this.idx;
          if(this.ended()) {
            this.error_at("expected character after regular expression escape", this.idx);
          }
        }
        ++this.idx;
      }
      if(!this.is_at("/")) {
        this.error_at("regular expression didn't found closing pair", start);
      }
      const pattern = this.text.slice(start+2, this.idx++);
      let flags = "";
      while(!this.ended() && /[a-zA-Z]/.test(this.text[this.idx])) {
        flags += this.text[this.idx++];
      }
      this.tokens.push({
        kind: TokenKind.RegexLiteral,
        pattern, flags,
        raw: this.text.slice(start, this.idx),
        start, end: this.idx
      });
      return true;
    }
    
    for(const [raw, kind] of lexer_symbols) {
      if(!this.is_at(raw)) continue;
      this.tokens.push({
        kind, raw,
        start: this.idx,
        end: (this.idx += raw.length)
      });
      return true;
    }
    return false;
  }
  consumeNext() {
    if(this.consumeIgnorable()) return;
    if(this.consumeNumbers()) return;
    if(this.consumeStrings()) return;
    if(this.consumeIdentifier()) return;
    if(this.consumeSymbols()) return;
    
    this.error_at(`the character '${this.text[this.idx]}' was not expected to be read on the input.`, this.idx);
  }
  
  lex(input) {
    this.text = input;
    this.idx = 0;
    this.tokens = [];
    this.comments = [];
    while(!this.ended()) {
      this.consumeNext();
    }
    return [this.tokens, this.comments];
  }
}
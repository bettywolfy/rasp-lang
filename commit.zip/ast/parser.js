import { Lexer, TokenKind } from "./lexer.js";

export const NodeKind = {
  Import: "import",
  Export: "export",
  New: "new",
  
  Program: "program",
  NumberLiteral: "number literal",
  StringLiteral: "string literal",
  RegexLiteral: "regular expression literal",
  TemplateString: "template string",
  BoolLiteral: "boolean literal",
  NilLiteral: "nil literal",
  NaNLiteral: "nan literal",
  Identifier: "identifier",
  
  Ternary: "ternary expression",
  BinaryExpr: "binary expression",
  UnaryExpr: "unary expression",
  MemberExpr: "member expression",
  IndexExpr: "index expression",
  CallExpr: "call expression",
  ArrayExpr: "array expression",
  ObjectExpr: "object expression",
  
  ExprStmt: "expression statement",
  FunctionDef: "function definition",
  Lambda: "lambda function",
  VarDef: "variable definition",
  VarAssign: "variable assignment",
  ForStmt: "for-statement",
  IfStmt: "if-statement",
  ElseStmt: "else-statement",
  WhileStmt: "while-statement",
  Block: "block",
  BlockStmt: "block statement",
  ReturnStmt: "return-statement",
  Break: "break-statement",
  Continue: "continue-statement",
  EnumDef: "enumerator definition",
};

export class Parser {
  is_at(kind, la=0) {
    return this.tokens[la]?.kind===kind;
  }
  ended() {
    return !this.tokens.length;
  }
  consume() {
    return this.tokens.shift();
  }
  consume_if_at(kind) {
    if(this.is_at(kind)) {
      return this.consume();
    }
    return false;
  }
  expect(kind, msg) {
    if(this.ended()) {
      this.error_at(
        (msg ? msg : `expecting ${kind}`)
          + " → found the end of input instead",
        this.text.length-1
      );
    }
    const next = this.consume();
    if(next.kind!==kind) {
      this.error_at(
        (msg ? msg : `expecting a ${kind}`)
          + ` → found ${next.raw} instead`,
        next.start
      );
    }
    return next;
  }
  
  parse_primary_call() {
    if(this.ended()) {
      this.error_at(`not expecting the end of input right now`, this.text.length-1);
    }
    if(this.is_at(TokenKind.Function)) {
      return this.parse_lambda_expr();
    }
    const next = this.consume();
    switch(next.kind) {
      case TokenKind.Identifier: {
        return {
          kind: NodeKind.Identifier,
          name: next.name,
          start: next.start,
          end: next.end
        };
      }
      case TokenKind.Bool: {
        return {
          kind: NodeKind.BoolLiteral,
          value: next.value,
          start: next.start,
          end: next.end
        };
      }
      case TokenKind.Nil: {
        return {
          kind: NodeKind.NilLiteral,
          start: next.start,
          end: next.end
        };
      }
      case TokenKind.NaN: {
        return {
          kind: NodeKind.NaNLiteral,
          start: next.start,
          end: next.end
        };
      }
      case TokenKind.Number: {
        return {
          kind: NodeKind.NumberLiteral,
          value: next.value,
          raw: next.raw,
          start: next.start,
          end: next.end,
          is_float: next.is_float
        };
      }
      case TokenKind.String: {
        return {
          kind: NodeKind.StringLiteral,
          value: next.value,
          raw: next.raw,
          start: next.start,
          end: next.end
        };
      }
      case TokenKind.TemplateString: {
        const quasis = [next.value], exprs = [];
        if(!next.is_tail) {
          while(!this.ended()) {
            exprs.push(this.parse_expr());
            
            const next = this.expect(TokenKind.TemplateString);
            quasis.push(next.value);
            if(next.is_tail) break;
          }
        }
        return {
          kind: NodeKind.TemplateString,
          quasis, exprs,
          start: next.start,
          end: next.end
        };
      }
      case TokenKind.LeftParen: {
        const expr = this.parse_expr();
        this.expect(TokenKind.RightParen, "expected a closing pair for parenthesis");
        return expr;
      }
      case TokenKind.Dash:
      case TokenKind.Hash:
      case TokenKind.Bang:
      {
        const expr = this.parse_member_call_expr();
        return {
          kind: NodeKind.UnaryExpr,
          expr, op: next.raw,
          start: next.start, end: expr.end
        };
      }
      case TokenKind.LeftBracket: {
        const items = [];
        while(!this.ended() && !this.is_at(TokenKind.RightBracket)) {
          const expr = this.parse_expr();
          items.push(expr);
          this.consume_if_at(TokenKind.Comma);
        }
        const end = this.expect(TokenKind.RightBracket, "you need to close the array expression").end;
        return {
          kind: NodeKind.ArrayExpr,
          items,
          start: next.start, end
        };
      }
      case TokenKind.LeftBrace: {
        const entries = [];
        while(!this.ended() && !this.is_at(TokenKind.RightBrace)) {
          const key = this.expect(TokenKind.Identifier);
          
          let value;
          if(
            this.is_at(TokenKind.Comma)
            || this.is_at(TokenKind.RightBrace)
          ) {
            value = key;
          } else {
            this.consume_if_at(TokenKind.Colon);
            value = this.parse_expr();
          }
          entries.push({ key: key.name, value });
          this.consume_if_at(TokenKind.Comma);
        }
        const end = this.expect(TokenKind.RightBrace, "you need to close the object expression").end;
        return {
          kind: NodeKind.ObjectExpr,
          entries,
          start: next.start, end
        };
      }
      case TokenKind.RegexLiteral: {
        const regex = new RegExp(next.pattern, next.flags);
        return {
          kind: NodeKind.RegexLiteral,
          regex,
          start: next.start, end: next.end
        }
      }
      default:
        this.error_at(`not expecting '${next.raw}' to be here`, next.start);
    }
  }
  at_valid_member_call(ls = 0) {
    return this.is_at(TokenKind.Dot, ls)
    || this.is_at(TokenKind.LeftBracket, ls)
    || this.is_at(TokenKind.Bang, ls)
    || this.is_at(TokenKind.LeftParen, ls);
  }
  parse_member_call_expr(c = false) {
    let first;
    if(c && this.is_at(TokenKind.At)) {
      const start = this.consume().start;
      
      const callee = this.parse_member_call_expr(true);
      
      this.expect(
        TokenKind.LeftParen,
        "call expression must start with a left parenthesis"
      ).end;
      
      const args = [];
      while(!this.ended() && !this.is_at(TokenKind.RightParen)) {
        args.push(this.parse_expr());
        this.consume_if_at(TokenKind.Comma);
      }
      
      const end = this.expect(
        TokenKind.RightParen,
        "call expression must end with a right parenthesis"
      ).end;
      
      first = {
        kind: NodeKind.New,
        callee, args,
        start, end
      };
    } else {
      first = this.parse_primary_call();
    }
    
    while(this.at_valid_member_call()) {
      if(this.consume_if_at(TokenKind.Dot)) {
        let property = this.expect(
          TokenKind.Identifier,
          "member field name must be an identifier"
        );
        const end = property.end;
        property = property.name;
        first = {
          kind: NodeKind.MemberExpr,
          object: first,
          property,
          start: first.start, end
        };
        continue;
      }
      if(this.consume_if_at(TokenKind.LeftBracket)) {
        const property = this.parse_expr();
        const end = this.expect(
          TokenKind.RightBracket,
          "member indexing must end with a right bracket"
        ).end;
        first = {
          kind: NodeKind.IndexExpr,
          object: first,
          property,
          start: first.start, end
        };
        continue;
      }
      
      if(c) return first;
      
      if(this.is_at(TokenKind.Bang)) {
        const end = this.consume().end;
        first = {
          kind: NodeKind.CallExpr,
          callee: first, args: [],
          start: first.start, end
        };
        continue;
      }
      this.consume();
      
      const args = [];
      while(!this.ended() && !this.is_at(TokenKind.RightParen)) {
        args.push(this.parse_expr());
        this.consume_if_at(TokenKind.Comma);
      }
      const end = this.expect(
        TokenKind.RightParen,
        "call expression must end with a right parenthesis"
      ).end;
      
      first = {
        kind: NodeKind.CallExpr,
        callee: first, args,
        start: first.start, end,
      };
    }
    return first;
  }
  parse_expo_expr() {
    let left = this.parse_member_call_expr();
    while(
      this.is_at(TokenKind.Caret)
    ) {
      const op = this.consume().raw;
      const right = this.parse_member_call_expr();
      left = {
        kind: NodeKind.BinaryExpr,
        left, op, right,
        start: left.start,
        end: right.end
      };
    }
    return left;
  }
  parse_mult_expr() {
    let left = this.parse_expo_expr();
    while(
      this.is_at(TokenKind.Star)
      || this.is_at(TokenKind.Slash)
      || this.is_at(TokenKind.Modulo)
      || this.is_at(TokenKind.DoubleSlash)
    ) {
      const op = this.consume().raw;
      const right = this.parse_expo_expr();
      left = {
        kind: NodeKind.BinaryExpr,
        left, op, right,
        start: left.start,
        end: right.end
      };
    }
    return left;
  }
  parse_add_expr() {
    let left = this.parse_mult_expr();
    while(
      this.is_at(TokenKind.Plus) ||
      this.is_at(TokenKind.Dash)
    ) {
      const op = this.consume().raw;
      const right = this.parse_mult_expr();
      left = {
        kind: NodeKind.BinaryExpr,
        left, op, right,
        start: left.start,
        end: right.end
      };
    }
    return left;
  }
  parse_comp_expr() {
    let left = this.parse_add_expr();
    while(
      this.is_at(TokenKind.GreaterThan) ||
      this.is_at(TokenKind.GreaterThanEqual) ||
      this.is_at(TokenKind.LessThan) ||
      this.is_at(TokenKind.LessThanEqual) ||
      this.is_at(TokenKind.Equal) ||
      this.is_at(TokenKind.NotEqual)
    ) {
      const op = this.consume().raw;
      const right = this.parse_add_expr();
      left = {
        kind: NodeKind.BinaryExpr,
        left, op, right,
        start: left.start,
        end: right.end
      };
    }
    return left;
  }
  parse_logical_expr() {
    let left = this.parse_comp_expr();
    while(
      this.is_at(TokenKind.LogicalAnd) ||
      this.is_at(TokenKind.LogicalOr)
    ) {
      const op = this.consume().raw;
      const right = this.parse_comp_expr();
      left = {
        kind: NodeKind.BinaryExpr,
        left, op, right,
        start: left.start,
        end: right.end
      };
    }
    return left;
  }
  parse_expr() {
    let left = this.parse_logical_expr();
    while(
      this.is_at(TokenKind.Concat)
      || this.is_at(TokenKind.Question)
    ) {
      if(this.consume_if_at(TokenKind.Question)) {
        const a = this.parse_logical_expr();
        this.consume_if_at(":");
        const b = this.parse_logical_expr();
        left = {
          kind: NodeKind.Ternary,
          cond: left, a, b
        };
        continue;
      }
      
      const op = this.consume().raw;
      const right = this.parse_logical_expr();
      left = {
        kind: NodeKind.BinaryExpr,
        left, op, right,
        start: left.start,
        end: right.end
      };
    }
    if(!this.tokens.length) return left;
    switch(this.tokens[0].kind) {
      case TokenKind.Assign:
      case TokenKind.AssignAdd:
      case TokenKind.AssignSub:
      case TokenKind.AssignMul:
      case TokenKind.AssignDiv:
      case TokenKind.AssignIDiv:
      case TokenKind.AssignMod:
      case TokenKind.AssignCon:
      {
        const op = this.consume().raw;
        switch(left.kind) {
          case NodeKind.Identifier:
          case NodeKind.IndexExpr:
          case NodeKind.MemberExpr:
          {
            const right = this.parse_expr();
            return {
              kind: NodeKind.VarAssign,
              left, op, right,
              start: left.start, end: right.end
            };
          }
          default:
            this.error_at(`can't assign to ${left.kind}`, left.start);
        }
      }
    }
    return left;
  }
  parse_lambda_expr() {
    const start = this.consume().start;
    
    // const is_void = this.consume_if_at(TokenKind.Void)!==false;
    
    let name = null, variadic = -1;
    if(this.is_at(TokenKind.Identifier)) {
      name = this.consume().name;
    }
    
    const params = [];
    if(this.consume_if_at(TokenKind.Comma)) {
      while(true) {
        if(this.is_at(TokenKind.Colon)) break;
        if(this.is_at(TokenKind.LeftBrace)) break;
        if(this.consume_if_at(TokenKind.Plus)) {
          variadic = params.length;
        }
        const name = this.expect(
          TokenKind.Identifier,
          "parameter name must be an identifier"
        ).name;
        params.push(name);
        if(variadic>0) break;
        this.consume_if_at(TokenKind.Comma);
      }
    }
    
    let body = this.parse_inline_or_block("lambda");
    return {
      kind: NodeKind.Lambda,
      name, body/*, is_void*/,
      params, variadic,
      start, end: body.end
    };
  
  }
  
  parse_funcdef_stmt() {
    const start = this.consume().start;
    
    const is_native = this.consume_if_at(TokenKind.Native)!==false;
    // const is_void = this.consume_if_at(TokenKind.Void)!==false;
    
    const name = this.expect(
      TokenKind.Identifier,
      "function name must be an identifier"
    ).name;
    
    const params = [];
    let variadic = -1;
    
    if(this.consume_if_at(TokenKind.Comma)) {
      while(true) {
        if(is_native && this.is_at(TokenKind.Semicolon)) break;
        if(this.is_at(TokenKind.Colon)) break;
        if(this.is_at(TokenKind.LeftBrace)) break;
        if(this.consume_if_at(TokenKind.Plus)) {
          variadic = params.length;
        }
        const name = this.expect(
          TokenKind.Identifier,
          "parameter name must be an identifier"
        ).name;
        params.push(name);
        if(variadic>0) break;
        this.consume_if_at(TokenKind.Comma);
      }
    }
    let body = null, end;
    if(is_native) {
      end = this.expect(TokenKind.Semicolon).end;
    } else {
      body = this.parse_inline_or_block("function");
      end = body.end;
    }
    return {
      kind: NodeKind.FunctionDef,
      name, body,// is_void,
      params, is_native, variadic,
      start, end
    };
  }
  parse_vardef_stmt() {
    const start = this.consume().start;
    const is_const = this.consume_if_at(TokenKind.Tilde)===false;
    const defs = [];
    while(true) {
      const name = this.expect(
        TokenKind.Identifier,
        "variable name must be an identifier"
      ).name;
      const init = this.parse_expr();
      defs.push({ name, init });
      if(this.consume_if_at(TokenKind.Comma)) continue;
      break;
    }
    const end =
      this.consume_if_at(TokenKind.Semicolon)?.end
      ?? defs.at(-1).init.end;
    return {
      kind: NodeKind.VarDef,
      is_const, defs,
      start, end
    };
  }
  parse_block(name = "block") {
    const start = this.expect(
      TokenKind.LeftBrace,
      name+" must start with a left brace"
    ).start;
    const stmts = [];
    while(!this.ended() && !this.is_at(TokenKind.RightBrace)) {
      const stmt = this.parse_stmt();
      stmts.push(stmt);
      if(
        stmt.kind===NodeKind.ReturnStmt
        || stmt.kind===NodeKind.Break
        || stmt.kind===NodeKind.Continue
      ) break;
    }
    const end = this.expect(
      TokenKind.RightBrace,
      name+" must end with a right brace"
    ).end;
    return {
      kind: NodeKind.Block,
      stmts,
      start, end
    };
  }
  parse_inline_or_block(name = "body") {
    if(this.is_at(TokenKind.Colon)) {
      this.consume();
      const stmt = this.parse_stmt();
      if(
        stmt.kind===NodeKind.FunctionDef ||
        stmt.kind===NodeKind.VarDef
      ) {
        this.error_at(`${stmt.kind} after inline ${name} is not allowed`, stmt.start);
      }
      return stmt;
    }
    return this.parse_block(name);
  }
  for_opt_helper() {
    this.consume_if_at(TokenKind.Comma);
    return !this.is_at(TokenKind.Colon) &&
      !this.is_at(TokenKind.LeftBrace) &&
      !this.is_at(TokenKind.Comma);
  }
  
  parse_for_stmt() {
    const start = this.consume().start;
    
    const is_const = this.consume_if_at(TokenKind.Star)!==false;
    
    const cycles = this.parse_expr();
    const counter = this.expect(TokenKind.Identifier).name;
    let iota = null, step = null;
    if(this.for_opt_helper()) {
      iota = this.parse_expr();
    }
    if(this.for_opt_helper()) {
      step = this.parse_expr();
    }
    
    const body = this.parse_inline_or_block("for-statement");
    return {
      kind: NodeKind.ForStmt,
      cycles, counter, iota, step,
      is_const, body,
      start, end: body.end
    };
  }
  parse_if_stmt() {
    const start = this.consume().start;
    const condition = this.parse_expr();
    const body = this.parse_inline_or_block("if-statement");
    let alt = null;
    if(this.is_at(TokenKind.Elif)) {
      alt = this.parse_if_stmt();
    } else if(this.is_at(TokenKind.Else)) {
      const estart = this.consume().start;
      const ebody = this.parse_inline_or_block("else-statement");
      alt = {
        kind: NodeKind.ElseStmt,
        body: ebody,
        start: estart, end: ebody.end
      };
    }
    return {
      kind: NodeKind.IfStmt,
      condition, body, alt,
      start, end: body.end
    };
  }
  parse_while_stmt() {
    const start = this.consume().start;
    const run_first = this.consume_if_at(TokenKind.Star)!==false;
    const condition = this.parse_expr();
    const body = this.parse_inline_or_block("while-statement");
    return {
      kind: NodeKind.WhileStmt,
      condition, body, run_first,
      start, end: body.end
    };
  }
  parse_return_stmt() {
    const start = this.consume().start;
    let value = null;
    if(!this.is_at(TokenKind.Semicolon)) {
      value = this.parse_expr();
    }
    const end =
      this.consume_if_at(TokenKind.Semicolon)?.end
      ?? value.end;
    return {
      kind: NodeKind.ReturnStmt,
      value,
      start, end
    };
  }
  parse_break_stmt() {
    const { start, nend } = this.consume();
    const end =
      this.consume_if_at(TokenKind.Semicolon)?.end
      ?? nend;
    return {
      kind: NodeKind.Break,
      start, end
    };
  }
  parse_continue_stmt() {
    const { start, nend } = this.consume();
    const end =
      this.consume_if_at(TokenKind.Semicolon)?.end
      ?? nend;
    return {
      kind: NodeKind.Continue,
      start, end
    };
  }
  parse_enum_stmt() {
    const start = this.consume().start;
    const name = this.expect(TokenKind.Identifier, "enumerator name must be a identifier").name;
    this.expect(TokenKind.LeftBrace, "enumerator list must start with a left brace");
    const names = [];
    while(!this.ended() && this.is_at(TokenKind.Identifier)) {
      names.push(this.consume().name);
      this.consume_if_at(TokenKind.Comma);
    }
    const end = this.expect(TokenKind.RightBrace, "enumerator list must end with a right brace").end;
    return {
      kind: NodeKind.EnumDef,
      name, names,
      start, end
    }
  }
  parse_stmt() {
    if(this.is_at(TokenKind.Function)) {
      return this.parse_funcdef_stmt();
    }
    if(this.is_at(TokenKind.Var)) {
      return this.parse_vardef_stmt();
    }
    if(this.is_at(TokenKind.For)) {
      return this.parse_for_stmt();
    }
    if(this.is_at(TokenKind.If)) {
      return this.parse_if_stmt();
    }
    if(this.is_at(TokenKind.While)) {
      return this.parse_while_stmt();
    }
    if(this.is_at(TokenKind.LeftBrace)) {
      const block = this.parse_block();
      block.kind = NodeKind.BlockStmt;
      return block;
    }
    if(this.is_at(TokenKind.Return)) {
      return this.parse_return_stmt();
    }
    if(this.is_at(TokenKind.Break)) {
      return this.parse_break_stmt();
    }
    if(this.is_at(TokenKind.Continue)) {
      return this.parse_continue_stmt();
    }
    if(this.is_at(TokenKind.Enum)) {
      return this.parse_enum_stmt();
    }
    
    return this.parse_expr_stmt();
  }
  parse_expr_stmt() {
    const expr = this.parse_expr();
    
    const end =
      this.consume_if_at(TokenKind.Semicolon)?.end
      ?? expr.end;
    
    return {
      kind: NodeKind.ExprStmt,
      expr,
      start: expr.start, end
    };
  }
  parse_program_stmt() {
    if(this.is_at(TokenKind.Import)) {
      const start = this.consume().start;
      
      if(this.is_at(TokenKind.Identifier)) {
        const name = this.consume().name;
        const res = this.expect(TokenKind.String);
        const end = this.consume_if_at(TokenKind.Semicolon)?.end ?? res.end;
        return {
          kind: NodeKind.Import,
          all: true,
          path: res.value, name,
          start, end
        };
      }
      
      const names = [];
      this.expect(TokenKind.LeftBrace);
      while(!this.ended() && !this.is_at(TokenKind.RightBrace)) {
        names.push(this.expect(TokenKind.Identifier).name);
        this.consume_if_at(TokenKind.Comma);
      }
      this.expect(TokenKind.RightBrace);
      
      const res = this.expect(TokenKind.String);
      const end = this.consume_if_at(TokenKind.Semicolon)?.end ?? res.end;
      return {
        kind: NodeKind.Import,
        all: false,
        path: res.value, names,
        start, end
      };
    }
    if(this.is_at(TokenKind.Export)) {
      const start = this.consume().start;
      if(this.is_at(TokenKind.Export)) {
        this.error_at("can't export an export-statement", start);
      }
      const stmt = this.parse_program_stmt();
      if(stmt.kind!==NodeKind.FunctionDef && stmt.kind!==NodeKind.VarDef) {
        this.error_at(`can't export '${stmt.kind}'`, start);
      }
      return {
        kind: NodeKind.Export, stmt,
        start, end: stmt.end
      };
    }
    if(this.is_at(TokenKind.Function)) {
      return this.parse_funcdef_stmt();
    }
    if(this.is_at(TokenKind.Var)) {
      return this.parse_vardef_stmt();
    }
    if(this.is_at(TokenKind.Enum)) {
      return this.parse_enum_stmt();
    }
    if(this.is_at(TokenKind.LeftBrace)) {
      const block = this.parse_block();
      block.kind = NodeKind.BlockStmt;
      return block;
    }
    return this.parse_expr_stmt();
    // this.error_at(`expected end of file but received '${this.tokens[0].kind}'`, this.tokens[0].start);
  }
  parse_program() {
    const body = [];
    while(!this.ended()) {
      body.push(this.parse_program_stmt());
    }
    return {
      kind: NodeKind.Program,
      body,
      start: (body[0]?.start ?? 0),
      end: (body.at(-1)?.end ?? 0)
    };
  }
  error_at(msg, idx) {
    let col = 0, row = 1;
    for(let i = 0; i<=idx; ++i) {
      if(this.text[i]==="\n") {
        col = 0;
        ++row;
      } else {
        ++col;
      }
    }
    --col;
    throw new SyntaxError(`${row}:${col} → ${msg}`);
  }
  parse(code) {
    this.text = code;
    if(typeof code==="string") {
      this.tokens = (new Lexer().lex(code))[0];
    } else {
      this.tokens = code;
    }
    return this.parse_program();
  }
}
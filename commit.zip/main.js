import { interpret_source } from "./vm/main.js";
import { compile_source } from "./vm/compiler.js";
import { Parser } from "./ast/parser.js";

import * as filesystem from "jsr:@std/fs";
import * as path from "jsr:@std/path";

if(!Deno.args.length) Deno.exit(0);

const cmd = Deno.args[0];
switch(cmd) {
  case "-v":
  case "version": {
    console.log("runic v0.0.1");
    Deno.exit(0);
  }
  
  case "-a":
  case "-ast": {
    let input_path = Deno.args[1];
    if(!input_path) {
      console.log("please provide a path for input");
      break;
    }
    if(input_path[0]!=="/") {
      input_path = path.join(import.meta.dirname, input_path);
    }
    if(!filesystem.existsSync(input_path, { isFile: true })) {
      console.log("please provide a path that points to a file");
      break;
    }
    
    let output_path = Deno.args[2];
    if(!output_path) {
      console.log("please provide a path for output");
      break;
    }
    if(output_path[0]!=="/") {
      output_path = path.join(import.meta.dirname, output_path);
    }
    if(filesystem.existsSync(output_path, { isDirectory: true })) {
      console.log("the output path was taken by a directory");
      break;
    }
    if(output_path.includes("/")) {
      const output_dir = output_path.replace(/\/[^\/]+?\/*$/, "");
      Deno.mkdirSync(output_dir, { recursive: true });
    }
    
    const file_res = Deno.readTextFileSync(input_path);
    const program_ast = new Parser().parse(file_res);
    Deno.writeTextFileSync(
      output_path,
      JSON.stringify(program_ast, null, 2),
      { create: true }
    );
    console.log("AST generated");
    break;
  }
  
  case "-r":
  case "run": {
    let input_path = Deno.args[1];
    if(!input_path) {
      console.log("please provide a path for input");
      break;
    }
    if(input_path[0]!=="/") {
      input_path = path.join(import.meta.dirname, input_path);
    }
    if(!filesystem.existsSync(input_path, { isFile: true })) {
      console.log("please provide a path that points to a file");
      break;
    }
    
    const file_res = Deno.readFileSync(input_path);
    interpret_source(true, file_res, Deno.args.slice(2), input_path);
    
    break;
  }
  
  case "-c":
  case "compile": {
    let input_path = Deno.args[1];
    if(!input_path) {
      console.log("please provide a path for input");
      break;
    }
    if(input_path[0]!=="/") {
      input_path = path.join(import.meta.dirname, input_path);
    }
    if(!filesystem.existsSync(input_path, { isFile: true })) {
      console.log("please provide a path that points to a file");
      break;
    }
    
    let output_path = Deno.args[2];
    if(!output_path) {
      console.log("please provide a path for output");
      break;
    }
    if(output_path[0]!=="/") {
      output_path = path.join(import.meta.dirname, output_path);
    }
    if(output_path.includes("/")) {
      const output_dir = output_path.replace(/\/[^\/]+?\/*$/, "");
      Deno.mkdirSync(output_dir, { recursive: true });
    }
    if(filesystem.existsSync(output_path, { isDirectory: true })) {
      console.log("the output path was taken by a directory");
      break;
    }
    
    const file_res = Deno.readTextFileSync(input_path);
    const data = compile_source(file_res, input_path);
    
    Deno.writeFileSync(output_path, data, { create: true });
    
    break;
  }
  
  default: {
    console.log("unknown command → "+cmd);
    break;
  }
}
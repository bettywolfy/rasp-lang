import { Parser, NodeKind } from "../ast/parser.js";
import { Opcode, BinOperToOpcode, UnOperToOpcode } from "../vm/main.js";
import { analyzeAST } from "../ast/analyzer.js";
import * as path from "jsr:@std/path";
import * as filesystem from "jsr:@std/fs";

const tochar = String.fromCharCode;
const fromchar = x => x.charCodeAt(0);

class Scope {
  string_pool = [];
  jumps = [];
  static uint16(x) {
    x = x&0xffff;
    return tochar((x>>8)&255, x&255);
  }
  static int16(x) {
    if(x<0) x += 0x10000;
    x = x&0xffff;
    return tochar((x>>8)&255, x&255);
  }
  static int32(x) {
    if(x<0) x += 0x100000000;
    x = x&0xffffffff;
    return tochar(x>>24, x>>16&255, x>>8&255, x&255);
  }
  static float64(x) {
    const buffer = new ArrayBuffer(8);
    const view = new DataView(buffer);
    view.setFloat64(0, x, false); 
    const bytes = new Uint8Array(buffer);
    return tochar(...bytes);
  }
  static number(x, is_float=true) {
    if(is_float)
        return Opcode.PushFloat+Scope.float64(x);
    if(x>=-0x8000 && x<=0x7FFF)
      return Opcode.PushInt16+Scope.int16(x);
    return Opcode.PushInt32+Scope.int32(x);
  }
  string(str) {
    const type = /^[\x00-\xff]*$/.test(str)
      ? Opcode.BinaryString
      : Opcode.UTF8String;
    
    const fi = this.string_pool.findIndex(x => x[0]===type && x.slice(3)===str);
    if(fi>=0) return Scope.uint16(fi);
    
    if(type===Opcode.UTF8String) {
      str = new TextEncoder().encode(str);
      str = Array.from(str, x => tochar(x)).join("");
    }
    if(str.length>0xffff)
      throw new SyntaxError("string too long");
    this.string_pool.push(type+Scope.uint16(str.length)+str);
    return Scope.uint16(this.string_pool.length-1);
  }
y}

function compile_node(node, scope) {
  switch(node?.kind) {
    case NodeKind.Program: {
      let res = "";
      for(const stmt of node.body) {
        res += compile_node(stmt, scope);
      }
      return Opcode.Magic+scope.string_pool.join("")+res;
    }
    case NodeKind.ReturnStmt: {
      if(!node.value)
        return Opcode.Return;
      return compile_node(node.value, scope)+Opcode.ReturnVal;
    }
    case NodeKind.FunctionDef: {
      if(node.params.length>255) {
        throw new SyntaxError("too many parameters");
      }
      const name = scope.string(node.name);
      
      let res = name
        +tochar(node.params.length)
        +node.params.map(x => scope.string(x)).join("");
        
      if(node.variadic<0)
        res += "\0\0";
      else
        res += "\x01"+tochar(node.variadic);
      
      if(node.is_native) {
        res = Opcode.DecNative+res;
      } else {
        const body = compile_node(node.body, scope);
        res = Opcode.DecFunction+res;
        res += Scope.int32(body.length)+body;
      }
      
      return res;
    }
    case NodeKind.Break: {
      return Opcode.Jump+"\0\0";
    }
    case NodeKind.Continue: {
      return Opcode.Jump+"\0\0";
    }
    case NodeKind.Block:
    case NodeKind.BlockStmt:
    {
      let res = "";
      for(const stmt of node.stmts) {
        res += compile_node(stmt, scope);
      }
      if(node.kind===NodeKind.BlockStmt) {
        res = Opcode.PushScope+res+Opcode.PopScope;
      }
      return res;
    }
    case NodeKind.ExprStmt: {
      return compile_node(node.expr, scope)+Opcode.PopStack;
    }
    case NodeKind.VarDef: {
      let res = "";
      const op = node.is_const
        ? Opcode.DecConst
        : Opcode.DecVar;
      for(const def of node.defs) {
        res += compile_node(def.init, scope);
        res += op+scope.string(def.name);
      }
      return res;
    }
    
    case NodeKind.ElseStmt: {
      return compile_node(node.body, scope);
    }
    case NodeKind.IfStmt: {
      const cond = compile_node(node.condition, scope);
      const body = compile_node(node.body, scope);
      
      if(node.alt) {
        const alt = compile_node(node.alt, scope);
        return cond
          +Opcode.JumpIfNot
          +Scope.uint16(3+body.length)
          +body
          +Opcode.Jump+Scope.uint16(alt.length)
          +alt;
      }
      
      return cond+Opcode.JumpIfNot+Scope.uint16(body.length)+body;
    }
    case NodeKind.WhileStmt: {
      const cond = compile_node(node.condition, scope);
      
      scope.jumps.push([]);
      
      let body = compile_node(node.body, scope);
      
      const jlen = body.length+cond.length;
      for(const [le, ki] of scope.jumps.pop()) {
        let res = Opcode.Jump;
        if(ki===0) {
          res += Scope.uint16(jlen-le);
        } else if(ki===1) {
          res += Scope.uint16(body.length-le-3);
        }
        body = body.slice(0, le)+res+body.slice(le+3);
      }
      
      let res = body
        +cond
        +Opcode.BackIf
        +Scope.uint16(3+cond.length+body.length);
      
      if(!node.run_first) {
        res = Opcode.Jump
          +Scope.uint16(body.length)
          +res;
      }
      
      return res;
    }
    case NodeKind.VarAssign: {
      if(node.op==="=") {
        if(node.left.kind===NodeKind.Identifier) {
          const val = compile_node(node.right, scope);
          return val+Opcode.AssignVar+scope.string(node.left.name);
        }
      }
      const op = node.op.slice(0, -1);
      if(node.left.kind===NodeKind.Identifier) {
        const val = compile_node(node.right, scope);
        const name = scope.string(node.left.name);
        return Opcode.Load
          +name
          +val
          +BinOperToOpcode.get(op)
          +Opcode.AssignVar
          +name;
      }
    }
    
    case NodeKind.ArrayExpr: {
      if(node.items.length>0xffff) {
        throw new SyntaxError("too many items");
      }
      const items = node.items.map(a => compile_node(a, scope)).join("");
      return items+Opcode.MakeArray+Scope.uint16(node.items.length);
    }
    case NodeKind.CallExpr: {
      let res = "";
      if(node.args.length>255) {
        throw new SyntaxError("too many arguments");
      }
      res += node.args.map(a => compile_node(a, scope)).join("");
      if(node.callee.kind===NodeKind.MemberExpr) {
        res += compile_node(node.callee.object, scope);
        res += Opcode.CopyStack;
        res += Opcode.AccessMember+scope.string(node.callee.property);
        return res+Opcode.CallWithSelf+tochar(node.args.length);
      }
      
      const callee = compile_node(node.callee, scope);
      return res+Opcode.Call+tochar(node.args.length);
    }
    case NodeKind.BinaryExpr: {
      const left = compile_node(node.left, scope);
      const right = compile_node(node.right, scope);
      return left+right+BinOperToOpcode.get(node.op);
    }
    case NodeKind.UnaryExpr: {
      if(node.op==="-" && node.expr.kind===NodeKind.NumberLiteral) {
        return Scope.number(-node.expr.value, node.expr.is_float);
      }
      const expr = compile_node(node.expr, scope);
      return expr+UnOperToOpcode.get(node.op);
    }
    case NodeKind.BoolLiteral: {
      return node.value
        ? Opcode.PushTrue
        : Opcode.PushFalse;
    }
    case NodeKind.NaNLiteral: return Opcode.PushNaN;
    case NodeKind.NilLiteral: return Opcode.PushNil;
    case NodeKind.NumberLiteral: {
      return Scope.number(node.value, node.is_float);
    }
    case NodeKind.StringLiteral: {
      return Opcode.LoadString+scope.string(node.value);
    }
    case NodeKind.TemplateString: {
      let res = "";
      for(let i = 0; i<node.quasis.length; ++i) {
        res += Opcode.LoadString+scope.string(node.quasis[i]);
        if(i>0) res += Opcode.BoConcat;
        if(i<node.exprs.length) {
          res += compile_node(node.exprs[i], scope);
          res += Opcode.BoConcat;
        }
      }
      return res;
    }
    case NodeKind.Identifier: {
      return Opcode.Load+scope.string(node.name);
    }
    default: {
      console.log(node);
      throw new Error();
    }
  }
}

export function compile_source(code, path) {
  try {
    const program = new Parser().parse(code);
    analyzeAST(program);
    
    const scope = new Scope();
    const res = compile_node(program, scope);
    return Uint8Array.from(res, fromchar);
  } catch(e) {
    console.log(`\x1b[1;31merror: ${e.message}\n  at ${path}\x1b[0m`);
    console.log(`\x1b[2;38;5;244m${e.stack.slice(e.name.length+e.message.length+3).replace(/^    /gm, "  ")}\x1b[0m`);
    throw e;
  }
}
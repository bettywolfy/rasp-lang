import { Parser, NodeKind } from "../ast/parser.js";
import { analyzeAST } from "../ast/analyzer.js";
import * as path from "jsr:@std/path";
import * as filesystem from "jsr:@std/fs";

export let global_scope;

export class Scope {
  syms = new Map();
  consts = new Set();
  constructor(parent = false) {
    if(parent) {
      this.parent = parent;
      this.root = parent.root;
      this.exports = parent.exports;
    } else {
      this.parent = global_scope;
      this.root = this;
      this.exports = new Map();
    }
  }
  add_export(name, value) {
    this.exports.set(name, value);
  }
  declare(name, value, is_const = false) {
    if(this.syms.has(name)) {
      throw new SyntaxError(`redefinition of '${name}' is not allowed`);
    }
    if(is_const) this.consts.add(name);
    return this.syms.set(name, value);
  }
  assign(name, value) {
    const scope = this.lookup(name);
    if(!scope) {
      rt_error(`'${name}' is not defined`);
    }
    if(scope.consts.has(name)) {
      rt_error(`assignment to constant '${name}' is not allowed`);
    }
    return scope.syms.set(name, value);
  }
  get(name, crash = true) {
    const scope = this.lookup(name);
    if(!scope) {
      if(!crash) return null;
      rt_error(`'${name}' is not defined`);
    }
    return scope.syms.get(name);
  }
  lookup(name) {
    if(this.syms.has(name)) return this;
    if(this.parent) return this.parent.lookup(name);
    return null;
  }
}

global_scope = new Scope();

function stypeof(x) {
  if(x===null) return "null";
  return typeof x;
}

function rt_error(msg) {
  throw new Error(msg);
}

function rt_value(tag, value) {
  return { tag, value };
}

let rt_nil, rt_nan, rt_true, rt_false,
  rt_prototype_array,
  rt_prototype_object,
  rt_prototype_function,
  rt_prototype_regex;

function rt_object(proto, ...props) {
  const keys = new Map();
  const len = props.length-props.length%2;
  for(let i = 0; i<len; i += 2) {
    keys.set(props[i], props[i+1]);
  }
  return { tag: "object", proto, keys, name: "object" };
}

function rt_regex(regex) {
  const rg = rt_object(rt_prototype_regex);
  rg.regex = regex;
  rg.name = "regex";
  return rg;
}

function rt_tostr(val) {
  if(val.tag==="string") return val;
  if(val.tag==="number") {
    if(Number.isNaN(val.value)) {
      return rt_value("string", "nan");
    }
    if(Number.isFinite(val.value)) {
      return rt_value("string", ""+val.value);
    }
    return rt_value("string", val.val>0 ? "inf" : "-inf");
  } 
  if(val.tag==="bool" || val.tag==="nil") {
    return rt_value("string", ""+val.value);
  }
  
  const f = rt_meta_index(val, "__tostr");
  if(f===rt_nil) rt_error(`can't convert ${val.tag} to string`);
  
  const res = rt_call(f, val);
  if(res.tag!=="string") rt_error("function '__tostr' must return a string");
  return res;
}

function rt_index(obj, prop) {
  if(obj===rt_nil) {
    rt_error("can't index nil value");
  }
  if(stypeof(prop)!=="string") {
    prop = rt_tostr(prop).value;
  }
  while(obj && (obj.tag==="object" || obj.tag==="function")) {
    const val = obj.keys.get(prop);
    if(val) return val;
    obj = obj.proto;
  }
  return rt_nil;
}
function rt_set_index(obj, prop, val) {
  if(obj===rt_nil) {
    rt_error("can't set index of nil value");
  }
  if(obj.tag!=="object" && obj.tag!=="function") {
    rt_error(`can't set index of ${obj.tag}`);
  }
  if(stypeof(prop)!=="string") {
    prop = rt_tostr(prop).value;
  }
  obj.keys.set(prop, val);
  return rt_nil;
}

function to_rt_value(val) {
  const t = stypeof(val);
  if(t==="null" || t==="undefined") return rt_nil;
  if(t==="boolean") return val ? rt_true : rt_false;
  if(t==="number") {
    if(Number.isNaN(val)) return rt_nan;
    return rt_value("number", val);
  }
  if(t==="string") return rt_value("string", val);
  return rt_nil;
}

function rt_function(name, params, body, variadic=-1, scope=null) {
  const obj = rt_object(
    rt_prototype_function,
    "name", to_rt_value(name)
  );
  obj.tag = "function";
  obj.body = body;
  obj.params = params;
  obj.variadic = variadic;
  obj.size = params.length;
  obj.scope = scope;
  return obj;
}

rt_nil = rt_value("nil", "nil");
rt_nan = rt_value("number", NaN);
rt_true = rt_value("bool", true);
rt_false = rt_value("bool", false);

rt_prototype_object = rt_object(rt_nil);
rt_prototype_function = rt_object(rt_prototype_object);

rt_set_index(
  rt_prototype_object,
  "__tostr", rt_function(
    "__tostr", [],
    function(self) {
      return rt_value("string", `[object ${self.name}]`);
    }
  )
);

rt_set_index(
  rt_prototype_function,
  "__tostr", rt_function(
    "__tostr", [],
    function(self) {
      const name = rt_tostr(rt_index(self, "name")).value;
      return rt_value("string", `[fun${name ? ` ${name}` : ""}]`);
    }
  )
);
rt_set_index(
  rt_prototype_function,
  "__len", rt_function(
    "__len", [],
    function(self) {
      return rt_value("number", self.size);
    }
  )
);
rt_set_index(
  rt_prototype_function,
  "apply", rt_function(
    "apply", ["vself", "args"],
    function(self, vself, args) {
      const argv = [];
      const len = rt_len(args).value;
      for(let i = 0; i<len; ++i) {
        argv.push(rt_index(args, ""+i));
      }
      return rt_call(self, vself, ...argv);
    },
    1
  )
);

rt_prototype_array = rt_object(rt_prototype_object,
  "__tostr", rt_function(
    "__tostr", [],
    function(self) {
      const len = rt_len(self).value;
      
      let res = "";
      for(let i = 0; i<len;) {
        res += rt_tostr(rt_index(self, ""+i)).value;
        if(++i<len) res += ", ";
      }
      return rt_value("string", res);
    }),
  "__len", rt_function(
    "__len", [],
    function(self) {
      let i = 0;
      while(rt_index(self, ""+i)!==rt_nil) ++i;
      return rt_value("number", i);
    }),
  "join", rt_function(
    "join", ["sep"],
    function(self, sep) {
      sep = rt_tostr(sep).value;
      const len = rt_len(self).value;
      
      let res = "";
      for(let i = 0; i<len;) {
        res += rt_tostr(rt_index(self, ""+i)).value;
        if(++i<len) res += sep;
      }
      return rt_value("string", res);
    }),
  "has", rt_function(
    "has", ["occ"],
    function(self, occ) {
      const len = rt_len(self).value;
      
      for(let i = 0; i<len; ++i) {
        const e = rt_index(self, ""+i);
        if(rt_eq(e, occ).value) return rt_true;
      }
      return rt_false;
    }),
  "push", rt_function(
    "push", ["val"],
    function(self, val) {
      const len = rt_len(self).value;
      rt_set_index(self, ""+len, val);
      return rt_value("number", len+1);
    }),
  "map", rt_function(
    "map", ["func"],
    function(self, func) {
      const len = rt_len(self).value;
      
      const arr = rt_array([]);
      for(let i = 0; i<len; ++i) {
        const e = rt_index(self, ""+i);
        const v = rt_value("number", i);
        rt_set_index(arr, ""+i, rt_call(func, rt_nil, e, v));
      }
      return arr;
    }),
  "mapto", rt_function(
    "mapto", ["func"],
    function(self, func) {
      const len = rt_len(self).value;
      
      for(let i = 0; i<len; ++i) {
        const e = rt_index(self, ""+i);
        const v = rt_value("number", i);
        rt_set_index(self, ""+i, rt_call(func, rt_nil, e, v));
      }
    }),
);

rt_prototype_regex = rt_object(rt_prototype_object,
  "__tostr", rt_function("__tostr", [], function(self) {
    return rt_value("string", self.regex.toString());
  }),
  "test", rt_function("test", ["str"], function(self, str) {
    str = rt_tostr(str).value;
    return rt_value("bool", self.regex.test(str));
  }),
);

function rt_array(idxs) {
  const obj = rt_object(rt_prototype_array);
  for(let i = 0; i<idxs.length; ++i) {
    rt_set_index(obj, ""+i, idxs[i]);
  }
  return obj;
}

function rt_call(func, self, ...args) {
  if(func.tag==="nil") {
    rt_error("can't call nil value");
  }
  if(func.tag!=="function") {
    const d = rt_meta_index(func, "__call");
    if(!d || d===rt_nil) rt_error(`can't call ${func.tag}`);
    if(d.tag!=="function") rt_error("property '__call' must be a function");
    func = d;
  }
  const variadic = func.variadic;
  if(args.length<func.size) {
    let len = func.size;
    if(variadic>=0) len = variadic;
    while(args.length<len) args.push(rt_nil);
    /*const name = rt_tostr(rt_index(func, "name")).value;
    rt_error(`can't call '${name}' with ${args.length} arguments`);*/
  }
  const arg_list = rt_array(args);
  if(variadic>=0) {
    const vari = rt_array(args.slice(variadic));
    args = args.slice(0, variadic);
    args[variadic] = vari;
  }
  if(stypeof(func.body)==="function") {
    return func.body(self, ...args) ?? rt_nil;
  }
  const fscope = new Scope(func.scope);
  for(let i = 0; i<func.size; ++i) {
    fscope.declare(func.params[i], args[i]);
  }
  fscope.declare("self", self, true);
  fscope.declare("arguments", arg_list, true);
  try {
    evaluate_node(func.body, fscope);
  } catch(e) {
    if(e instanceof ReturnSignal) return e.value;
    throw e;
  }
  return rt_nil;
}

function rt_len(val) {
  if(val.tag==="string") return rt_value("number", val.value.length);
  if(val.tag==="nil") rt_error("can't get length of nil value");
  if(val.tag==="bool") rt_error("can't get length of bool");
  if(val.tag==="number") rt_error("can't get length of number");
  
  const f = rt_meta_index(val, "__len");
  if(f===rt_nil) rt_error(`can't get length of ${val.tag}`);
  
  const res = rt_call(f, val);
  if(res.tag!=="number") rt_error("function '__len' must return a number");
  return res;
}
function rt_is_truthy(val) {
  if(val===rt_nil) return false;
  if(val.tag==="bool") return val.value;
  return true;
}
function rt_eq(left, right) {
  if(
    (left.tag==="object" && right.tag==="object")
    || (left.tag==="function" && right.tag==="function")
  ) {
    return rt_value("bool", left===right);
  }
  return rt_value("bool", left.tag===right.tag && left.value===right.value);
}
function rt_neq(left, right) {
  if(
    (left.tag==="object" && right.tag==="object")
    || (left.tag==="function" && right.tag==="function")
  ) {
    return rt_value("bool", left!==right);
  }
  return rt_value("bool", left.tag!==right.tag || left.value!==right.value);
}

const rt_binop_name = new Map([
  ["+", "__add"],
  ["-", "__sub"],
  ["*", "__mul"],
  ["/", "__div"],
  ["//", "__idiv"],
  ["%", "__mod"],
  ["^", "__pow"],
  ["<", "__lt"],
  ["<=", "__lte"],
  [">", "__gt"],
  [">=", "__gte"],
]);
function rt_binop(op, left, right) {
  if(op==="..") return rt_value("string", rt_tostr(left).value+rt_tostr(right).value);
  if(op==="&&") return rt_value("bool", rt_is_truthy(left)&&rt_is_truthy(right));
  if(op==="||") return rt_value("bool", rt_is_truthy(left)||rt_is_truthy(right));
  if(op==="==") return rt_eq(left, right);
  if(op==="!=") return rt_neq(left, right);
  
  if(left.tag==="number" && right.tag==="number") {
    switch(op) {
      case "+": return rt_value("number", left.value+right.value);
      case "-": return rt_value("number", left.value-right.value);
      case "*": return rt_value("number", left.value*right.value);
      case "/": return rt_value("number", left.value/right.value);
      case "//": return rt_value("number", Math.trunc(left.value/right.value));
      case "%": return rt_value("number", left.value%right.value);
      case "^": return rt_value("number", left.value**right.value);
      
      case "<": return rt_value("bool", left.value<right.value);
      case "<=": return rt_value("bool", left.value<=right.value);
      case ">": return rt_value("bool", left.value>right.value);
      case ">=": return rt_value("bool", left.value>=right.value);
    }
  }
  const nop = rt_binop_name.get(op);
  if(!nop) rt_error(`unknown operation '${op}'`);
  
  let f = rt_meta_index(left, nop);
  if(f===rt_nil) f = rt_meta_index(right, nop);
  if(f===rt_nil) {
    rt_error(`can't do '${op}' binary operation with ${left.tag} and ${right.tag}`);
  }
  return rt_call(f, rt_nil, left, right);
}
const rt_unop_name = new Map([
  ["-", "__unm"],
  ["!", "__not"]
]);
function rt_unop(op, val) {
  if(op==="#") return rt_len(val);
  
  if(val.tag==="number" && op==="-") {
    return rt_value("number", -val.value);
  }
  if(val.tag==="bool" && op==="!") {
    return rt_value("bool", !val.value);
  }
  
  const nop = rt_unop_name.get(op);
  if(!nop) {
    if(op==="!") return rt_value("bool", !rt_is_truthy(val));
    rt_error(`unknown operation '${op}'`);
  }
  
  const f = rt_meta_index(val, nop);
  if(f===rt_nil) rt_error(`can't do '${op}' binary operation with ${val.tag}`);
  
  return rt_call(f, val);
}

function rt_meta_index(obj, prop) {
  if(obj.tag!=="object" && obj.tag!=="function") return rt_nil;
  if(!obj.proto || obj.proto===rt_nil) return rt_nil;
  return rt_index(obj.proto, prop);
}

function help_getnum(x, msg) {
  if(x.tag!=="number") {
    rt_error(`${msg} must be a number but found ${x.tag} instead`);
  }
  return x.value;
}

class ReturnSignal extends SyntaxError {
  constructor(val = rt_nil) {
    super("return-statement ouside function body");
    this.value = val;
  }
}


const rt_h_break = new SyntaxError("break-statement outside loop");
const rt_h_continue = new SyntaxError("continue-statement outside loop");

const rt_rni = new Map([
  ["core/math.rp/sqrt", (self, x) => {
    x = help_getnum(x, "value");
    return rt_value("number", Math.sqrt(x));
  }],
  ["core/math.rp/exp", (self, x) => {
    x = help_getnum(x, "value");
    return rt_value("number", Math.exp(x));
  }],
  ["core/math.rp/log", (self, base, x) => {
    base = help_getnum(base, "logarithm base");
    x = help_getnum(x, "value");
    return rt_value("number", Math.log(x)/Math.log(base));
  }],
  ["core/math.rp/ln", (self, x) => {
    x = help_getnum(x, "value");
    return rt_value("number", Math.log(x));
  }],
  ["core/math.rp/lb", (self, x) => {
    x = help_getnum(x, "value");
    return rt_value("number", Math.log2(x));
  }],
  ["core/math.rp/lg", (self, x) => {
    x = help_getnum(x, "value");
    return rt_value("number", Math.log10(x));
  }],
  ["core/math.rp/cos", (self, x) => {
    x = help_getnum(x, "value");
    return rt_value("number", Math.cos(x));
  }],
  ["core/math.rp/sin", (self, x) => {
    x = help_getnum(x, "value");
    return rt_value("number", Math.sin(x));
  }],
  ["core/math.rp/floor", (self, x) => {
    x = help_getnum(x, "value");
    return rt_value("number", Math.floor(x));
  }],
  ["core/math.rp/ceil", (self, x) => {
    x = help_getnum(x, "value");
    return rt_value("number", Math.ceil(x));
  }],
  ["core/math.rp/fract", (self, x) => {
    x = help_getnum(x, "value");
    return rt_value("number", x-Math.floor(x));
  }],
  ["core/math.rp/trunc", (self, x) => {
    x = help_getnum(x, "value");
    return rt_value("number", Math.trunc(x));
  }],
  ["core/random.rp/rf", (self, x) => {
    if(x===rt_nil) x = 1;
    else x = help_getnum(x, "random scale");
    return rt_value("number", x*Math.random());
  }],
  ["core/random.rp/crf", (self, x) => {
    if(x===rt_nil) x = 1;
    else x = help_getnum(x, "random scale");
    const sample = new Uint32Array(1);
    crypto.getRandomValues(sample);
    return rt_value("number", x*sample[0]/0x100000000);
  }],
  ["core/random.rp/ri", (self, min, max) => {
    if(min!==rt_nil && max===rt_nil) {
      min = help_getnum(min, "random max interval");
      return rt_value("number", Math.floor((min+1)*Math.random()));
    }
    min = help_getnum(min, "random min interval");
    max = help_getnum(max, "random max interval");
    if(min===max) return rt_value("number", min);
    return rt_value("number", Math.floor(min+(max-min+1)*Math.random()));
  }],
  ["core/random.rp/cri", (self, min, max) => {
    if(min!==rt_nil && max===rt_nil) {
      min = help_getnum(min, "random max interval");
      return rt_value("number", Math.floor((min+1)*Math.random()));
    }
    min = help_getnum(min, "random min interval");
    max = help_getnum(max, "random max interval");
    if(min===max) return rt_value("number", min);
    
    const range = max-min;
    const limit = Math.floor(2**32/range)*range;
    const sample = new Uint32Array(1);
    do {
      crypto.getRandomValues(sample);
    } while (sample[0]>=limit);
    return rt_value("number", min+(sample[0]%range));
  }],
  ["core/random.rp/cris", (self, size) => {
    size = help_getnum(size, "array size");
    if(size<1) rt_error("array size must be greater than 0");
    
    let samples = new Uint32Array(size);
    crypto.getRandomValues(samples);
    
    samples = Array.from(samples);
    samples = samples.map(x => rt_value("number", x));
    return rt_array(samples);
  }],
  ["core/random.rp/uuid", (self) => {
    return rt_value("string", crypto.randomUUID());
  }],
]);

function evaluate_node(node, scope) {
  if(!node) return rt_nil;
  
  switch(node.kind) {
    case NodeKind.Export: {
      const stmt = node.stmt;
      switch(stmt.kind) {
        case NodeKind.FunctionDef: {
          evaluate_node(stmt, scope);
          scope.add_export(stmt.name, scope.get(stmt.name));
          break;
        }
        case NodeKind.VarDef: {
          for(const def of stmt.defs) {
            const init = evaluate_node(def.init, scope);
            scope.declare(def.name, init, node.is_const);
            scope.add_export(def.name, init);
          }
          break;
        }
      }
      return rt_nil;
    }
    case NodeKind.Import: {
      let final_path;
      if(node.path.startsWith("./")) {
        final_path = path.join(scope.root.__dirname, node.path);
      } else {
        rt_error(`module '${node.path}' does not exists`);
      }
      
      if(!filesystem.existsSync(final_path, { isFile: true })) {
        rt_error(`module '${node.path}' does not exists`);
      }
      const source = Deno.readTextFileSync(final_path);
      
      const dscope = interpret_source(false, source, [], final_path);
      
      if(node.all) {
        const obj = rt_object(rt_nil);
        for(const [name, value] of dscope.exports.entries()) {
          rt_set_index(obj, name, value);
        }
        scope.declare(node.name, obj, true);
        return rt_nil;
      }
      
      for(const name of node.names) {
        const e = dscope.exports.get(name);
        if(!e) {
          rt_error(`no import '${name}' in module '${node.path}'`);
        }
        scope.declare(name, e, true);
      }
      
      return rt_nil;
    }
    
    case NodeKind.Program: {
      for(const stmt of node.body) {
        evaluate_node(stmt, scope);
      }
      return rt_nil;
    }
    case NodeKind.Lambda: {
      return rt_function(node.name ?? "", node.params, node.body, node.variadic, scope);
    }
    case NodeKind.FunctionDef: {
      let body;
      if(node.is_native) {
        if(!scope.root.__dirname.startsWith(import.meta.dirname)) {
          rt_error("no natives for you!");
        }
        
        let m_name = scope.root.__filename+"/"+node.name;
        m_name = m_name.slice(import.meta.dirname.length+1);
        if(!rt_rni.has(m_name)) {
          rt_error(`can't resolve native method '${m_name}'`);
        }
        body = rt_rni.get(m_name);
      } else body = node.body;
      
      const func = rt_function(node.name, node.params, body, node.variadic, scope);
      rt_set_index(func, "prototype", rt_object(rt_prototype_object));
      scope.declare(node.name, func, true);
      return rt_nil;
    }
    case NodeKind.Block:
    case NodeKind.BlockStmt:
    {
      if(node.kind===NodeKind.BlockStmt) {
        scope = new Scope(scope);
      }
      for(const stmt of node.stmts) {
        evaluate_node(stmt, scope);
      }
      return rt_nil;
    }
    case NodeKind.ExprStmt: {
      evaluate_node(node.expr, scope);
      return rt_nil;
    }
    case NodeKind.VarDef: {
      for(const def of node.defs) {
        const init = evaluate_node(def.init, scope);
        scope.declare(def.name, init, node.is_const);
      }
      return rt_nil;
    }
    case NodeKind.VarAssign: {
      const right = evaluate_node(node.right, scope);
      if(node.op==="=") {
        if(node.left.kind===NodeKind.IndexExpr) {
          const obj = evaluate_node(node.left.object, scope);
          const prop = evaluate_node(node.left.property, scope);
          rt_set_index(obj, prop, right);
          return right;
        } else if(node.left.kind===NodeKind.MemberExpr) {
          const obj = evaluate_node(node.left.object, scope);
          rt_set_index(obj, node.left.property, right);
          return right;
        }
        scope.assign(node.left.name, right);
        return right;
      }
      const left = evaluate_node(node.left, scope);
      const val = rt_binop(node.op.slice(0, -1), left, right);
      if(node.left.kind===NodeKind.IndexExpr) {
        const obj = evaluate_node(node.left.object, scope);
        const prop = evaluate_node(node.left.property, scope);
        rt_set_index(obj, prop, val);
        return val;
      } else if(node.left.kind===NodeKind.MemberExpr) {
        const obj = evaluate_node(node.left.object, scope);
        rt_set_index(obj, node.left.property, val);
        return val;
      }
      scope.assign(node.left.name, val);
      return val;
    }
    case NodeKind.ForStmt: {
      let cycles = evaluate_node(node.cycles, scope);
      cycles = help_getnum(cycles, "for-loop cycles");
      
      let iota = 0, step = 1;
      if(node.iota) {
        iota = evaluate_node(node.iota, scope);
        iota = help_getnum(iota, "for-loop iota");
      }
      if(node.step) {
        step = evaluate_node(node.step, scope);
        step = help_getnum(step, "for-loop step");
      }
      
      if(node.is_const) {
        for(let i = 0, j = iota; i<cycles; ++i, j += step) {
          try {
            const lscope = new Scope(scope);
            lscope.declare(node.counter, rt_value("number", j), true);
            evaluate_node(node.body, lscope);
          } catch(e) {
            if(e===rt_h_break) break;
            if(e===rt_h_continue) continue;
            throw e;
          }
        }
        return rt_nil;
      }
      
      for(let i = iota; i<cycles; i += step) {
        try {
          const lscope = new Scope(scope);
          lscope.declare(node.counter, rt_value("number", i), true);
          evaluate_node(node.body, lscope);
        } catch(e) {
          if(e===rt_h_break) break;
          if(e===rt_h_continue) continue;
          throw e;
        }
      }
      return rt_nil;
    }
    case NodeKind.IfStmt: {
      const cond = evaluate_node(node.condition, scope);
      if(rt_is_truthy(cond)) {
        evaluate_node(node.body, new Scope(scope));
      } else if(node.alt) {
        if(node.alt.kind===NodeKind.ElseStmt) {
          evaluate_node(node.alt.body, new Scope(scope));
        } else {
          evaluate_node(node.alt, scope);
        }
      }
      return rt_nil;
    }
    case NodeKind.WhileStmt: {
      let ft = node.run_first;
      while(true) {
        if(ft) ft = false;
        else {
          const cond = evaluate_node(node.condition, scope);
          if(!rt_is_truthy(cond)) break;
        }
        
        try {
          evaluate_node(node.body, new Scope(scope));
        } catch(e) {
          if(e===rt_h_break) break;
          if(e===rt_h_continue) continue;
          throw e;
        }
      }
      return rt_nil;
    }
    
    case NodeKind.Break: {
      throw rt_h_break;
    }
    case NodeKind.Continue: {
      throw rt_h_continue;
    }
    case NodeKind.Return: {
      if(!node.value) {
        throw new ReturnSignal();
      }
      const val = evaluate_node(node.value, scope);
      throw new ReturnSignal(val);
    }
    
    case NodeKind.ArrayExpr: {
      const idxs = node.items
        .map(a => evaluate_node(a, scope));
      return rt_array(idxs);
    }
    case NodeKind.ObjectExpr: {
      const obj = rt_object(rt_prototype_object);
      for(const { key, value } of node.entries) {
        rt_set_index(obj, key, evaluate_node(value, scope));
      }
      return obj;
    }
    case NodeKind.CallExpr: {
      const args = node.args.map(a => evaluate_node(a, scope));
      if(node.callee.kind===NodeKind.MemberExpr) {
        const obj = evaluate_node(node.callee.object, scope);
        const val = rt_index(obj, node.callee.property);
        return rt_call(val, obj, ...args);
      }
      const callee = evaluate_node(node.callee, scope);
      return rt_call(callee, rt_nil, ...args);
    }
    case NodeKind.New: {
      const args = node.args.map(a => evaluate_node(a, scope));
      const callee = evaluate_node(node.callee, scope);
      
      if(callee.tag!=="function") {
        rt_error(`${callee.tag} is not a constructor`);
      }
      const new_obj = rt_object(rt_index(callee, "prototype"));
      rt_call(callee, new_obj, ...args);
      return new_obj;
    }
    case NodeKind.IndexExpr: {
      const obj = evaluate_node(node.object, scope);
      const prop = evaluate_node(node.property, scope);
      return rt_index(obj, prop);
    }
    case NodeKind.MemberExpr: {
      const obj = evaluate_node(node.object, scope);
      return rt_index(obj, node.property);
    }
    case NodeKind.PathExpr:
    case NodeKind.MemberExpr: {
      const obj = evaluate_node(node.object, scope);
      return rt_index(obj, node.property);
    }
    case NodeKind.Ternary: {
      const cond = evaluate_node(node.cond, scope);
      if(rt_is_truthy(cond)) {
        return evaluate_node(node.a, scope);
      }
      return evaluate_node(node.b, scope);
    }
    case NodeKind.BinaryExpr: {
      const left = evaluate_node(node.left, scope);
      if((node.op==="&&" || node.op==="||") && rt_is_truthy(left)) return left;
      const right = evaluate_node(node.right, scope);
      return rt_binop(node.op, left, right);
    }
    case NodeKind.UnaryExpr: {
      const expr = evaluate_node(node.expr, scope);
      return rt_unop(node.op, expr);
    }
    case NodeKind.BoolLiteral: {
      return rt_value("bool", node.value);
    }
    case NodeKind.NaNLiteral: return rt_nan;
    case NodeKind.NilLiteral: return rt_nil;
    case NodeKind.NumberLiteral: {
      return rt_value("number", node.value);
    }
    case NodeKind.StringLiteral: {
      return rt_value("string", node.value);
    }
    case NodeKind.RegexLiteral: {
      return rt_regex(node.regex);
    }
    case NodeKind.TemplateString: {
      let res = "";
      for(let i = 0; i<node.quasis.length; ++i) {
        res += node.quasis[i];
        if(i<node.exprs.length) {
          const expr = evaluate_node(node.exprs[i], scope);
          res += rt_tostr(expr).value;
        }
      }
      return rt_value("string", res);
    }
    case NodeKind.Identifier: {
      return scope.get(node.name);
    }
    default: {
      console.log(node);
      throw new Error();
    }
  }
}

function raw_prompt() {
  Deno.stdin.setRaw(true);
  const buf = new Uint8Array(1024);
  let input = "";
  try {
    while(true) {
      const n = Deno.stdin.readSync(buf);
      if(n===null || n===0) break;
      const char = new TextDecoder().decode(buf.subarray(0, n));
      if(char==="\x03") {
        process.stdout.write("^C\n");
        Deno.exit(130);
      }
      if(char==="\x04") {
        process.stdout.write("^D\n");
        break;
      }
      if(char==="\r" || char==="\n") {
        process.stdout.write("\n");
        break;
      }
      if(char==="\x7f" || char==="\x08") {
        if(input.length>0) {
          input = input.slice(0, -1);
          process.stdout.write("\x08 \x08");
        }
        continue;
      }
  
      if(char.charCodeAt(0)<32 && char!=="\t") continue;
      input += char;
      process.stdout.write(char);
    }
  } finally {
    Deno.stdin.setRaw(false);
  }
  if(!input.length) return null;
  return input;
}

global_scope.declare("typeof",
  rt_function("typeof", ["val"], function(self, val) {
    return rt_value("string", val.tag);
  }),
  true
)
global_scope.declare("error",
  rt_function("typeof", ["msg"], function(self, msg) {
    rt_error(rt_tostr(msg).value);
  }),
  true
)
global_scope.declare("tostring",
  rt_function("typeof", ["val"], function(self, val) {
    return rt_tostr(val);
  }),
  true
)
global_scope.declare("instanceof",
  rt_function("instanceof", ["ins", "proto"], function(self, ins, proto) {
    if(proto.tag!=="function" || ins.tag!=="object") return rt_false;
    proto = rt_index(proto, "prototype");
    ins = ins.proto;
    while(ins && ins!==rt_nil) {
      if(ins===proto) return rt_true;
      ins = ins.proto;
    }
    return rt_false;
  }),
  true
)

{
  const sys = rt_object(rt_prototype_object,
    "read", rt_function(
      "read", ["msg"], function(self, msg) {
        if(msg!==rt_nil) {
          process.stdout.write(rt_tostr(msg).value);
        }
        const out = raw_prompt();
        if(!out) return rt_nil;
        return rt_value("string", out);
      }),
    "confirm", rt_function(
      "confirm", ["msg"], function(self, msg) {
        if(msg!==rt_nil) {
          process.stdout.write(rt_tostr(msg).value+" [Y/n] ");
        } else {
          process.stdout.write("confirm? [Y/n] ");
        }
        const out = raw_prompt();
        if(!out) return rt_nil;
        return rt_value("string", out);
      }),
    "sleep", rt_function(
      "sleep", ["ms"], function(self, ms) {
        ms = help_getnum(ms, "sleep time");
        if(ms<0) {
          rt_error("can't sleep for negative milliseconds");
        }
        const sab = new SharedArrayBuffer(4);
        const int32 = new Int32Array(sab);
        Atomics.wait(int32, 0, 0, ms);
      }),
    "exit", rt_function(
      "exit", ["code"], function(self, code) {
        code = help_getnum(code, "exit code");
        Deno.exit(code);
      }),
    "writeln", rt_function(
      "writeln", ["data"], function(self, data) {
        process.stdout.write(rt_tostr(data).value+"\n");
      }),
    "write", rt_function(
      "write", ["data"], function(self, data) {
        process.stdout.write(rt_tostr(data).value);
      }),
  );
  sys.name = "sys";
  global_scope.declare("sys", sys, true);
}

{
  const func = rt_function("Array", ["array"], function(self, array) {
    if(array.tag!=="object") return;
    const len = rt_len(array).value;
    for(let i = 0; i<len; ++i) {
      rt_set_index(self, ""+i, rt_index(array, ""+i));
    }
  });
  rt_set_index(func, "prototype", rt_prototype_array);
  global_scope.declare("Array", func);
}

{
  const func = rt_function("RegExp", ["array"], function(self, pattern, flags) {
    pattern = rt_tostr(pattern).value;
    flags = rt_tostr(flags).value;
    self.regex = new RegExp(pattern, flags);
  });
  rt_set_index(func, "prototype", rt_prototype_regex);
  global_scope.declare("RegExp", func);
}

{
  const func = rt_function("Object", ["obj"], function(self, obj) {
    if(obj.tag!=="object") return;
    for(const [key, value] of obj.keys.entries()) {
      rt_set_index(self, key, value);
    }
  });
  rt_set_index(func, "get_proto", rt_function(
    "get_proto", ["obj"], function(self, obj) {
      return obj.proto ?? rt_nil;
    }));
  rt_set_index(func, "prototype", rt_prototype_object);
  rt_set_index(func, "entries", rt_function(
    "entries", ["obj"], function(self, obj) {
      if(obj.tag!=="object") {
        rt_error("can't get entries of "+obj.tag);
      }
      return rt_array([...obj.keys.entries()].map(([key, val]) => {
        return rt_array([rt_value("string", key), val]);
      }));
    }));
  global_scope.declare("Object", func);
}

global_scope.declare("string", rt_object(rt_prototype_object,
  "char", rt_function(
    "char", ["cp"], function(self, cp) {
      cp = help_getnum(cp, "char codepoint");
      return rt_value("string", String.fromCodePoint(cp));
    }),
  "split", rt_function(
    "split", ["str", "sep"], function(self, str, sep) {
      str = rt_tostr(str).value;
      sep = rt_tostr(sep).value;
      return rt_array(str.split(sep).map(x => rt_value("string", x)));
    }),
  "has", rt_function(
    "has", ["str", "occ"], function(self, str, occ) {
      str = rt_tostr(str).value;
      occ = rt_tostr(occ).value;
      return rt_value("bool", str.includes(occ));
    }),
  "repl", rt_function(
    "repl", ["str", "target", "after"], function(self, str, target, after) {
      str = rt_tostr(str).value;
      target = target.regex ?? rt_tostr(target).value;
      after = rt_tostr(after).value;
      return rt_value("string", str.replaceAll(target, after));
    }),
  "pad_evline", rt_function(
    "pad_evline", ["str", "pad"], function(self, str, pad) {
      str = rt_tostr(str).value;
      pad = rt_tostr(pad).value;
      return rt_value("string", str.replace(/^/gm, pad));
    }),
));

{
  const queue = [path.join(import.meta.dirname, "core")];
  let deferred_files = new Map();
  while(queue.length) {
    const w = queue.pop();
    if (filesystem.existsSync(w, { isFile: true })) {
      if (!w.endsWith(".rp")) continue;
      
      const source = Deno.readTextFileSync(w);
      
      let dscope;
      try {
        dscope = interpret_source(false, source, [], w);
        deferred_files.delete(w);
      } catch(e) {
        if(!(e instanceof ReferenceError)) throw e;
        
        const retries = (deferred_files.get(w) ?? 0)+1;
        if(retries>50) {
          console.error(`unresolvable circular or missing dependency in: ${w}`);
          Deno.exit(1);
        }
        
        deferred_files.set(w, retries);
        queue.unshift(w);
        continue;
      }
      
      for(const [name, value] of dscope.exports.entries()) {
        global_scope.declare(name, value, true);
      }
      continue;
    }
    
    if(!filesystem.existsSync(w, { isDirectory: true })) continue;
    
    for(const node of Deno.readDirSync(w)) {
      queue.push(path.join(w, node.name));
    }
  }
}

export function interpret_source(is_main, code, args, path) {
  try {
    const program = new Parser().parse(code);
    analyzeAST(program);
  
    const scope = new Scope();
    scope.__filename = path;
    scope.__dirname = path.slice(0, path.lastIndexOf("/"));
  
    evaluate_node(program, scope);
    
    if(!is_main) return scope;
    
    const main = scope.get("main", false);
    if(!main || main.tag!=="function") {
      rt_error("can't find 'main' function");
    }
    args = rt_array(args.map(a => rt_value("string", a)));
    rt_call(main, rt_nil, args);
    return scope;
  } catch(e) {
    console.log(`\x1b[1;31merror: ${e.message}\n  at ${path}\x1b[0m`);
    console.log(`\x1b[2;38;5;244m${e.stack.slice(e.name.length+e.message.length+3).replace(/^    /gm, "  ")}\x1b[0m`);
    throw e;
  }
}
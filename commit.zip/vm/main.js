import * as path from "jsr:@std/path";
import * as filesystem from "jsr:@std/fs";
import { compile_source } from "./compiler.js";

export let global_scope;

const tochar = String.fromCharCode;
const fromchar = x => x.charCodeAt(0);

function debug(x) {
  console.log(x);
  return x;
}

export const Opcode = { Magic: "\x3b\xe6\x45\xb9" };
export const OpcodeName = {};

{
  let j = 0;
  [
    "BinaryString",
    "UTF8String",
    
    "PushInt16",
    "PushInt32",
    "PushFloat",
    "PushTrue",
    "PushFalse",
    "PushNaN",
    "PushNil",
    
    "Return",
    "ReturnVal",
    "JumpIfNot",
    "Jump",
    "BackIf",
    
    "PopStack",
    "CopyStack",
    "LoadString",
    "Load",
    "PushScope",
    "PopScope",
    
    "AccessMember",
    "Call",
    "CallWithSelf",
    
    "DecVar",
    "DecConst",
    "DecFunction",
    "AssignVar",
    "SetIndex",
    "SetIndexDyn",
    
    "BoAdd",
    "BoSub",
    "BoMul",
    "BoDiv",
    "BoIDiv",
    "BoMod",
    "BoPow",
    "BoConcat",
    "BoLT",
    "BoLTE",
    "BoGT",
    "BoGTE",
    "BoEQ",
    "BoNEQ",
    
    "UoMinus",
    "UoNot",
  ].map((i) => {
    let d;
    do {
      d = tochar(j++);
    } while(/[ \f\n\r\ta-zA-Z0-9]/.test(d));
    Opcode[i] = d;
    OpcodeName[d] = i;
  });
}

export const OpcodeToBinOper = new Map([
  [Opcode.BoAdd, "+"],
  [Opcode.BoSub, "-"],
  [Opcode.BoMul, "*"],
  [Opcode.BoDiv, "/"],
  [Opcode.BoIDiv, "//"],
  [Opcode.BoMod, "%"],
  [Opcode.BoPow, "^"],
  [Opcode.BoConcat, ".."],
  [Opcode.BoLT, "<"],
  [Opcode.BoLTE, "<="],
  [Opcode.BoGT, ">"],
  [Opcode.BoGTE, ">="],
  [Opcode.BoEQ, "=="],
  [Opcode.BoNEQ, "!="],
]);

export const BinOperToOpcode = new Map([
  ["+", Opcode.BoAdd],
  ["-", Opcode.BoSub],
  ["*", Opcode.BoMul],
  ["/", Opcode.BoDiv],
  ["//", Opcode.BoIDiv],
  ["%", Opcode.BoMod],
  ["^", Opcode.BoPow],
  ["..", Opcode.BoConcat],
  ["<", Opcode.BoLT],
  ["<=", Opcode.BoLTE],
  [">", Opcode.BoGT],
  [">=", Opcode.BoGTE],
  ["==", Opcode.BoEQ],
  ["!=", Opcode.BoNEQ],
]);

export const OpcodeToUnOper = new Map([
  [Opcode.UoMinus, "-"],
  [Opcode.UoNot, "!"],
]);

export const UnOperToOpcode = new Map([
  ["-", Opcode.UoMinus],
  ["!", Opcode.UoNot],
]);

export class Scope {
  syms = new Map();
  consts = new Set();
  constructor(parent = false) {
    if(parent) {
      this.parent = parent;
      this.root = parent.root;
      this.exports = parent.exports;
    } else {
      this.parent = global_scope;
      this.root = this;
      this.string_pool = [];
      this.stack = [];
      this.exports = new Map();
    }
  }
  add_export(name, value) {
    this.exports.set(name, value);
  }
  declare(name, value, is_const = false) {
    if(this.syms.has(name)) {
      throw new TypeError(`redefinition of '${name}' is not allowed`);
    }
    if(is_const) this.consts.add(name);
    return this.syms.set(name, value);
  }
  assign(name, value) {
    const scope = this.lookup(name);
    if(!scope) {
      throw new ReferenceError(`'${name}' is not defined`);
    }
    if(scope.consts.has(name)) {
      throw new TypeError(`assignment to constant '${name}' is not allowed`);
    }
    return scope.syms.set(name, value);
  }
  get(name, crash = true) {
    const scope = this.lookup(name);
    if(!scope) {
      if(!crash) return null;
      rt_error(`'${name}' is not defined`);
    }
    return scope.syms.get(name);
  }
  lookup(name) {
    if(this.syms.has(name)) return this;
    if(this.parent) return this.parent.lookup(name);
    return null;
  }
}

global_scope = new Scope();

function stypeof(x) {
  if(x===null) return "null";
  return typeof x;
}

function rt_error(msg) {
  throw new Error(msg);
}

function rt_value(tag, value) {
  return { tag, value };
}

let rt_nil, rt_nan, rt_true, rt_false,
  rt_prototype_array,
  rt_prototype_object,
  rt_prototype_function,
  rt_prototype_regex;

function rt_object(proto, ...props) {
  const keys = new Map();
  const len = props.length-props.length%2;
  for(let i = 0; i<len; i += 2) {
    keys.set(props[i], props[i+1]);
  }
  return { tag: "object", proto, keys, name: "object" };
}

function rt_regex(regex) {
  const rg = rt_object(rt_prototype_regex);
  rg.regex = regex;
  rg.name = "regex";
  return rg;
}

function rt_tostr(val) {
  if(val.tag==="string") return val;
  if(val.tag==="number") {
    if(Number.isNaN(val.value)) {
      return rt_value("string", "nan");
    }
    if(Number.isFinite(val.value)) {
      return rt_value("string", ""+val.value);
    }
    return rt_value("string", val.val>0 ? "inf" : "-inf");
  } 
  if(val.tag==="bool" || val.tag==="nil") {
    return rt_value("string", ""+val.value);
  }
  
  const f = rt_meta_index(val, "__tostr");
  if(f===rt_nil) rt_error(`can't convert ${val.tag} to string`);
  
  const res = rt_call(f, val);
  if(res.tag!=="string") rt_error("function '__tostr' must return a string");
  return res;
}

function rt_index(obj, prop) {
  if(obj===rt_nil) {
    rt_error("can't index nil value");
  }
  if(stypeof(prop)!=="string") {
    prop = rt_tostr(prop).value;
  }
  while(obj && (obj.tag==="object" || obj.tag==="function")) {
    const val = obj.keys.get(prop);
    if(val) return val;
    obj = obj.proto;
  }
  return rt_nil;
}
function rt_set_index(obj, prop, val) {
  if(obj===rt_nil) {
    rt_error("can't set index of nil value");
  }
  if(obj.tag!=="object" && obj.tag!=="function") {
    rt_error(`can't set index of ${obj.tag}`);
  }
  if(stypeof(prop)!=="string") {
    prop = rt_tostr(prop).value;
  }
  obj.keys.set(prop, val);
  return rt_nil;
}

function to_rt_value(val) {
  const t = stypeof(val);
  if(t==="null" || t==="undefined") return rt_nil;
  if(t==="boolean") return val ? rt_true : rt_false;
  if(t==="number") {
    if(Number.isNaN(val)) return rt_nan;
    return rt_value("number", val);
  }
  if(t==="string") return rt_value("string", val);
  return rt_nil;
}

function rt_function(name, params, body, variadic=-1, scope=null) {
  const obj = rt_object(
    rt_prototype_function,
    "name", to_rt_value(name)
  );
  obj.tag = "function";
  obj.body = body;
  obj.params = params;
  obj.variadic = variadic;
  obj.size = params.length;
  obj.scope = scope;
  return obj;
}

rt_nil = rt_value("nil", "nil");
rt_nan = rt_value("number", NaN);
rt_true = rt_value("bool", true);
rt_false = rt_value("bool", false);

rt_prototype_object = rt_object(rt_nil);
rt_prototype_function = rt_object(rt_prototype_object);

rt_set_index(
  rt_prototype_object,
  "__tostr", rt_function(
    "__tostr", [],
    function(self) {
      return rt_value("string", `[object ${self.name}]`);
    }
  )
);

rt_set_index(
  rt_prototype_function,
  "__tostr", rt_function(
    "__tostr", [],
    function(self) {
      const name = rt_tostr(rt_index(self, "name")).value;
      return rt_value("string", `[fun${name ? ` ${name}` : ""}]`);
    }
  )
);
rt_set_index(
  rt_prototype_function,
  "__len", rt_function(
    "__len", [],
    function(self) {
      return rt_value("number", self.size);
    }
  )
);
rt_set_index(
  rt_prototype_function,
  "apply", rt_function(
    "apply", ["vself", "args"],
    function(self, vself, args) {
      const argv = [];
      const len = rt_len(args).value;
      for(let i = 0; i<len; ++i) {
        argv.push(rt_index(args, ""+i));
      }
      return rt_call(self, vself, ...argv);
    },
    1
  )
);

rt_prototype_array = rt_object(rt_prototype_object,
  "__tostr", rt_function(
    "__tostr", [],
    function(self) {
      const len = rt_len(self).value;
      
      let res = "";
      for(let i = 0; i<len;) {
        res += rt_tostr(rt_index(self, ""+i)).value;
        if(++i<len) res += ", ";
      }
      return rt_value("string", res);
    }),
  "__len", rt_function(
    "__len", [],
    function(self) {
      let i = 0;
      while(rt_index(self, ""+i)!==rt_nil) ++i;
      return rt_value("number", i);
    }),
  "join", rt_function(
    "join", ["sep"],
    function(self, sep) {
      sep = rt_tostr(sep).value;
      const len = rt_len(self).value;
      
      let res = "";
      for(let i = 0; i<len;) {
        res += rt_tostr(rt_index(self, ""+i)).value;
        if(++i<len) res += sep;
      }
      return rt_value("string", res);
    }),
  "has", rt_function(
    "has", ["occ"],
    function(self, occ) {
      const len = rt_len(self).value;
      
      for(let i = 0; i<len; ++i) {
        const e = rt_index(self, ""+i);
        if(rt_eq(e, occ).value) return rt_true;
      }
      return rt_false;
    }),
  "push", rt_function(
    "push", ["val"],
    function(self, val) {
      const len = rt_len(self).value;
      rt_set_index(self, ""+len, val);
      return rt_value("number", len+1);
    }),
  "map", rt_function(
    "map", ["func"],
    function(self, func) {
      const len = rt_len(self).value;
      
      const arr = rt_array([]);
      for(let i = 0; i<len; ++i) {
        const e = rt_index(self, ""+i);
        const v = rt_value("number", i);
        rt_set_index(arr, ""+i, rt_call(func, rt_nil, e, v));
      }
      return arr;
    }),
  "mapto", rt_function(
    "mapto", ["func"],
    function(self, func) {
      const len = rt_len(self).value;
      
      for(let i = 0; i<len; ++i) {
        const e = rt_index(self, ""+i);
        const v = rt_value("number", i);
        rt_set_index(self, ""+i, rt_call(func, rt_nil, e, v));
      }
    }),
);

rt_prototype_regex = rt_object(rt_prototype_object,
  "__tostr", rt_function("__tostr", [], function(self) {
    return rt_value("string", self.regex.toString());
  }),
  "test", rt_function("test", ["str"], function(self, str) {
    str = rt_tostr(str).value;
    return rt_value("bool", self.regex.test(str));
  }),
);

function rt_array(idxs) {
  const obj = rt_object(rt_prototype_array);
  for(let i = 0; i<idxs.length; ++i) {
    rt_set_index(obj, ""+i, idxs[i]);
  }
  return obj;
}

function rt_call(func, self, ...args) {
  if(func.tag==="nil") {
    rt_error("can't call nil value");
  }
  if(func.tag!=="function") {
    const d = rt_meta_index(func, "__call");
    if(!d || d===rt_nil) rt_error(`can't call ${func.tag}`);
    if(d.tag!=="function") rt_error("property '__call' must be a function");
    func = d;
  }
  const variadic = func.variadic;
  if(args.length<func.size) {
    let len = func.size;
    if(variadic>=0) len = variadic;
    while(args.length<len) args.push(rt_nil);
    /*const name = rt_tostr(rt_index(func, "name")).value;
    rt_error(`can't call '${name}' with ${args.length} arguments`);*/
  }
  const arg_list = rt_array(args);
  if(variadic>=0) {
    const vari = rt_array(args.slice(variadic));
    args = args.slice(0, variadic);
    args[variadic] = vari;
  }
  if(stypeof(func.body)==="function") {
    return func.body(self, ...args) ?? rt_nil;
  }
  const fscope = new Scope(func.scope);
  for(let i = 0; i<func.size; ++i) {
    fscope.declare(func.params[i], args[i]);
  }
  fscope.declare("self", self, true);
  fscope.declare("arguments", arg_list, true);
  try {
    evaluate_program(func.body, fscope, false);
  } catch(e) {
    if(e instanceof ReturnSignal) return e.value;
    throw e;
  }
  return rt_nil;
}

function rt_len(val) {
  if(val.tag==="string") return rt_value("number", val.value.length);
  if(val.tag==="nil") rt_error("can't get length of nil value");
  if(val.tag==="bool") rt_error("can't get length of bool");
  if(val.tag==="number") rt_error("can't get length of number");
  
  const f = rt_meta_index(val, "__len");
  if(f===rt_nil) rt_error(`can't get length of ${val.tag}`);
  
  const res = rt_call(f, val);
  if(res.tag!=="number") rt_error("function '__len' must return a number");
  return res;
}
function rt_is_truthy(val) {
  if(val===rt_nil) return false;
  if(val.tag==="bool") return val.value;
  return true;
}
function rt_eq(left, right) {
  if(
    (left.tag==="object" && right.tag==="object")
    || (left.tag==="function" && right.tag==="function")
  ) {
    return rt_value("bool", left===right);
  }
  return rt_value("bool", left.tag===right.tag && left.value===right.value);
}
function rt_neq(left, right) {
  if(
    (left.tag==="object" && right.tag==="object")
    || (left.tag==="function" && right.tag==="function")
  ) {
    return rt_value("bool", left!==right);
  }
  return rt_value("bool", left.tag!==right.tag || left.value!==right.value);
}

const rt_binop_name = new Map([
  ["+", "__add"],
  ["-", "__sub"],
  ["*", "__mul"],
  ["/", "__div"],
  ["//", "__idiv"],
  ["%", "__mod"],
  ["^", "__pow"],
  ["<", "__lt"],
  ["<=", "__lte"],
  [">", "__gt"],
  [">=", "__gte"],
]);
function rt_binop(op, left, right) {
  if(op==="..") return rt_value("string", rt_tostr(left).value+rt_tostr(right).value);
  if(op==="&&") return rt_value("bool", rt_is_truthy(left)&&rt_is_truthy(right));
  if(op==="||") return rt_value("bool", rt_is_truthy(left)||rt_is_truthy(right));
  if(op==="==") return rt_eq(left, right);
  if(op==="!=") return rt_neq(left, right);
  
  if(left.tag==="number" && right.tag==="number") {
    switch(op) {
      case "+": return rt_value("number", left.value+right.value);
      case "-": return rt_value("number", left.value-right.value);
      case "*": return rt_value("number", left.value*right.value);
      case "/": return rt_value("number", left.value/right.value);
      case "//": return rt_value("number", Math.trunc(left.value/right.value));
      case "%": return rt_value("number", left.value%right.value);
      case "^": return rt_value("number", left.value**right.value);
      
      case "<": return rt_value("bool", left.value<right.value);
      case "<=": return rt_value("bool", left.value<=right.value);
      case ">": return rt_value("bool", left.value>right.value);
      case ">=": return rt_value("bool", left.value>=right.value);
    }
  }
  const nop = rt_binop_name.get(op);
  if(!nop) rt_error(`unknown operation '${op}'`);
  
  let f = rt_meta_index(left, nop);
  if(f===rt_nil) f = rt_meta_index(right, nop);
  if(f===rt_nil) {
    rt_error(`can't do '${op}' binary operation with ${left.tag} and ${right.tag}`);
  }
  return rt_call(f, rt_nil, left, right);
}
const rt_unop_name = new Map([
  ["-", "__unm"],
  ["!", "__not"]
]);
function rt_unop(op, val) {
  if(op==="#") return rt_len(val);
  
  if(val.tag==="number" && op==="-") {
    return rt_value("number", -val.value);
  }
  if(val.tag==="bool" && op==="!") {
    return rt_value("bool", !val.value);
  }
  
  const nop = rt_unop_name.get(op);
  if(!nop) {
    if(op==="!") return rt_value("bool", !rt_is_truthy(val));
    rt_error(`unknown operation '${op}'`);
  }
  
  const f = rt_meta_index(val, nop);
  if(f===rt_nil) rt_error(`can't do '${op}' binary operation with ${val.tag}`);
  
  return rt_call(f, val);
}

function rt_meta_index(obj, prop) {
  if(obj.tag!=="object" && obj.tag!=="function") return rt_nil;
  if(!obj.proto || obj.proto===rt_nil) return rt_nil;
  return rt_index(obj.proto, prop);
}

function help_getnum(x, msg) {
  if(x.tag!=="number") {
    rt_error(`${msg} must be a number but found ${x.tag} instead`);
  }
  return x.value;
}

class ReturnSignal extends SyntaxError {
  constructor(val = rt_nil) {
    super("return-statement ouside function body");
    this.value = val;
  }
}


const rt_h_break = new SyntaxError("break-statement outside loop");
const rt_h_continue = new SyntaxError("continue-statement outside loop");

const rt_rni = new Map([
  ["core/math.rex/sqrt", (self, x) => {
    x = help_getnum(x, "value");
    return rt_value("number", Math.sqrt(x));
  }],
  ["core/math.rex/exp", (self, x) => {
    x = help_getnum(x, "value");
    return rt_value("number", Math.exp(x));
  }],
  ["core/math.rex/log", (self, base, x) => {
    base = help_getnum(base, "logarithm base");
    x = help_getnum(x, "value");
    return rt_value("number", Math.log(x)/Math.log(base));
  }],
  ["core/math.rex/ln", (self, x) => {
    x = help_getnum(x, "value");
    return rt_value("number", Math.log(x));
  }],
  ["core/math.rex/lb", (self, x) => {
    x = help_getnum(x, "value");
    return rt_value("number", Math.log2(x));
  }],
  ["core/math.rex/lg", (self, x) => {
    x = help_getnum(x, "value");
    return rt_value("number", Math.log10(x));
  }],
  ["core/math.rex/cos", (self, x) => {
    x = help_getnum(x, "value");
    return rt_value("number", Math.cos(x));
  }],
  ["core/math.rex/sin", (self, x) => {
    x = help_getnum(x, "value");
    return rt_value("number", Math.sin(x));
  }],
  ["core/math.rex/floor", (self, x) => {
    x = help_getnum(x, "value");
    return rt_value("number", Math.floor(x));
  }],
  ["core/math.rex/ceil", (self, x) => {
    x = help_getnum(x, "value");
    return rt_value("number", Math.ceil(x));
  }],
  ["core/math.rex/fract", (self, x) => {
    x = help_getnum(x, "value");
    return rt_value("number", x-Math.floor(x));
  }],
  ["core/math.rex/trunc", (self, x) => {
    x = help_getnum(x, "value");
    return rt_value("number", Math.trunc(x));
  }],
  ["core/random.rex/rf", (self, x) => {
    if(x===rt_nil) x = 1;
    else x = help_getnum(x, "random scale");
    return rt_value("number", x*Math.random());
  }],
  ["core/random.rex/crf", (self, x) => {
    if(x===rt_nil) x = 1;
    else x = help_getnum(x, "random scale");
    const sample = new Uint32Array(1);
    crypto.getRandomValues(sample);
    return rt_value("number", x*sample[0]/0x100000000);
  }],
  ["core/random.rex/ri", (self, min, max) => {
    if(min!==rt_nil && max===rt_nil) {
      min = help_getnum(min, "random max interval");
      return rt_value("number", Math.floor((min+1)*Math.random()));
    }
    min = help_getnum(min, "random min interval");
    max = help_getnum(max, "random max interval");
    if(min===max) return rt_value("number", min);
    return rt_value("number", Math.floor(min+(max-min+1)*Math.random()));
  }],
  ["core/random.rex/cri", (self, min, max) => {
    if(min!==rt_nil && max===rt_nil) {
      min = help_getnum(min, "random max interval");
      return rt_value("number", Math.floor((min+1)*Math.random()));
    }
    min = help_getnum(min, "random min interval");
    max = help_getnum(max, "random max interval");
    if(min===max) return rt_value("number", min);
    
    const range = max-min;
    const limit = Math.floor(2**32/range)*range;
    const sample = new Uint32Array(1);
    do {
      crypto.getRandomValues(sample);
    } while (sample[0]>=limit);
    return rt_value("number", min+(sample[0]%range));
  }],
  ["core/random.rex/cris", (self, size) => {
    size = help_getnum(size, "array size");
    if(size<1) rt_error("array size must be greater than 0");
    
    let samples = new Uint32Array(size);
    crypto.getRandomValues(samples);
    
    samples = Array.from(samples);
    samples = samples.map(x => rt_value("number", x));
    return rt_array(samples);
  }],
  ["core/random.rex/uuid", (self) => {
    return rt_value("string", crypto.randomUUID());
  }],
]);

function raw_prompt() {
  Deno.stdin.setRaw(true);
  const buf = new Uint8Array(1024);
  let input = "";
  try {
    while(true) {
      const n = Deno.stdin.readSync(buf);
      if(n===null || n===0) break;
      const char = new TextDecoder().decode(buf.subarray(0, n));
      if(char==="\x03") {
        process.stdout.write("^C\n");
        Deno.exit(130);
      }
      if(char==="\x04") {
        process.stdout.write("^D\n");
        break;
      }
      if(char==="\r" || char==="\n") {
        process.stdout.write("\n");
        break;
      }
      if(char==="\x7f" || char==="\x08") {
        if(input.length>0) {
          input = input.slice(0, -1);
          process.stdout.write("\x08 \x08");
        }
        continue;
      }
  
      if(char.charCodeAt(0)<32 && char!=="\t") continue;
      input += char;
      process.stdout.write(char);
    }
  } finally {
    Deno.stdin.setRaw(false);
  }
  if(!input.length) return null;
  return input;
}

global_scope.declare("typeof",
  rt_function("typeof", ["val"], function(self, val) {
    return rt_value("string", val.tag);
  }),
  true
)
global_scope.declare("error",
  rt_function("typeof", ["msg"], function(self, msg) {
    rt_error(rt_tostr(msg).value);
  }),
  true
)
global_scope.declare("tostring",
  rt_function("typeof", ["val"], function(self, val) {
    return rt_tostr(val);
  }),
  true
)
global_scope.declare("instanceof",
  rt_function("instanceof", ["ins", "proto"], function(self, ins, proto) {
    if(proto.tag!=="function" || ins.tag!=="object") return rt_false;
    proto = rt_index(proto, "prototype");
    ins = ins.proto;
    while(ins && ins!==rt_nil) {
      if(ins===proto) return rt_true;
      ins = ins.proto;
    }
    return rt_false;
  }),
  true
)

{
  const sys = rt_object(rt_prototype_object,
    "read", rt_function(
      "read", ["msg"], function(self, msg) {
        if(msg!==rt_nil) {
          process.stdout.write(rt_tostr(msg).value);
        }
        const out = raw_prompt();
        if(!out) return rt_nil;
        return rt_value("string", out);
      }),
    "confirm", rt_function(
      "confirm", ["msg"], function(self, msg) {
        if(msg!==rt_nil) {
          process.stdout.write(rt_tostr(msg).value+" [Y/n] ");
        } else {
          process.stdout.write("confirm? [Y/n] ");
        }
        const out = raw_prompt();
        if(!out) return rt_nil;
        return rt_value("string", out);
      }),
    "sleep", rt_function(
      "sleep", ["ms"], function(self, ms) {
        ms = help_getnum(ms, "sleep time");
        if(ms<0) {
          rt_error("can't sleep for negative milliseconds");
        }
        const sab = new SharedArrayBuffer(4);
        const int32 = new Int32Array(sab);
        Atomics.wait(int32, 0, 0, ms);
      }),
    "exit", rt_function(
      "exit", ["code"], function(self, code) {
        code = help_getnum(code, "exit code");
        Deno.exit(code);
      }),
    "writeln", rt_function(
      "writeln", ["data"], function(self, data) {
        process.stdout.write(rt_tostr(data).value+"\n");
      }),
    "write", rt_function(
      "write", ["data"], function(self, data) {
        process.stdout.write(rt_tostr(data).value);
      }),
  );
  sys.name = "sys";
  global_scope.declare("sys", sys, true);
}

{
  const func = rt_function("Array", ["array"], function(self, array) {
    if(array.tag!=="object") return;
    const len = rt_len(array).value;
    for(let i = 0; i<len; ++i) {
      rt_set_index(self, ""+i, rt_index(array, ""+i));
    }
  });
  rt_set_index(func, "prototype", rt_prototype_array);
  global_scope.declare("Array", func);
}

{
  const func = rt_function("RegExp", ["array"], function(self, pattern, flags) {
    pattern = rt_tostr(pattern).value;
    flags = rt_tostr(flags).value;
    self.regex = new RegExp(pattern, flags);
  });
  rt_set_index(func, "prototype", rt_prototype_regex);
  global_scope.declare("RegExp", func);
}

{
  const func = rt_function("Object", ["obj"], function(self, obj) {
    if(obj.tag!=="object") return;
    for(const [key, value] of obj.keys.entries()) {
      rt_set_index(self, key, value);
    }
  });
  rt_set_index(func, "get_proto", rt_function(
    "get_proto", ["obj"], function(self, obj) {
      return obj.proto ?? rt_nil;
    }));
  rt_set_index(func, "prototype", rt_prototype_object);
  rt_set_index(func, "entries", rt_function(
    "entries", ["obj"], function(self, obj) {
      if(obj.tag!=="object") {
        rt_error("can't get entries of "+obj.tag);
      }
      return rt_array([...obj.keys.entries()].map(([key, val]) => {
        return rt_array([rt_value("string", key), val]);
      }));
    }));
  global_scope.declare("Object", func);
}

global_scope.declare("string", rt_object(rt_prototype_object,
  "char", rt_function(
    "char", ["cp"], function(self, cp) {
      cp = help_getnum(cp, "char codepoint");
      return rt_value("string", String.fromCodePoint(cp));
    }),
  "split", rt_function(
    "split", ["str", "sep"], function(self, str, sep) {
      str = rt_tostr(str).value;
      sep = rt_tostr(sep).value;
      return rt_array(str.split(sep).map(x => rt_value("string", x)));
    }),
  "has", rt_function(
    "has", ["str", "occ"], function(self, str, occ) {
      str = rt_tostr(str).value;
      occ = rt_tostr(occ).value;
      return rt_value("bool", str.includes(occ));
    }),
  "repl", rt_function(
    "repl", ["str", "target", "after"], function(self, str, target, after) {
      str = rt_tostr(str).value;
      target = target.regex ?? rt_tostr(target).value;
      after = rt_tostr(after).value;
      return rt_value("string", str.replaceAll(target, after));
    }),
  "pad_evline", rt_function(
    "pad_evline", ["str", "pad"], function(self, str, pad) {
      str = rt_tostr(str).value;
      pad = rt_tostr(pad).value;
      return rt_value("string", str.replace(/^/gm, pad));
    }),
));

if(false) {
  const queue = [path.join(import.meta.dirname, "core")];
  let deferred_files = new Map();
  while(queue.length) {
    const w = queue.pop();
    if(filesystem.existsSync(w, { isFile: true })) {
      if(w.endsWith(".rp")) {
        const source = Deno.readTextFileSync(w);
        Deno.readFileSync(w.slice(0, -3)+".rex", compile_source(source, w));
        continue;
      }
      
      if(!w.endsWith(".rex")) continue;
      
      const source = Deno.readTextFileSync(w);
      
      let dscope;
      try {
        dscope = interpret_source(false, source, [], w);
        deferred_files.delete(w);
      } catch(e) {
        if(!(e instanceof ReferenceError)) throw e;
        
        const retries = (deferred_files.get(w) ?? 0)+1;
        if(retries>50) {
          console.error(`unresolvable circular or missing dependency in: ${w}`);
          Deno.exit(1);
        }
        
        deferred_files.set(w, retries);
        queue.unshift(w);
        continue;
      }
      
      for(const [name, value] of dscope.exports.entries()) {
        global_scope.declare(name, value, true);
      }
      continue;
    }
    
    if(!filesystem.existsSync(w, { isDirectory: true })) continue;
    
    for(const node of Deno.readDirSync(w)) {
      queue.push(path.join(w, node.name));
    }
  }
}

function evaluate_program(source, scope, check_magic) {
  const string_pool = scope.root.string_pool;
  const stack = scope.root.stack;
    
  let pc = 0;
  function uint16() {
    const hb = fromchar(source[pc++]);
    const lb = fromchar(source[pc++]);
    return (hb<<8)|lb;
  }
  function int16() {
    const hb = fromchar(source[pc++]);
    const lb = fromchar(source[pc++]);
    let x = (hb<<8)|lb;
    if(hb&128) x -= 0x10000;
    return x;
  }
  function int32() {
    const b0 = fromchar(source[pc++]);
    const b1 = fromchar(source[pc++]);
    const b2 = fromchar(source[pc++]);
    const b3 = fromchar(source[pc++]);
    let x = (b0<<24)|(b1<<16)|(b2<<8)|(b3);
    if(b0&128) x -= 0x100000000;
    return x;
  }
  function float64() {
    const buffer = new ArrayBuffer(8);
    const bytes = new Uint8Array(buffer);
    for(let i = 0; i<8; ++i)
      bytes[i] = fromchar(source[pc++]);
    const view = new DataView(buffer);
    return view.getFloat64(0, false); 
  }
  function string() {
    return string_pool[uint16()];
  }
  function evaluate(scope) {
    // console.log(OpcodeName[source[pc]]);
    
    if(OpcodeToBinOper.has(source[pc])) {
      const op = OpcodeToBinOper.get(source[pc++]);
      const right = stack.pop();
      const left = stack.pop();
      stack.push(rt_binop(op, left, right));
      return;
    }
    if(OpcodeToUnOper.has(source[pc])) {
      const op = OpcodeToUnOper.get(source[pc++]);
      stack.push(rt_unop(op, stack.pop()));
      return;
    }
    
    switch(source[pc++]) {
      case Opcode.BinaryString: {
        const len = uint16();
        string_pool.push(source.slice(pc, pc += len));
        break;
      }
      case Opcode.UTF8String: {
        const len = uint16();
        let str = Uint8Array.from(source.slice(pc, pc += len), fromchar);
        str = new TextDecoder().decode(str);
        string_pool.push(str);
        break;
      }
      
      case Opcode.PushInt16: {
        stack.push(rt_value("number", int16()));
        break;
      }
      case Opcode.PushInt32: {
        stack.push(rt_value("number", int32()));
        break;
      }
      case Opcode.PushFloat: {
        stack.push(rt_value("number", float64()));
        break;
      }
      case Opcode.PushTrue: {
        stack.push(rt_true);
        break;
      }
      case Opcode.PushFalse: {
        stack.push(rt_false);
        break;
      }
      case Opcode.PushNaN: {
        stack.push(rt_nan);
        break;
      }
      case Opcode.PushNil: {
        stack.push(rt_nil);
        break;
      }
      case Opcode.Return: {
        throw new ReturnSignal();
      }
      case Opcode.ReturnVal: {
        throw new ReturnSignal(stack.pop());
      }
      case Opcode.JumpIfNot: {
        const jump = uint16();
        if(!rt_is_truthy(stack.pop())) {
          pc += jump;
        }
        break;
      }
      case Opcode.Jump: {
        const jump = uint16();
        pc += jump;
        break;
      }
      case Opcode.BackIf: {
        const jump = uint16();
        if(rt_is_truthy(stack.pop())) {
          pc -= jump;
        }
        break;
      }
      
      case Opcode.PopStack: {
        stack.pop();
        break;
      }
      
      case Opcode.CopyStack: {
        stack.push(stack[stack.length-1]);
        break;
      }
      case Opcode.LoadString: {
        stack.push(rt_value("string", string()));
        break;
      }
      
      case Opcode.Load: {
        stack.push(scope.get(string()));
        break;
      }
      case Opcode.PushScope: {
        scope = new Scope(scope);
        break;
      }
      case Opcode.PopScope: {
        scope = scope.parent;
        break;
      }
      
      case Opcode.AccessMember: {
        const obj = stack.pop();
        const prop = string();
        stack.push(rt_index(obj, prop));
        break;
      }
      case Opcode.Call: {
        
      }
      case Opcode.CallWithSelf: {
        const func = stack.pop();
        const self = stack.pop();
        
        const argc = fromchar(source[pc++]);
        const args = argc===0 ? [] : stack.splice(-argc);
        
        stack.push(rt_call(func, self, ...args));
        break;
      }
      
      case Opcode.DecVar: {
        scope.declare(string(), stack.pop(), false);
        break;
      }
      case Opcode.DecConst: {
        scope.declare(string(), stack.pop(), true);
        break;
      }
      case Opcode.AssignVar: {
        const name = string();
        const val = stack.pop();
        scope.assign(name, val);
        stack.push(val);
        break;
      }
      case Opcode.SetIndex: {
        const prop = string();
        const val = stack.pop();
        const obj = stack.pop();
        rt_set_index(obj, prop, val);
        stack.push(val);
        break;
      }
      case Opcode.SetIndexDyn: {
        const val = stack.pop();
        const prop = stack.pop();
        const obj = stack.pop();
        stack.push(val);
        rt_set_index(obj, prop, val);
        break;
      }
      case Opcode.DecFunction: {
        const name = string();
        
        const params = [];
        const paramc = fromchar(source[pc++]);
        for(let i = 0; i<paramc; i++) {
          params.push(string());
        }
        
        let variadic = -1;
        if(fromchar(source[pc++])) {
          variadic = fromchar(source[pc++]);
        } else ++pc;
        
        const blen = int32();
        const body = source.slice(pc, pc += blen);
        scope.declare(name, rt_function(
          name, params, body, variadic, scope
        ), true);
        break;
      }
      
      default: {
        const op = fromchar(source[pc-1]).toString(16);
        rt_error(`unknown opcode: '0x${op.padStart(2, "0")}'`);
      }
    }
  }
  if(typeof source!=="string") source = tochar(...source);
  if(check_magic) {
    if(!source.startsWith(Opcode.Magic)) {
      rt_error("not a valid program");
    }
    pc += Opcode.Magic.length;
  }
  while(pc<source.length) evaluate(scope);
}

export function interpret_source(is_main, code, args, path) {
  try {
    const scope = new Scope();
    scope.__filename = path;
    scope.__dirname = path.slice(0, path.lastIndexOf("/"));
  
    evaluate_program(code, scope, true);
    
    if(!is_main) return scope;
    
    const main = scope.get("main", false);
    if(!main || main.tag!=="function") {
      rt_error("can't find 'main' function");
    }
    args = rt_array(args.map(a => rt_value("string", a)));
    rt_call(main, rt_nil, args);
    return scope;
  } catch(e) {
    console.log(`\x1b[1;31merror: ${e.message}\n  at ${path}\x1b[0m`);
    console.log(`\x1b[2;38;5;244m${e.stack.slice(e.name.length+e.message.length+3).replace(/^    /gm, "  ")}\x1b[0m`);
    throw e;
  }
}
# Runic
Runic will be a statically and strongly typed language that compiles it's code to a Runic Executable file (`.rex`) so it can be interpreted by the Sig Virtual Machine.

For now, Runic is just being transpiled to JavaScript, and it's still being worked on.

# Runic compiler roadmap
- [x] Lexer
- [x] Parser
- [x] Semantic Analyzer
- [x] Code Generation
- [ ] Sig Virtual Machine
- [ ] Code Optimization 
- [ ] Self-hosting
export const TokenKind = {
  String: "string",
  TemplateString: "template string",
  Number: "number",
  Identifier: "identifier",
  Bool: "boolean",
  Nil: "nil",
  NaN: "nan",
  Void: "void",
  New: "new",
  
  Star: "*", Slash: "/", Modulo: "%",
  DoubleSlash: "//", Caret: "^",
  Plus: "+", Dash: "-", Concat: "..",
  
  LessThan: "<", GreaterThan: ">",
  LessThanEqual: "<=", GreaterThanEqual: ">=",
  Equal: "==", NotEqual: "!=",
  
  LogicalAnd: "&&", LogicalOr: "||",
  
  LeftParen: "(",
  RightParen: ")",
  LeftBrace: "{",
  RightBrace: "}",
  LeftBracket: "[",
  RightBracket: "]",
  Semicolon: ";",
  Question: "?",
  Colon: ":",
  Path: "::",
  Bang: "!",
  Tilde: "~",
  Dot: ".",
  Comma: ",",
  
  Assign: "=",
  AssignAdd: "+=",
  AssignSub: "-=",
  AssignMul: "*=",
  AssignDiv: "/=",
  AssignIDiv: "//=",
  AssignMod: "%=",
  AssignCon: "..=",
  
  Native: "native",
  Package: "package",
  Import: "import",
  Export: "export",
  Function: "fun",
  Var: "var",
  For: "for",
  While: "while",
  If: "if",
  Elif: "elif",
  Else: "else",
  Return: "return",
  Break: "break",
  Continue: "continue",
  Enum: "enum",
};

const lexer_symbols = [
  ["..", TokenKind.Concat],
  ["+", TokenKind.Plus],
  ["-", TokenKind.Dash],
  ["*", TokenKind.Star],
  ["/", TokenKind.Slash],
  ["%", TokenKind.Modulo],
  ["//", TokenKind.DoubleSlash],
  ["^", TokenKind.Caret],
  
  ["<", TokenKind.LessThan],
  ["<=", TokenKind.LessThanEqual],
  [">", TokenKind.GreaterThan],
  [">=", TokenKind.GreaterThanEqual],
  ["==", TokenKind.Equal],
  ["!=", TokenKind.NotEqual],
  
  ["&&", TokenKind.LogicalAnd],
  ["||", TokenKind.LogicalOr],
  
  ["(", TokenKind.LeftParen],
  [")", TokenKind.RightParen],
  ["{", TokenKind.LeftBrace],
  ["}", TokenKind.RightBrace],
  ["[", TokenKind.LeftBracket],
  ["]", TokenKind.RightBracket],
  [";", TokenKind.Semicolon],
  [":", TokenKind.Colon],
  ["::", TokenKind.Path],
  ["?", TokenKind.Question],
  ["!", TokenKind.Bang],
  ["~", TokenKind.Tilde],
  [".", TokenKind.Dot],
  [",", TokenKind.Comma],
  
  ["=", TokenKind.Assign],
  ["+=", TokenKind.AssignAdd],
  ["-=", TokenKind.AssignSub],
  ["*=", TokenKind.AssignMul],
  ["/=", TokenKind.AssignDiv],
  ["//=", TokenKind.AssignIDiv],
  ["%=", TokenKind.AssignMod],
  ["..=", TokenKind.AssignCon],
].toSorted((i, j) => j[0].length-i[0].length);

const reserved_names = {
  "native": TokenKind.Native,
  "package": TokenKind.Package,
  "import": TokenKind.Import,
  "export": TokenKind.Export,
  "fun": TokenKind.Function,
  "var": TokenKind.Var,
  "for": TokenKind.For,
  "while": TokenKind.While,
  "if": TokenKind.If,
  "elif": TokenKind.Elif,
  "else": TokenKind.Else,
  "void": TokenKind.Void,
  "new": TokenKind.New,
  "return": TokenKind.Return,
  "break": TokenKind.Break,
  "continue": TokenKind.Continue,
  "enum": TokenKind.Enum,
  "nil": TokenKind.Nil,
  "nan": TokenKind.NaN,
};

// Lexer
export class Lexer {
  errorAtCode(msg, idx) {
    let col = 0, row = 0;
    for(let i = 0; i<=idx; ++i) {
      if(this.text[i]==="\n") {
        col = 0;
        ++row;
      } else {
        ++col;
      }
    }
    --col;
    throw new SyntaxError(`${row}:${col} → ${msg}`);
  }
  ended() {
    return this.idx>=this.text.length;
  }
  isAt(code) {
    return this.text.slice(this.idx, this.idx+code.length)==code;
  }
  consumeIgnorable() {
    if(/\s/.test(this.text[this.idx])) {
      while(!this.ended() && /\s/.test(this.text[this.idx])) ++this.idx;
      return true;
    }
    
    if(this.isAt("---")) {
      let start = this.idx;
      this.idx += 3;
      while(!this.ended() && !this.isAt("\n")) {
        ++this.idx;
      }
      return true;
    }
    if(this.isAt("-*")) {
      let start = this.idx, depth = 1;
      this.idx += 2;
      while(!this.ended() && depth) {
        if(this.isAt("*-")) ++this.idx, --depth;
        else if(this.isAt("-*")) ++this.idx, ++depth;
        ++this.idx;
      }
      if(depth) {
        this.errorAtCode(
          "multiline comment didn't found a closing pair → "
            +this.text.slice(start, this.idx),
          start
        );
      }
      return true;
    }
    return false;
  }
  // TODO: a better way to handle bases
  consumeNumbers(tokens) {
    // binary
    if(this.isAt("0b")) {
      const start = this.idx;
      this.idx += 2;
      let dots = 0;
      while(!this.ended() && /[01\.]/.test(this.text[this.idx])) {
        if(this.isAt(".")) {
          if(dots>0) {
            this.errorAtCode(
              "too many decimal points → "
                +this.text.slice(start, this.idx),
              start
            );
          }
          ++dots;
        }
        ++this.idx;
      }
      let is_float = dots>0;
      if(this.isAt("f")) {
        is_float = true;
        ++this.idx;
      }
      if(!this.ended() && /[\p{ID_Start}_]/u.test(this.text[this.idx])) {
        this.errorAtCode(
          "identifier is too close to number → "
            +this.text.slice(start, this.idx+1),
          start
        );
      }
      const raw = this.text.slice(start+2, this.idx);
      if(raw==="") {
        this.errorAtCode("expected characters after number base prefix → 0b", start);
      }
      
      let dec = raw.indexOf(".");
      dec = (dec===-1) ? 0 : (raw.length-1-dec);
      dec = 2**dec;
      const value = parseInt(raw.replace(".", ""), 2)/dec;
      
      tokens.push({
        kind: TokenKind.Number,
        start, end: this.idx,
        raw: ("0b"+raw), value,
        is_float
      });
      return true;
    }
    // octo
    if(this.isAt("0o")) {
      const start = this.idx;
      this.idx += 2;
      let dots = 0;
      while(!this.ended() && /[0-7\.]/.test(this.text[this.idx])) {
        if(this.isAt(".")) {
          if(dots>0) {
            this.errorAtCode(
              "too many decimal points → "
                +this.text.slice(start, this.idx),
              start
            );
          }
          ++dots;
        }
        ++this.idx;
      }
      let is_float = false;
      if(this.isAt("f")) {
        is_float = true;
        ++this.idx;
      }
      if(!this.ended() && /[\p{ID_Start}_]/u.test(this.text[this.idx])) {
        this.errorAtCode(
          "identifier is too close to number → "
            +this.text.slice(start, this.idx+1),
          start
        );
      }
      const raw = this.text.slice(start+2, this.idx);
      if(raw==="") {
        this.errorAtCode("expected characters after number base prefix → 0o", start);
      }
      
      let dec = raw.indexOf(".");
      dec = (dec===-1) ? 0 : (raw.length-1-dec);
      dec = 8**dec;
      const value = parseInt(raw.replace(".", ""), 8)/dec;
      
      tokens.push({
        kind: TokenKind.Number,
        start, end: this.idx,
        raw: ("0o"+raw), value,
        is_float
      });
      return true;
    }
    // hexa
    if(this.isAt("0x")) {
      const start = this.idx;
      this.idx += 2;
      let dots = 0;
      while(!this.ended() && /[0-9a-fA-F\.]/.test(this.text[this.idx])) {
        if(this.isAt(".")) {
          if(dots>0) {
            this.errorAtCode(
              "too many decimal points → "
                +this.text.slice(start, this.idx),
              start
            );
          }
          ++dots;
        }
        ++this.idx;
      }
      let is_float = false;
      if(this.isAt("f")) {
        is_float = true;
        ++this.idx;
      }
      if(!this.ended() && /[\p{ID_Start}_]/u.test(this.text[this.idx])) {
        this.errorAtCode(
          "identifier is too close to number → "
            +this.text.slice(start, this.idx+1),
            start
        );
      }
      const raw = this.text.slice(start+2, this.idx);
      if(raw==="") {
        this.errorAtCode("expected characters after number base prefix → 0x", start);
      }
      let dec = raw.indexOf(".");
      dec = (dec===-1) ? 0 : (raw.length-1-dec);
      dec = 16**dec;
      const value = parseInt(raw.replace(".", ""), 16)/dec;
      
      tokens.push({
        kind: TokenKind.Number,
        start, end: this.idx,
        raw: ("0x"+raw), value,
        is_float
      });
      return true;
    }
    // decimal
    if(
      /[0-9]/.test(this.text[this.idx])
      || (
        this.isAt(".")
        && (this.text.length<1
        || /[0-9]/.test(this.text[this.idx+1]))
      )
    ) {
      const start = this.idx;
      while(!this.ended() && /[0-9]/.test(this.text[this.idx])) ++this.idx;
      
      let is_float = false;
      if(this.isAt(".")) {
        is_float = true;
        ++this.idx;
        while(!this.ended() && /[0-9]/.test(this.text[this.idx])) ++this.idx;
      }
      if(this.isAt("e")) {
        ++this.idx;
        if(!this.isAt("+") && !this.isAt("-")) {
          this.errorAtCode(
            "expected exponential sign → "
              +this.text.slice(start, this.idx+1),
            start
          );
        }
        ++this.idx;
        if(this.ended() || !/[0-9]/.test(this.text[this.idx])) {
          this.errorAtCode(
            "expected exponential value → "
              +this.text.slice(start, this.idx+1),
            start
          );
        }
        while(!this.ended() && /[0-9]/.test(this.text[this.idx])) ++this.idx; 
      }
      
      if(this.isAt("f")) {
        is_float = true;
        ++this.idx;
      }
      
      if(!this.ended() && /[\p{ID_Start}_]/u.test(this.text[this.idx])) {
        this.errorAtCode(
          "identifier is too close to number → "
            +this.text.slice(start, this.idx+1),
          start
        );
      }
      const raw = this.text.slice(start, this.idx);
      const value = parseFloat(raw);
      tokens.push({
        kind: TokenKind.Number,
        start, end: this.idx,
        raw, value, is_float
      });
      return true;
    }
    return false;
  }
  consumeStrings(tokens) {
    if(this.isAt("`")) {
      let start = this.idx++;
      let value = "", is_head = true;
      while(!this.ended() && !this.isAt("`")) {
        if(this.isAt("\\")) {
          ++this.idx;
          if(this.ended()) {
            this.errorAtCode(
              "string didn't found a character after backslash escape → "
                +this.text.slice(start, this.idx),
              start
            );
          }
          const esc = this.text[this.idx++];
          switch(esc) {
            case "t": { value += "\t"; break; }
            case "r": { value += "\r"; break; }
            case "n": { value += "\n"; break; }
            case "b": { value += "\b"; break; }
            case "0": { value += "\0"; break; }
            case "\\": { value += "\\"; break; }
            case "`": { value += "`"; break; }
            
            case "{": {
              tokens.push({
                kind: TokenKind.TemplateString,
                raw: this.text.slice(start, this.idx-2),
                start, end: this.idx-2,
                value, is_head, is_tail: false
              });
              start = this.idx;
              is_head = false;
              value = "";
              while(!this.ended() && !this.isAt("}")) {
                this.consumeNext(tokens);
              }
              if(!this.isAt("}")) {
                this.errorAtCode(
                  "template string expression must end with a right brace → "
                    +this.text.slice(start, this.idx),
                  start
                );
              }
              ++this.idx;
              break;
            }
            
            case "u": {
              if(this.ended()) {
                this.errorAtCode(
                  "string didn't found a character after unicode escape → "
                    +this.text.slice(start, this.idx),
                  start
                );
              }
              let cdp = "";
              while(!this.ended() && /[0-9a-fA-F]/.test(this.text[this.idx])) {
                cdp += this.text[this.idx++];
                if(this.isAt(";")) {
                  ++this.idx;
                  break;
                }
              }
              value += String.fromCodePoint(parseInt(cdp, 16));
              break;
            }
            
            case "x": {
              if(this.idx+2>this.text.length) {
                this.errorAtCode(
                  "string didn't found enough characters after hexadecimal escape → "
                    +this.text.slice(start, this.idx),
                  start
                );
              }
              const code = this.text.slice(this.idx, this.idx += 2);
              const val = parseInt(code, 16);
              if(Number.isNaN(val)) {
                this.errorAtCode(`'${code}' is not a valid hexadecimal number`, start);
              }
              value += String.fromCodePoint(val);
              break;
            }
            
            default:
              this.errorAtCode(`'\\${esc}' is not a invalid character escape sequence`, this.idx);
          }
          continue;
        }
        value += this.text[this.idx++];
      }
      if(!this.isAt("`")) {
        this.errorAtCode(
          "string didn't found a closing pair → "
            +this.text.slice(start, this.idx),
          start
        );
      }
      tokens.push({
        kind: TokenKind.TemplateString,
        is_head,
        is_tail: true,
        value, raw: this.text.slice(start, ++this.idx),
        start, end: this.idx
      });
      return true;
    }
    if(this.isAt('"')) {
      const start = this.idx++;
      let value = "";
      while(!this.ended() && !this.isAt('"')) {
        if(this.isAt('\\"')) {
          value += '"';
          this.idx += 2;
          continue;
        }
        value += this.text[this.idx++];
      }
      if(!this.isAt('"')) {
        this.errorAtCode(
          "string didn't found a closing pair → "
            +this.text.slice(start, this.idx),
          start
        );
      }
      ++this.idx;
      tokens.push({
        kind: TokenKind.String,
        raw: this.text.slice(start, this.idx),
        value,
        start, end: this.idx
      });
      return true;
    }
    return false;
  }
  consumeIdentifier(tokens) {
    if(/[\p{ID_Start}_]/u.test(this.text[this.idx])) {
      const start = this.idx;
      while(!this.ended() && /[\p{ID_Continue}]/u.test(this.text[this.idx])) {
        ++this.idx;
      }
      const raw = this.text.slice(start, this.idx);
      if(raw==="true" || raw==="false") {
        tokens.push({
          kind: TokenKind.Bool,
          value: raw==="true",
          start, end: this.idx,
          raw
        });
        return true; 
      }
      if(reserved_names.hasOwnProperty(raw)) {
        const kind = reserved_names[raw];
        tokens.push({
          kind,
          start, end: this.idx,
          raw
        });
      } else {
        tokens.push({
          kind: TokenKind.Identifier,
          start, end: this.idx,
          raw, name: raw
        });
      }
      return true;
    }
    return false;
  }
  consumeSymbols(tokens) {
    for(const [raw, kind] of lexer_symbols) {
      if(!this.isAt(raw)) continue;
      tokens.push({
        kind, raw,
        start: this.idx,
        end: (this.idx += raw.length)
      });
      return true;
    }
    return false;
  }
  consumeNext(tokens) {
    if(this.consumeIgnorable()) return;
    if(this.consumeNumbers(tokens)) return;
    if(this.consumeStrings(tokens)) return;
    if(this.consumeIdentifier(tokens)) return;
    if(this.consumeSymbols(tokens)) return;
    
    this.errorAtCode(`the character '${cur_at}' was not expected to be read on the input.`, this.idx);
  }
  
  lex(input) {
    this.text = input;
    this.idx = 0;
    
    const tokens = [];
    while(!this.ended()) {
      this.consumeNext(tokens);
    }
    return tokens;
  }
}
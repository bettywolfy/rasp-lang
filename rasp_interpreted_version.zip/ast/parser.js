import { Lexer, TokenKind } from "./lexer.js";

export const NodeKind = {
  Package: "package",
  Import: "import",
  Export: "export",
  
  Program: "program",
  NumberLiteral: "number literal",
  StringLiteral: "string literal",
  TemplateString: "template string",
  BoolLiteral: "boolean literal",
  NilLiteral: "nil literal",
  NaNLiteral: "nan literal",
  Identifier: "identifier",
  
  Ternary: "ternary expression",
  BinaryExpr: "binary expression",
  UnaryExpr: "unary expression",
  MemberExpr: "member expression",
  IndexExpr: "index expression",
  CallExpr: "call expression",
  ArrayExpr: "array expression",
  
  ExprStmt: "expression statement",
  FunctionDef: "function definition",
  Lambda: "lambda function",
  VarDef: "variable definition",
  VarAssign: "variable assignment",
  ForStmt: "for-statement",
  IfStmt: "if-statement",
  ElseStmt: "else-statement",
  While: "while-statement",
  Block: "block",
  BlockStmt: "block statement",
  Return: "return-statement",
  Break: "break-statement",
  Continue: "continue-statement",
  EnumDef: "enumerator definition",
};

export class Parser {
  atKind(kind, la=0) {
    return this.tokens[la]?.kind===kind;
  }
  ended() {
    return !this.tokens.length;
  }
  consume() {
    return this.tokens.shift();
  }
  consumeIfAt(kind) {
    if(this.atKind(kind)) {
      return this.consume();
    }
    return false;
  }
  expectKind(kind, msg) {
    if(this.ended()) {
      this.errorAtCode(
        (msg ? msg : `expecting ${kind}`)
          + " → found the end of input instead",
        this.text.length-1
      );
    }
    const next = this.consume();
    if(next.kind!==kind) {
      this.errorAtCode(
        (msg ? msg : `expecting a ${kind}`)
          + ` → found ${next.raw} instead`,
        next.start
      );
    }
    return next;
  }
  
  parsePrimaryExpr() {
    if(this.ended()) {
      this.errorAtCode(`not expecting the end of input right now`, this.text.length-1);
    }
    if(this.atKind(TokenKind.Function)) {
      return this.parseLambdaExpr();
    }
    const next = this.consume();
    switch(next.kind) {
      case TokenKind.Identifier: {
        return {
          kind: NodeKind.Identifier,
          name: next.name,
          start: next.start,
          end: next.end
        };
      }
      case TokenKind.Bool: {
        return {
          kind: NodeKind.BoolLiteral,
          value: next.value,
          start: next.start,
          end: next.end
        };
      }
      case TokenKind.Nil: {
        return {
          kind: NodeKind.NilLiteral,
          start: next.start,
          end: next.end
        };
      }
      case TokenKind.NaN: {
        return {
          kind: NodeKind.NaNLiteral,
          start: next.start,
          end: next.end
        };
      }
      case TokenKind.Number: {
        return {
          kind: NodeKind.NumberLiteral,
          value: next.value,
          raw: next.raw,
          start: next.start,
          end: next.end,
          is_float: next.is_float
        };
      }
      case TokenKind.String: {
        return {
          kind: NodeKind.StringLiteral,
          value: next.value,
          raw: next.raw,
          start: next.start,
          end: next.end
        };
      }
      case TokenKind.TemplateString: {
        return {
          kind: NodeKind.TemplateString,
          quasis: next.quasis,
          exprs: next.exprs,
          raw: next.raw,
          start: next.start,
          end: next.end
        };
      }
      case TokenKind.LeftParen: {
        const expr = this.parseExpr();
        this.expectKind(TokenKind.RightParen, "expected a closing pair for parenthesis");
        return expr;
      }
      case TokenKind.Dash: {
        const expr = this.parsePrimaryExpr();
        return {
          kind: NodeKind.UnaryExpr,
          expr, op: next.raw,
          start: next.start, end: expr.end
        };
      }
      case TokenKind.LeftBracket: {
        const items = [];
        while(!this.ended() && !this.atKind(TokenKind.RightBracket)) {
          const expr = this.parseExpr();
          items.push(expr);
          this.consumeIfAt(TokenKind.Comma);
        }
        const end = this.expectKind(TokenKind.RightBracket, "expected a closing pair for brackets").end;
        return {
          kind: NodeKind.ArrayExpr,
          items,
          start: next.start, end
        };
      }
      
      default:
        this.errorAtCode(`not expecting '${next.raw}' to be here`, next.start);
    }
  }
  atValidMemberCall(ls = 0) {
    return this.atKind(TokenKind.Dot, ls) ||
      this.atKind(TokenKind.LeftBracket, ls) ||
      this.atKind(TokenKind.Bang, ls) ||
      this.atKind(TokenKind.LeftParen, ls);
  }
  parseMemberCallExpr() {
    let first = this.parsePrimaryExpr();
    while(this.atValidMemberCall()) {
      if(
        this.atKind(TokenKind.Dot) ||
        this.atKind(TokenKind.LeftBracket)
      ) {
        const is_computed = this.consume().kind===TokenKind.LeftBracket;
        let end, property;
        if(is_computed) {
          property = this.parseExpr();
          end = this.expectKind(
            TokenKind.RightBracket,
            "member indexing must end with a right bracket"
          ).end;
        } else {
          property = this.expectKind(
            TokenKind.Identifier,
            "member field name must be an identifier"
          );
          end = property.end;
          property = property.name;
        }
        first = {
          kind: is_computed
            ? NodeKind.IndexExpr
            : NodeKind.MemberExpr,
          object: first,
          property,
          start: first.start, end
        };
      } else if(this.atKind(TokenKind.Bang)) {
        const end = this.consume().end;
        first = {
          kind: NodeKind.CallExpr,
          callee: first, args: [],
          start: first.start, end
        };
      } else {
        this.consume();
        
        const args = [];
        while(!this.ended() && !this.atKind(TokenKind.RightParen)) {
          args.push(this.parseExpr());
          this.consumeIfAt(TokenKind.Comma);
        }
        const end = this.expectKind(
          TokenKind.RightParen,
          "call expression must end with a right parenthesis"
        ).end;
        
        first = {
          kind: NodeKind.CallExpr,
          callee: first, args,
          start: first.start, end,
        };
      }
    }
    return first;
  }
  parseExponentialExpr() {
    let left = this.parseMemberCallExpr();
    while(
      this.atKind(TokenKind.Caret)
    ) {
      const op = this.consume().raw;
      const right = this.parseMemberCallExpr();
      left = {
        kind: NodeKind.BinaryExpr,
        left, op, right,
        start: left.start,
        end: right.end
      };
    }
    return left;
  }
  parseMultipliveExpr() {
    let left = this.parseExponentialExpr();
    while(
      this.atKind(TokenKind.Star)
      || this.atKind(TokenKind.Slash)
      || this.atKind(TokenKind.Modulo)
      || this.atKind(TokenKind.DoubleSlash)
    ) {
      const op = this.consume().raw;
      const right = this.parseExponentialExpr();
      left = {
        kind: NodeKind.BinaryExpr,
        left, op, right,
        start: left.start,
        end: right.end
      };
    }
    return left;
  }
  parseAdditiveExpr() {
    let left = this.parseMultipliveExpr();
    while(
      this.atKind(TokenKind.Plus) ||
      this.atKind(TokenKind.Dash)
    ) {
      const op = this.consume().raw;
      const right = this.parseMultipliveExpr();
      left = {
        kind: NodeKind.BinaryExpr,
        left, op, right,
        start: left.start,
        end: right.end
      };
    }
    return left;
  }
  parseComparativeExpr() {
    let left = this.parseAdditiveExpr();
    while(
      this.atKind(TokenKind.GreaterThan) ||
      this.atKind(TokenKind.GreaterThanEqual) ||
      this.atKind(TokenKind.LessThan) ||
      this.atKind(TokenKind.LessThanEqual) ||
      this.atKind(TokenKind.Equal) ||
      this.atKind(TokenKind.NotEqual)
    ) {
      const op = this.consume().raw;
      const right = this.parseAdditiveExpr();
      left = {
        kind: NodeKind.BinaryExpr,
        left, op, right,
        start: left.start,
        end: right.end
      };
    }
    return left;
  }
  parseLogicalExpr() {
    let left = this.parseComparativeExpr();
    while(
      this.atKind(TokenKind.LogicalAnd) ||
      this.atKind(TokenKind.LogicalOr)
    ) {
      const op = this.consume().raw;
      const right = this.parseComparativeExpr();
      left = {
        kind: NodeKind.BinaryExpr,
        left, op, right,
        start: left.start,
        end: right.end
      };
    }
    return left;
  }
  parseExpr() {
    let left = this.parseLogicalExpr();
    while(
      this.atKind(TokenKind.Concat)
      || this.atKind(TokenKind.Question)
    ) {
      if(this.consumeIfAt(TokenKind.Question)) {
        const a = this.parseLogicalExpr();
        this.consumeIfAt(":");
        const b = this.parseLogicalExpr();
        left = {
          kind: NodeKind.Ternary,
          cond: left, a, b
        };
        continue;
      }
      
      const op = this.consume().raw;
      const right = this.parseLogicalExpr();
      left = {
        kind: NodeKind.BinaryExpr,
        left, op, right,
        start: left.start,
        end: right.end
      };
    }
    return left;
  }
  parseLambdaExpr() {
    const start = this.consume().start;
    
    const is_void = this.consumeIfAt(TokenKind.Void)!==false;
    
    const params = [];
    while(
      !this.ended() &&
      !this.atKind(TokenKind.LeftBrace) &&
      !this.atKind(TokenKind.Colon)
    ) {
      const name = this.expectKind(
        TokenKind.Identifier,
        "parameter name must be an identifier"
      ).name;
      params.push(name);
      if(this.atKind(TokenKind.Colon)) break;
      if(this.atKind(TokenKind.LeftBrace)) break;
      this.consumeIfAt(TokenKind.Comma);
    }
    
    const body = this.parseInlineOrBlock("function");
    return {
      kind: NodeKind.Lambda,
      body, is_void, params,
      start, end: body.end
    };
  }
  
  parseFuncDefStmt() {
    const start = this.consume().start;
    
    const is_native = this.consumeIfAt(TokenKind.Native)!==false;
    const is_void = this.consumeIfAt(TokenKind.Void)!==false;
    
    const name = this.expectKind(
      TokenKind.Identifier,
      "function name must be an identifier"
    ).name;
    
    const params = [];
    let end;
    if(this.atKind(TokenKind.Colon)) {
      this.consume();
      while(
        !this.ended() &&
        !this.atKind(TokenKind.LeftBrace) &&
        !this.atKind(TokenKind.Colon) &&
        !(is_native && this.atKind(TokenKind.Semicolon))
      ) {
        const v_name = this.expectKind(
          TokenKind.Identifier,
          "parameter name must be an identifier"
        );
        end = v_name.end;
        params.push(v_name.name);
        if(this.atKind(TokenKind.Colon)) break;
        if(this.atKind(TokenKind.LeftBrace)) break;
        end = this.consumeIfAt(TokenKind.Comma)?.end ?? end;
      }
    }
    let body = null;
    if(is_native) {
      end = this.expectKind(TokenKind.Semicolon).end;
    } else {
      body = this.parseInlineOrBlock("function");
      end = body.end;
    }
    return {
      kind: NodeKind.FunctionDef,
      name, body, is_void,
      params, is_native,
      start, end
    };
  }
  parseVarDefStmt() {
    const start = this.consume().start;
    const is_const = this.consumeIfAt(TokenKind.Tilde)===false;
    const defs = [];
    while(true) {
      const name = this.expectKind(
        TokenKind.Identifier,
        "variable name must be an identifier"
      ).name;
      const init = this.parseExpr();
      defs.push({ name, init });
      if(this.consumeIfAt(TokenKind.Comma)) continue;
      break;
    }
    const end =
      this.consumeIfAt(TokenKind.Semicolon)?.end
      ?? defs.at(-1).init.end;
    return {
      kind: NodeKind.VarDef,
      is_const, defs,
      start, end
    };
  }
  parseBlock(name = "block") {
    const start = this.expectKind(
      TokenKind.LeftBrace,
      name+" must start with a left brace"
    ).start;
    const stmts = [];
    while(!this.ended() && !this.atKind(TokenKind.RightBrace)) {
      const stmt = this.parseStmt();
      stmts.push(stmt);
      if(
        stmt.kind===NodeKind.Return
        || stmt.kind===NodeKind.Break
        || stmt.kind===NodeKind.Continue
      ) break;
    }
    const end = this.expectKind(
      TokenKind.RightBrace,
      name+" must end with a right brace"
    ).end;
    return {
      kind: NodeKind.Block,
      stmts,
      start, end
    };
  }
  parseInlineOrBlock(name = "body") {
    if(this.atKind(TokenKind.Colon)) {
      this.consume();
      const stmt = this.parseStmt();
      if(
        stmt.kind===NodeKind.FunctionDef ||
        stmt.kind===NodeKind.VarDef
      ) {
        this.errorAtCode(`${stmt.kind} after inline ${name} is not allowed`, stmt.start);
      }
      return stmt;
    }
    return this.parseBlock(name);
  }
  forOptionalHelper() {
    this.consumeIfAt(TokenKind.Comma);
    return !this.atKind(TokenKind.Colon) &&
      !this.atKind(TokenKind.LeftBrace) &&
      !this.atKind(TokenKind.Comma);
  }
  
  parseForStmt() {
    const start = this.consume().start;
    
    const is_const = this.consumeIfAt(TokenKind.Star)!==false;
    
    const cycles = this.parseExpr();
    let counter = null, iota = null, step = null;
    
    if(this.forOptionalHelper()) {
      counter = this.expectKind(TokenKind.Identifier).name;
    }
    if(this.forOptionalHelper()) {
      iota = this.parseExpr();
    }
    if(this.forOptionalHelper()) {
      step = this.parseExpr();
    }
    
    const body = this.parseInlineOrBlock("for-statement");
    return {
      kind: NodeKind.ForStmt,
      cycles, counter, iota, step,
      is_const, body,
      start, end: body.end
    };
  }
  parseIfStmt() {
    const start = this.consume().start;
    const condition = this.parseExpr();
    const body = this.parseInlineOrBlock("if-statement");
    let alt = null;
    if(this.atKind(TokenKind.Elif)) {
      alt = this.parseIfStmt();
    } else if(this.atKind(TokenKind.Else)) {
      const estart = this.consume().start;
      const ebody = this.parseInlineOrBlock("else-statement");
      alt = {
        kind: NodeKind.ElseStmt,
        body: ebody,
        start: estart, end: ebody.end
      };
    }
    return {
      kind: NodeKind.IfStmt,
      condition, body, alt,
      start, end: body.end
    };
  }
  parseWhileStmt() {
    const start = this.consume().start;
    const run_first = this.consumeIfAt(TokenKind.Star)!==false;
    const condition = this.parseExpr();
    const body = this.parseInlineOrBlock("while-statement");
    return {
      kind: NodeKind.While,
      condition, body, run_first,
      start, end: body.end
    };
  }
  parseReturnStmt() {
    const start = this.consume().start;
    let value = null;
    if(!this.atKind(TokenKind.Semicolon)) {
      value = this.parseExpr();
    }
    const end =
      this.consumeIfAt(TokenKind.Semicolon)?.end
      ?? value.end;
    return {
      kind: NodeKind.Return,
      value,
      start, end
    };
  }
  parseBreakStmt() {
    const { start, nend } = this.consume();
    const end =
      this.consumeIfAt(TokenKind.Semicolon)?.end
      ?? nend;
    return {
      kind: NodeKind.Break,
      start, end
    };
  }
  parseContinueStmt() {
    const { start, nend } = this.consume();
    const end =
      this.consumeIfAt(TokenKind.Semicolon)?.end
      ?? nend;
    return {
      kind: NodeKind.Continue,
      start, end
    };
  }
  parseEnumStmt() {
    const start = this.consume().start;
    const name = this.expectKind(TokenKind.Identifier, "enumerator name must be a identifier").name;
    this.expectKind(TokenKind.LeftBrace, "enumerator list must start with a left brace");
    const names = [];
    while(!this.ended() && this.atKind(TokenKind.Identifier)) {
      names.push(this.consume().name);
      this.consumeIfAt(TokenKind.Comma);
    }
    const end = this.expectKind(TokenKind.RightBrace, "enumerator list must end with a right brace").end;
    return {
      kind: NodeKind.EnumDef,
      name, names,
      start, end
    }
  }
  parseStmt() {
    if(this.atKind(TokenKind.Function)) {
      return this.parseFuncDefStmt();
    }
    if(this.atKind(TokenKind.Var)) {
      return this.parseVarDefStmt();
    }
    if(this.atKind(TokenKind.For)) {
      return this.parseForStmt();
    }
    if(this.atKind(TokenKind.If)) {
      return this.parseIfStmt();
    }
    if(this.atKind(TokenKind.While)) {
      return this.parseWhileStmt();
    }
    if(this.atKind(TokenKind.LeftBrace)) {
      const block = this.parseBlock();
      block.kind = NodeKind.BlockStmt;
      return block;
    }
    if(this.atKind(TokenKind.Return)) {
      return this.parseReturnStmt();
    }
    if(this.atKind(TokenKind.Break)) {
      return this.parseBreakStmt();
    }
    if(this.atKind(TokenKind.Continue)) {
      return this.parseContinueStmt();
    }
    /*if(this.atKind(TokenKind.Enum)) {
      return this.parseEnumStmt();
    }*/
    
    const expr = this.parseExpr();
    
    // assignment
    if(
      this.atKind(TokenKind.Assign) ||
      this.atKind(TokenKind.AssignAdd) ||
      this.atKind(TokenKind.AssignSub) ||
      this.atKind(TokenKind.AssignMul) ||
      this.atKind(TokenKind.AssignDiv) ||
      this.atKind(TokenKind.AssignIDiv) ||
      this.atKind(TokenKind.AssignMod) ||
      this.atKind(TokenKind.AssignCon)
    ) {
      const op = this.consume().raw;
      switch(expr.kind) {
        case NodeKind.Identifier:
        case NodeKind.IndexExpr:
        {
          const right = this.parseExpr();
          const end =
            this.consumeIfAt(TokenKind.Semicolon)?.end
            ?? right.end;
          return {
            kind: NodeKind.VarAssign,
            left: expr, op, right,
            start: expr.start, end
          };
        }
        default:
          this.errorAtCode(`can't assign to a ${expr.kind}`, expr.start);
      }
    }
    
    const end =
      this.consumeIfAt(TokenKind.Semicolon)?.end
      ?? expr.end;
    
    return {
      kind: NodeKind.ExprStmt,
      expr,
      start: expr.start, end
    };
  }
  parseProgramStmt() {
    if(this.atKind(TokenKind.Export)) {
      const start = this.consume().start;
      if(this.atKind(TokenKind.Export)) {
        this.errorAtCode("can't export an export-statement", start);
      }
      const stmt = this.parseProgramStmt();
      if(stmt.kind!==NodeKind.FunctionDef && stmt.kind!==NodeKind.VarDef) {
        this.errorAtCode(`can't export '${stmt.kind}'`, start);
      }
      return {
        kind: NodeKind.Export, stmt,
        start, end: stmt.end
      };
    }
    if(this.atKind(TokenKind.Import)) {
      const start = this.consume().start;
      
      const path = [];
      let end;
      while(true) {
        const v = this.expectKind(TokenKind.Identifier);
        end = v.end;
        path.push(v.name);
        if(this.consumeIfAt(TokenKind.Dot)) continue;
        break;
      }
      end = this.consumeIfAt(TokenKind.Semicolon)?.end ?? end;
      
      return {
        kind: NodeKind.Import,
        path, start, end
      };
    }
    if(this.atKind(TokenKind.Function)) {
      return this.parseFuncDefStmt();
    }
    if(this.atKind(TokenKind.Var)) {
      return this.parseVarDefStmt();
    }
    if(this.atKind(TokenKind.Enum)) {
      return this.parseEnumStmt();
    }
    this.errorAtCode(`expected end of file but received '${this.tokens[0].kind}'`, this.tokens[0].start);
  }
  parseProgram() {
    const body = [];
    if(this.atKind(TokenKind.Package)) {
      const start = this.consume().start;
      
      const path = [];
      let end;
      while(true) {
        const v = this.expectKind(TokenKind.Identifier);
        end = v.end;
        path.push(v.name);
        if(this.consumeIfAt(TokenKind.Dot)) continue;
        break;
      }
      end = this.consumeIfAt(TokenKind.Semicolon)?.end ?? end;
      
      body.push({
        kind: NodeKind.Package,
        path, start, end
      });
    }
    while(!this.ended()) {
      body.push(this.parseProgramStmt());
    }
    return {
      kind: NodeKind.Program,
      body,
      start: (body[0]?.start ?? 0),
      end: (body.at(-1)?.end ?? 0)
    };
  }
  errorAtCode(msg, idx) {
    let col = 0, row = 1;
    for(let i = 0; i<=idx; ++i) {
      if(this.text[i]==="\n") {
        col = 0;
        ++row;
      } else {
        ++col;
      }
    }
    --col;
    throw new SyntaxError(`${row}:${col} → ${msg}`);
  }
  parse(code, is_expr = false) {
    this.text = code;
    this.tokens = ((typeof code)==="string")
      ? (new Lexer().lex(code))
      : code;
    if(is_expr) {
      if(this.ended()) {
        this.errorAtCode(`expected a expression but found the end of input instead`, 0);
      }
      const expr = this.parseExpr();
      if(!this.ended()) {
        const out = this.tokens[0];
        this.errorAtCode(`'${out.raw}' was not supossed to be here after the expression`, out.start);
      }
      return expr;
    }
    return this.parseProgram();
  }
}
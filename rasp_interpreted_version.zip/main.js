import { interpret_source } from "./svm/svm.js";
import { Parser } from "./ast/parser.js";

import * as fs from "jsr:@std/fs";
import * as path from "jsr:@std/path";

if(Deno.args.length) {
  let idx = 0;
  const cmd = Deno.args[idx++];
  switch(cmd) {
    case "-v":
    case "version": {
      console.log("runic v0.0.1");
      break;
    }
    
    case "-a":
    case "-ast": {
      let input_path = Deno.args[idx++];
      if(!input_path) {
        console.log("please provide a path for input.");
        break;
      }
      if(input_path[0]!=="/") {
        input_path = path.join(import.meta.dirname, input_path);
      }
      if(!fs.existsSync(input_path, { isFile: true })) {
        console.log("please provide a path that points to a file.");
        break;
      }
      
      let output_path = Deno.args[idx++];
      if(!output_path) {
        console.log("please provide a path for output.");
        break;
      }
      if(output_path[0]!=="/") {
        output_path = path.join(import.meta.dirname, output_path);
      }
      if(fs.existsSync(output_path, { isDirectory: true })) {
        console.log("the output path was taken by a directory.");
        break;
      }
      output_path += ".json";
      if(output_path.includes("/")) {
        const output_dir = output_path.replace(/\/[^\/]+?\/*$/, "");
        await Deno.mkdir(
          output_dir,
          { recursive: true }
        );
      }
      
      const file_res = Deno.readTextFileSync(input_path);
      const program_ast = new Parser().parse(file_res);
      Deno.writeTextFileSync(
        output_path,
        JSON.stringify(program_ast, null, 2),
        { create: true }
      );
      console.log("AST generated.");
      break;
    }
    
    case "-r":
    case "run": {
      let input_path = Deno.args[idx++];
      if(!input_path) {
        console.log("please provide a path for input.");
        break;
      }
      if(input_path[0]!=="/") {
        input_path = path.join(import.meta.dirname, input_path);
      }
      if(!fs.existsSync(input_path, { isFile: true })) {
        console.log("please provide a path that points to a file.");
        break;
      }
      
      const file_res = Deno.readTextFileSync(input_path);
      interpret_source(true, file_res, Deno.args.slice(idx), input_path);
      
      break;
    }
    
    default: {
      console.log("unknown command → "+cmd);
      break;
    }
  }
}
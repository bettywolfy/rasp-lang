import { Parser, NodeKind } from "../ast/parser.js";
import { analyzeAST } from "../ast/analyzer.js";
import * as path from "jsr:@std/path";
import * as fs from "jsr:@std/fs";

export class Scope {
  syms = new Map();
  consts = new Set();
  constructor(parent = null) {
    this.parent = parent;
    if(parent) {
      this.__filename = parent.__filename;
      this.__pathname = parent.__pathname;
      this.exports = parent.exports;
    } else {
      this.exports = [];
    }
  }
  add_export(name, value) {
    return this.exports.push([name, value]);
  }
  declare(name, value, is_const = false) {
    if(this.syms.has(name)) {
      throw new SyntaxError(`redefinition of '${name}' is not allowed`);
    }
    if(is_const) this.consts.add(name);
    return this.syms.set(name, value);
  }
  assign(name, value) {
    const scope = this.lookup(name);
    if(!scope) {
      throw new ReferenceError(`'${name}' is not defined`);
    }
    if(scope.consts.has(name)) {
      throw new ReferenceError(`assignment to constant '${name}' is not allowed`);
    }
    return scope.syms.set(name, value);
  }
  get(name, crash = true) {
    const scope = this.lookup(name);
    if(!scope) {
      if(!crash) return null;
      throw new ReferenceError(`'${name}' is not defined`);
    }
    return scope.syms.get(name);
  }
  lookup(name) {
    if(this.syms.has(name)) return this;
    if(this.parent) return this.parent.lookup(name);
    return null;
  }
}

const rt_function_proto = {
  kind: "metadata",
  name: "function",
  ops: {}
};

export function rt_value(value, type) {
  return { kind: "value", value, type };
}
function rt_function(fsigns, is_void=true, name="", scope = null) {
  const signs = new Map();
  for(const [p, f] of fsigns) {
    signs.set(p.length, [p, f]);
  }
  return rt_value(
    {
      name, is_void,
      signs, scope
    },
    rt_function_proto
  );
}
export function rtBinaryOp(left, right, op) {
  if(right.kind!=="value" || left.kind!=="value") {
    throw new TypeError(`can't do binary '${op}' operation with '${left.kind}' and '${right.kind}' type`);
  }
  let func = left.type.ops[op+right.type.name];
  if(func) {
    return func(left, right);
  }
  func = right.type.ops[left.type.name+op];
  if(func) {
    return func(left, right);
  }
  if(left.type==="number" && right.type==="number") {
    if(op==="+") {
      return rt_value(left.value+right.value, "number");
    }
    if(op==="-") {
      return rt_value(left.value-right.value, "number");
    }
    if(op==="*") {
      return rt_value(left.value*right.value, "number");
    }
    if(op==="/") {
      return rt_value(left.value/right.value, "number");
    }
    if(op==="//") {
      return rt_value(Math.trunc(left.value/right.value), "number");
    }
    if(op==="%") {
      return rt_value(Math.trunc(left.value%right.value), "number");
    }
    if(op==="<") {
      return (left.value<right.value) ? rt_true : rt_false;
    }
    if(op==="<=") {
      return (left.value<=right.value) ? rt_true : rt_false;
    }
    if(op===">") {
      return (left.value>right.value) ? rt_true : rt_false;
    }
    if(op===">=") {
      return (left.value>=right.value) ? rt_true : rt_false;
    }
  }
  if(op==="==") {
    return (left.value===right.value) ? rt_true : rt_false;
  }
  if(op==="!=") {
    return (left.value!==right.value) ? rt_true : rt_false;
  }
  if(op==="&&") {
    return (rtIsTruthy(left) && rtIsTruthy(right)) ? rt_true : rt_false;
  }
  if(op==="||") {
    return (rtIsTruthy(left) || rtIsTruthy(right)) ? rt_true : rt_false;
  }
  if(op==="..") {
    return rt_value(rtToString(left)+rtToString(right), "string");
  }
  throw new TypeError(`can't do binary '${op}' operation with '${left.type.name}' and '${right.type.name}' type`);
}
export function rtUnaryOp(expr, op) {
  if(expr.kind!=="value") {
    throw new TypeError(`can't do unary '${op}' operation with '${expr.kind}' type`);
  }
  if(expr.type==="number") {
    if(op==="-") {
      return rt_value(-expr.value, "number");
    }
  }
  let func = expr.type.ops[op];
  if(func) return func(expr);
  throw new TypeError(`can't do unary '${op}' operation with '${expr.type.name}'`);
}
export function rtIsTruthy(val) {
  if(val?.kind==="value") {
    return val.value!==false && val.value!==null;
  }
  return val?.kind!=="void";
}
export function rtToString(val) {
  if(val?.kind==="value") {
    let ts = val.type.ops._tostring;
    if(ts) return ""+ts(val).value;
    
    if(Number.isNaN(val.value)) return "nan";
    if(val.value===null) return "nil";
    return ""+val.value;
  }
  return "[object]";
}
export function rtTypeName(val) {
  if(val?.kind==="value") {
    return val.type.name;
  }
  return "object";
}
export function rtNumberValue(val) {
  const valt = rtTypeName(val);
  if(valt!=="number") {
    throw new Error(`value needs to be a number but received '${valt}'`);
  }
  return val.value;
}
export function rtInvoke(func, args = [], self = rt_nil) {
  if(func.kind!=="value" || func.type!=="function") {
    throw new TypeError(`can't invoke '${rtToString(func)}'`);
  }
  
  const sign = func.value.signs.get(args.length);
  if(!sign) {
    const first = func.value.signs.keys().next().value;
    const name = rtToString(func);
    throw new SyntaxError(`incorect number of arguments for ${name} → expected ${first} found ${args.length}`);
  }
  
  const [params, func_call] = sign;
  
  if(typeof func_call==="function") {
    const out = func_call(self, ...args);
    return out ? out : rt_void;
  } else {
    const fscope = new Scope(func.value.scope);
    fscope.declare("self", rt_nil, true);
    for(let i = 0; i<args.length; ++i) {
      fscope.declare(params[i], args[i], false);
    }
    try {
      evaluate_node(func_call, fscope);
    } catch(e) {
      if(e instanceof ReturnSignal) {
        return e.value;
      }
      throw e;
    }
  }
}
export function rtIndex(obj, idx) {
  const ptype = rtTypeName(idx);
  if(ptype!=="finctio") {
    throw new TypeError(`can't index with '${ptype}'`);
  }
  
  if(obj.kind==="value") {
    const ts = obj.type.ops.index;
    if(ts) {
      const val = ts(obj, idx);
      return val;
    }
  }
  
  throw new TypeError(`can't index '${rtTypeName(obj)}'`);
}
export function rtIndexSet(obj, idx, val) {
  const ptype = rtTypeName(idx);
  if(ptype!=="number") {
    throw new TypeError(`can't index with '${ptype}'`);
  }
  
  if(obj.kind==="value") {
    const ts = obj.type.ops.set_index;
    if(ts) {
      ts(obj, idx, val);
      return;
    }
  }
  
  throw new TypeError(`can't index '${rtTypeName(obj)}'`);
}
export function rtMember(obj, prop) {
  if(obj.kind==="object") {
    const val = obj.keys.get(prop);
    if(!val) {
      throw new TypeError(`member '${prop}' doesn't exist on object`);
    }
    return val;
  }
  if(obj.kind==="value") {
    const org = obj.type.meta?.[prop];
    if(org) return org;
    throw new TypeError(`can't index '${obj.type}'`);
  }
  throw new TypeError(`can't index '${obj.kind}'`);
}

const global_scope = new Scope();

// essentials
const rt_void = { kind: "void" };
const rt_nil = rt_value(null, { kind: "metadata", name: "nil", ops: {} });
const rt_true = rt_value(true, "boolean");
const rt_false = rt_value(false, "boolean");
const rt_nan = rt_value(NaN, "number");

global_scope.declare("Sys", {
  kind: "object",
  name: "Sys",
  keys: new Map([
    ["out", {
      kind: "object",
      namw: "out",
      keys: {
        "columns": rt_function(
          [[[], () => rt_value(process.stdout.columns, "number")]],
          false
        ),
        "rows": rt_function(
          [[[], () => rt_value(process.stdout.rows, "number")]],
          false
        ),
      }
    }],
    ["sleepms", rt_function(
      [[["ms"], function(self, ms) {
        ms = rtNumberValue(ms)|0;
        const sab = new SharedArrayBuffer(4);
        const int32 = new Int32Array(sab);
        Atomics.wait(int32, 0, 0, ms);
      }]],
      true,
      "sleepms"
    )],
    ["writeln", rt_function(
      [[["data"], function(self, data) {
        process.stdout.write(rtToString(data)+"\n");
      }]],
      true,
      "writeln"
    )],
    ["write", rt_function(
      [[["data"], function(self, data) {
        process.stdout.write(rtToString(data));
      }]],
      true,
      "write"
    )],
    ["read", rt_function(
      [
        [[], function(self) {
          const buffer = new Uint8Array(1024);
          const read = Deno.stdin.readSync(buffer);
          if(read===null || read===0) return rt_nil;
          
          let input = new TextDecoder().decode(buffer.subarray(0, read));
          input = input.replace(/\r?\n$/, "");
          if(!input.length) return rt_nil;
          
          return rt_value(input, "string");
        }],
        [["msg"], function(self, msg) {
          msg = rtToString(msg);
          process.stdout.write(msg);
          
          const buffer = new Uint8Array(1024);
          const read = Deno.stdin.readSync(buffer);
          if(read===null || read===0) return rt_nil;
          
          let input = new TextDecoder().decode(buffer.subarray(0, read));
          input = input.replace(/\r?\n$/, "");
          if(!input.length) return rt_nil;
          
          return rt_value(input, "string");
        }]
      ],
      false,
      "read"
    )]
  ])
}, true);

const rt_guide_break = new SyntaxError("break-statement outside loop");
const rt_guide_continue = new SyntaxError("continue-statement outside loop");
class ReturnSignal extends SyntaxError {
  constructor(value = rt_void) {
    super("return-statement outside function");
    this.value = value;
  }
}

const runic_inative = new Map([
  ["NUMBER_ISNAN", rt_function(
    [[["val"], function(val) {
      if(val?.kind==="value") {
        return Number.isNaN(val.value) ? rt_true : rt_false;
      }
      return rt_false;
    }]],
    false
  )],
  ["NUMBER_TO", rt_function(
    [[["val"], function(val) {
      if(val?.kind==="value") {
        return rt_value(Number(val.value), "number");
      }
      return rt_value(NaN, "number");
    }]],
    false
  )],
  ["STRING_TOCHAR", rt_function(
    [[["codepoint"], function(x) {
      return rt_value(String.fromCodePoint(rtNumberValue(x)), "string");
    }]],
    false
  )],
  ["MATH_SQRT", rt_function(
    [[["x"], function(x) {
      return rt_value(Math.sqrt(rtNumberValue(x)), "number");
    }]],
    false
  )],
  ["MATH_COS", rt_function(
    [[["x"], function(x) {
      return rt_value(Math.cos(rtNumberValue(x)), "number");
    }]],
    false
  )],
  ["MATH_SIN", rt_function(
    [[["x"], function(x) {
      return rt_value(Math.sin(rtNumberValue(x)), "number");
    }]],
    false
  )],
  ["MATH_LOG", rt_function(
    [[["x", "base"], function(x, base) {
      const xv = Math.log(rtNumberValue(x));
      const bv = Math.log(rtNumberValue(base));
      return rt_value(xv/bv, "number");
    }]],
    false
  )],
  ["MATH_LOGE", rt_function(
    [[["x"], function(x) {
      return rt_value(Math.log(rtNumberValue(x)), "number");
    }]],
    false
  )],
  ["MATH_LOG10", rt_function(
    [[["x"], function(x) {
      return rt_value(Math.log10(rtNumberValue(x)), "number");
    }]],
    false
  )],
  ["MATH_LOG2", rt_function(
    [[["x"], function(x) {
      return rt_value(Math.log2(rtNumberValue(x)), "number");
    }]],
    false
  )],
  ["MATH_FLOOR", rt_function(
    [[["x"], function(x) {
      return rt_value(Math.floor(rtNumberValue(x)), "number");
    }]],
    false
  )],
  ["MATH_RND", rt_function(
    [[[], function() {
      return rt_value(Math.random(), "number");
    }]],
    false
  )]
]);

function resolve_import_primitive(path, name, scope) {
  if(!fs.existsSync(path, { isFile: true })) {
    throw new Error(`can't resolve import '${path.slice(0, -3).replaceAll("/", ".")}'`);
  }
  
  const source = Deno.readTextFileSync(path);
  const program = interpret_source(false, source, [], path);
  
  const imp_obj = {
    kind: "object",
    name, keys: new Map()
  };
  for(const [name, val] of program.exports) {
    imp_obj.keys.set(name, val);
  }
  scope.declare(name, imp_obj, true);
}

function resolve_import(names, scope) {
  let _path = names.join("/")+".rc";
      
  let final_path = path.join(scope.__pathname, _path);
  if(fs.existsSync(final_path, { isFile: true })) {
    resolve_import_primitive(final_path, names.at(-1), scope);
    return;
  }
  
  final_path = path.join(import.meta.dirname, "core", _path);
  if(fs.existsSync(final_path, { isFile: true })) {
    resolve_import_primitive(final_path, names.at(-1), scope);
    return;
  }
  
  throw new Error(`can't resolve import '${names.join(".")}'`);
}

function evaluate_node(node, scope) {
  // process.stdout.write(`\x1b[2m${node.kind}\x1b[0m\n`);
  switch(node.kind) {
    case NodeKind.INative: {
      const val = runic_inative.get(node.name);
      if(!val) {
        throw new Error(`can't find native value '${node.name}'`);
      }
      scope.declare(node.name, val, true);
      return rt_nil;
    }
    case NodeKind.Import: {
      resolve_import(node.names, scope);
      return rt_nil;
    }
    case NodeKind.Export: {
      const stmt = node.stmt;
      switch(stmt.kind) {
        case NodeKind.FunctionDef: {
          evaluate_node(stmt, scope);
          scope.add_export(stmt.name, scope.get(stmt.name));
          break;
        }
        case NodeKind.VarDef: {
          for(const def of stmt.defs) {
            const init = evaluate_node(def.init, scope);
            scope.declare(def.name, init, node.is_const);
            scope.add_export(def.name, init);
          }
          break;
        }
      }
      return rt_nil;
    }
    case NodeKind.Break: {
      throw rt_guide_break;
    }
    case NodeKind.Return: {
      if(node.value) {
        const expr = evaluate_node(node.value, scope);
        throw new ReturnSignal(expr);
      }
      throw new ReturnSignal();
    }
    case NodeKind.Continue: {
      throw rt_guide_continue;
    }
    case NodeKind.ExprStmt: {
      evaluate_node(node.expr, scope);
      return rt_nil;
    }
    case NodeKind.IfStmt: {
      const cond = evaluate_node(node.condition, scope);
      if(rtIsTruthy(cond)) {
        evaluate_node(node.body, new Scope(scope));
      } else if(node.alt) {
        if(node.alt.kind===NodeKind.ElseStmt) {
          evaluate_node(node.alt.body, new Scope(scope));
        } else {
          evaluate_node(node.alt, scope);
        }
      }
      return rt_nil;
    }
    case NodeKind.VarDef: {
      for(const def of node.defs) {
        const init = evaluate_node(def.init, scope);
        scope.declare(def.name, init, node.is_const);
      }
      return rt_nil; 
    }
    case NodeKind.VarAssign: {
      const right = evaluate_node(node.right, scope);
      if(node.op==="=") {
        if(node.left.kind===NodeKind.IndexExpr) {
          const obj = evaluate_node(node.left.object, scope);
          const index = evaluate_node(node.left.property, scope);
          rtIndexSet(obj, index, right);
          return rt_nil;
        }
        scope.assign(node.left.name, right);
        return rt_nil;
      }
      if(node.left.kind===NodeKind.IndexExpr) {
        const obj = evaluate_node(node.left.object, scope);
        const index = evaluate_node(node.left.property, scope);
        const left = rtIndex(obj, index);
        const val = rtBinaryOp(left, right, node.op.slice(0, -1));
        rtIndexSet(obj, index, right);
        return rt_nil;
      }
      const left = evaluate_node(node.left, scope);
      const val = rtBinaryOp(left, right, node.op.slice(0, -1));
      scope.assign(node.left.name, val);
      return rt_nil;
    }
    case NodeKind.While: {
      while(true) {
        const cond = evaluate_node(node.condition, scope);
        if(!rtIsTruthy(cond)) break;
        
        try {
          evaluate_node(node.body, new Scope(scope));
        } catch(e) {
          if(e===rt_guide_break) break;
          if(e===rt_guide_continue) continue;
          throw e;
        }
      }
      return rt_nil;
    }
    case NodeKind.ForStmt: {
      let cycles = rtNumberValue(evaluate_node(node.cycles, scope));
      
      const counter = node.counter ?? false;
      const iota = node.iota
        ? rtNumberValue(evaluate_node(node.iota, scope))
        : 0;
      const step = node.step
        ? rtNumberValue(evaluate_node(node.step, scope))
        : 1;
      
      if(node.is_const) {
        for(let i = 0; i<cycles; ++i) {
          try {
            const lscope = new Scope(scope);
            if(counter) {
              lscope.declare(counter, rt_value(iota+i*step, "number"), true);
            }
            evaluate_node(node.body, lscope);
          } catch(e) {
            if(e===rt_guide_break) break;
            if(e===rt_guide_continue) continue;
            throw e;
          }
        }
        return rt_nil;
      }
      
      for(let i = iota; i<cycles; i += step) {
        const lscope = new Scope(scope);
        if(counter) {
          lscope.declare(counter, rt_value(i, "number"), true);
        }
        evaluate_node(node.body, lscope);
      }
      return rt_nil;
    }
    case NodeKind.FunctionDef:
    case NodeKind.Lambda:
    {
      if(node.kind===NodeKind.Lambda) {
        return rt_function(
          [[node.params, node.body]],
          node.is_void, "", scope
        );
      }
      
      const org = scope.get(node.name, false);
      if(!org) {
        scope.declare(node.name, rt_function(
          [[node.params, node.body]],
          node.is_void, "", scope
        ));
        return rt_nil;
      }
      if(org?.type!==rt_function_proto) {
        throw new Error(`'${node.name}' is not a function`);
      }
      if(org.value.signs.has(node.params.length)) {
        throw new Error(`redefinition of '${node.name}' with signature '${node.params.join(", ")}'`);
      }
      org.value.signs.set(node.params.length, [node.params, node.body]);
      return rt_nil;
    }
    case NodeKind.Program: {
      for(const stmt of node.body) {
        evaluate_node(stmt, scope);
      }
      return rt_nil;
    }
    case NodeKind.Block:
    case NodeKind.BlockStmt:
    {
      let bscope = scope;
      if(node.kind===NodeKind.BlockStmt) {
        bscope = new Scope(scooe);
      }
      for(const stmt of node.stmts) {
        evaluate_node(stmt, bscope);
      }
      return rt_nil;
    }
    
    case NodeKind.ArrayExpr: {
      const idxs = node.items.map(a => evaluate_node(a, scope));
      return rt_value(idxs, rt_array_proto);
    }
    
    case NodeKind.IndexExpr: {
      const obj = evaluate_node(node.object, scope);
      const prop = evaluate_node(node.property, scope);
      return rtIndex(obj, prop);
    }
    case NodeKind.BoolLiteral: {
      return node.value ? rt_true : rt_false;
    }
    case NodeKind.NilLiteral: {
      return rt_nil;
    }
    case NodeKind.NaNLiteral: {
      return rt_nan;
    }
    case NodeKind.BinaryExpr: {
      const left = evaluate_node(node.left, scope);
      const right = evaluate_node(node.right, scope);
      return rtBinaryOp(left, right, node.op);
    }
    case NodeKind.UnaryExpr: {
      const expr = evaluate_node(node.expr, scope);
      return rtUnaryOp(expr, node.op);
    }
    case NodeKind.NumberLiteral: {
      return rt_value(node.value, "number");
    }
    case NodeKind.TemplateString: {
      let res = "";
      for(let i = 0; i<node.quasis.length; ++i) {
        res += node.quasis[i];
        if(i<node.exprs.length) {
          const expr = evaluate_node(node.exprs[i], scope);
          res += rtToString(expr);
        }
      }
      return rt_value(res, "string");
    }
    case NodeKind.Identifier: {
      return scope.get(node.name);
    }
    case NodeKind.StringLiteral: {
      return rt_value(node.value, "string");
    }
    case NodeKind.MemberExpr: {
      const object = evaluate_node(node.object, scope);
      return rtMember(object, node.property);
    }
    case NodeKind.CallExpr: {
      const args = node.args.map(a => evaluate_node(a, scope));
      if(node.callee.kind===NodeKind.MemberExpr) {
        const self = evaluate_node(node.callee.object, scope);
        const callee = rtMember(self, node.callee.property);
        if(self.kind!=="value") {
          return rtInvoke(callee, args);
        }
        return rtInvoke(callee, args, self);
      }
      const callee = evaluate_node(node.callee, scope);
      return rtInvoke(callee, args);
    }
  }
  console.log(node);
  throw new SyntaxError(`can't evaluate '${node.kind}'`);
}

{
  const lang_dir = path.join(import.meta.dirname, "core/lang");
  for(const file of Deno.readDirSync(lang_dir)) {
    if(!file.isFile || !file.name.endsWith(".rc")) {
      continue;
    }
    resolve_import_primitive(
      path.join(lang_dir, file.name),
      file.name.slice(0, -3),
      global_scope
    );
  }
}

export function interpret_source(is_main, code, args = [], path = "/") {
  const program = new Parser().parse(code);
  analyzeAST(program);
  
  const scope = new Scope(global_scope);
  scope.__filename = path;
  scope.__pathname = path.slice(0, path.lastIndexOf("/")+1);
  scope.declare("__filename", rt_value(scope.__filename, "string"), true);
  scope.declare("__pathname", rt_value(scope.__pathname, "string"), true);
  evaluate_node(program, scope);
  
  if(!is_main) return scope;
  
  const main = scope.get("main", false);
  if(!main || main?.type!==rt_function_proto) {
    throw new Error("can't find 'main' function");
  }
  
  if(!main.value.is_void) {
    throw new Error("'main' function must be of type void");
  }
  if(main.value.signs.size!==1) {
    throw new Error("'main' function must have only one signature");
  }
  
  if(main.value.signs.has(0)) {
    rtInvoke(main);
  } else {
    let argv = args.map(a => rt_value(""+a, "string"));
    argv = rt_value(argv, rt_array_proto);
    rtInvoke(main, [argv]);
  }
   return scope;
}
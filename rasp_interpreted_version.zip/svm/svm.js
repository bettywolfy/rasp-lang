import { Parser, NodeKind } from "../ast/parser.js";
import { analyzeAST } from "../ast/analyzer.js";
import * as path from "jsr:@std/path";
import * as filesystem from "jsr:@std/fs";

export const cache_import = new Map();

let global_scope;

export class Scope {
  syms = new Map();
  consts = new Set();
  constructor(parent = null) {
    if(parent) {
      this.parent = parent;
      this.root = parent.root;
      this.exports = parent.exports;
    } else {
      this.parent = global_scope;
      this.package_name = null;
      this.root = this;
      this.exports = [];
    }
  }
  add_export(name, value) {
    this.exports.push([ name, value ]);
  }
  declare(name, value, is_const = false) {
    if(this.syms.has(name)) {
      throw new SyntaxError(`redefinition of '${name}' is not allowed`);
    }
    if(is_const) this.consts.add(name);
    return this.syms.set(name, value);
  }
  assign(name, value) {
    const scope = this.lookup(name);
    if(!scope) {
      rt_error(`'${name}' is not defined`);
    }
    if(scope.consts.has(name)) {
      rt_error(`assignment to constant '${name}' is not allowed`);
    }
    return scope.syms.set(name, value);
  }
  get(name, crash = true) {
    const scope = this.lookup(name);
    if(!scope) {
      if(!crash) return null;
      rt_error(`'${name}' is not defined`);
    }
    return scope.syms.get(name);
  }
  lookup(name) {
    if(this.syms.has(name)) return this;
    if(this.parent) return this.parent.lookup(name);
    return null;
  }
}

global_scope = new Scope();

function empty_object(obj = {}) {
  Object.setPrototypeOf(obj, null);
  return obj;
}
function rt_error(msg, row = -1, col = -1) {
  if(row>=0 && col>=0) {
    msg = `${row}:${col} → ${msg}`;
  }
  throw new Error(msg);
}
function rt_object(proto, props) {
  return empty_object({
    kind: "object",
    properties: empty_object(props),
    proto
  });
}
function rt_value(value, kind) {
  return empty_object({ kind, value });
}
function rt_function(name, scope, ...calls) {
  const obj = rt_object(r_proto_function, { name });
  obj.properties.prototype = rt_object(rt_proto_object, { "new": obj });
  
  obj.scope = scope;
  obj._is_func = true;
  obj.signs = empty_object();
  obj.signs.size = calls.length>>1;
  for(let i = 0; i<calls.length; i += 2) {
    const params = calls[i];
    const call = calls[i+1];
    obj.signs[params.length] = empty_object({ params, call });
  }
  return obj;
}
function rt_index(obj, prop) {
  if(typeof prop!=="string") {
    prop = rt_tostring(prop);
  }
  
  let cur = obj;
  
  switch(obj.kind) {
    case "string": cur = rt_string_obj(obj.value); break;
    case "number": cur = rt_proto_number; break;
    case "boolean": cur = rt_proto_boolean; break;
  }
  
  if(cur.kind!=="object") return rt_nil;
  
  while(cur!==rt_nil) {
    const p = cur.properties[prop];
    if(p) return p;
    cur = cur.proto;
  }
  return rt_nil;
}
function rt_index_set(obj, prop, val) {
  if(typeof prop!=="string") {
    prop = rt_tostring(prop);
  }
  
  if(obj.kind!=="object") return;
  obj.properties[prop] = val;
  if(obj.proto===rt_proto_array) {
    const c = Number(prop);
    if(!Number.isNaN(c) && Number.isFinite(c)) {
      const d = rt_tonumber(obj.properties.len);
      obj.properties.len = rt_value(Math.max(c+1, d), "number");
    }
  }
}
function rt_invoke(func, self, ...args) {
  if(!func._is_func) {
    rt_error(`${func.kind} is not a function`);
  }
  const sign = func.signs[args.length];
  if(!sign) {
    rt_error(`can't call function with ${args.length} arguments`);
  }
  const { params, call } = sign;
  
  if(typeof call==="function") {
    const ret = call(self, ...args);
    return ret ?? rt_nil;
  }
  
  try {
    const fscope = new Scope(func.scope);
    fscope.declare("self", self);
    for(let i = 0; i<args.length; ++i) {
      fscope.declare(params[i], args[i]);
    }
    evaluate_node(call, fscope);
  } catch(e) {
    if(e instanceof ReturnSignal) return e.value;
    throw e;
  }
  return rt_nil;
}
function rt_tostring(val, to = true) {
  if(val===rt_nil) {
    if(to) return "nil";
    return rt_value("nil", "string");
  }
  if(val.kind==="string") {
    if(to) return val.value;
    return val;
  }
  const m = rt_index(val, "tostring");
  if(m===rt_nil) {
    rt_error("can't convert to string");
  }
  val = rt_invoke(m, val);
  if(to) val = val.value;
  return val;
}
function rt_tonumber(val, to = true) {
  if(val.kind==="number") {
    if(to) return val.value;
    return val;
  }
  const m = rt_index(val, "tonumber");
  if(m===rt_nil) {
    rt_error("can't convert to number");
  }
  val = rt_invoke(m, val);
  if(to) val = val.value;
  return val;
}

function rt_binop(left, right, op) {
  switch(op) {
    case "..": {
      const lhs = rt_tostring(left);
      const rhs = rt_tostring(right);
      return rt_value(lhs+rhs, "string");
    }
    case "==": {
      if(left.kind==="object" && right.kind==="object") {
        return rt_value(left===right, "boolean");
      }
      return rt_value(left.kind===right.kind && left.value===right.value, "boolean");
    }
    case "!=": {
      if(left.kind==="object" && right.kind==="object") {
        return rt_value(left!==right, "boolean");
      }
      return rt_value(left.kind!==right.kind || left.value!==right.value, "boolean");
    }
    case "&&": return rt_value(rt_is_truthy(left)&&rt_is_truthy(right), "boolean");
    case "||": return rt_value(rt_is_truthy(left)||rt_is_truthy(right), "boolean");
  }
  
  let lhs, rhs;
  try {
    lhs = rt_tonumber(left);
    rhs = rt_tonumber(right);
  } catch(e) {
    if(e.message==="can't convert to number") {
      rt_error(`can't do binary ${op} operation with ${left.kind} and ${right.kind}`);
    } else throw e;
  }
  
  switch(op) {
      case "+": return rt_value(lhs+rhs, "number");
      case "-": return rt_value(lhs-rhs, "number");
      case "*": return rt_value(lhs*rhs, "number");
      case "/": return rt_value(lhs/rhs, "number");
      case "//": return rt_value(Math.trunc(lhs/rhs), "number");
      case "^": return rt_value(Math.trunc(lhs**rhs), "number");
      
      case "<": return rt_value(lhs<rhs, "boolean");
      case "<=": return rt_value(lhs<=rhs, "boolean");
      case ">": return rt_value(lhs>rhs, "boolean");
      case ">=": return rt_value(lhs>=rhs, "boolean");
    }
}
function rt_unop(value, op) {
  switch(op) {
    case "!": return rt_value(!rt_is_truthy(value), "boolean");
    case "+": return rt_tonumber(value, false);
  }
  
  const hs = rt_tonumber(value);
  switch(op) {
    case "-": return rt_value(-hs, "number");
  }
  rt_error(`can't do unary ${op} operation with ${value.kind}`);
}
function rt_is_truthy(val) {
  if(val==rt_nil) return false;
  if(val.kind==="boolean") return !!val.value;
  return true;
}
function rt_array_obj(idxs) {
  const arr = rt_object(rt_proto_array);
  for(let i = 0; i<idxs.length; ++i) {
    arr.properties[i] = idxs[i];
  }
  arr.properties.len = rt_value(idxs.length, "number");
  return arr;
}
function rt_string_obj(str) {
  const arr = rt_object(rt_proto_string);
  const idxs = str.split("");
  for(let i = 0; i<idxs.length; ++i) {
    arr.properties[i] = rt_value(idxs[i], "string");
  }
  arr.properties.len = rt_value(idxs.length, "number");
  return arr;
}

const rt_nil = rt_value(null, "nil");
const rt_nan = rt_value(NaN, "number");
const rt_true = rt_value(true, "boolean");
const rt_false = rt_value(false, "boolean");

const rt_proto_object = rt_object(rt_nil, {});
const r_proto_function = rt_object(rt_proto_object, {});

r_proto_function.properties = empty_object({
  tostring: rt_function(
    "tostring", null,
    [],
    function(self) {
      const name = self.properties.name;
      const str = `[function${name ? ` ${name}` : ""}]`;
      return rt_value(str, "string");
    }
  )
});
rt_proto_object.properties = empty_object({
  tostring: rt_function(
    "tostring", null,
    [],
    function(self) {
      return rt_value("[object]", "string");
    }
  )
});

const rt_proto_array = rt_object(rt_proto_object, {
  tostring: rt_function("tostring", null,
    [],
    function(self) {
      const len = rt_tonumber(self.properties.len);
      
      let res = "";
      const props = self.properties;
      for(let i = 0; i<len;) {
        res += rt_tostring(props[i] ?? rt_nil);
        if(++i<len) res += ", ";
      }
      
      return rt_value(res, "string");
    }
  ),
  join: rt_function("tostring", null,
    ["sep"],
    function(self, sep) {
      sep = rt_tostring(sep);
      
      const len = rt_tonumber(self.properties.len);
      
      let res = "";
      const props = self.properties;
      for(let i = 0; i<len;) {
        res += rt_tostring(props[i] ?? rt_nil);
        if(++i<len) res += sep;
      }
      
      return rt_value(res, "string");
    }
  ),
  remto: rt_function("remto", null,
    ["idx"],
    function(self, idx) {
      idx = rt_tostring(idx);
      
      const len = rt_tonumber(self.properties.len);
      
      const props = self.properties;
      for(let i = idx; i<len;) {
        props[i] = props[++i];
      }
      
      --self.properties.len.value;
    }
  )
});

const rt_proto_string = rt_object(rt_proto_object, {
  tostring: rt_function(
    "tostring", null,
    [],
    function(self) {
      return rt_value(self.value, "string");
    }
  ),
  tonumber: rt_function(
    "tonumber", null,
    [],
    function(self) {
      const val = Number(self.value);
      return rt_value(val, "number");
    }
  )
});
const rt_proto_number = rt_object(rt_proto_object, {
  tostring: rt_function(
    "tostring", null,
    [],
    function(self) {
      if(Number.isNaN(self.value)) {
        return rt_value("nan", "string");
      }
      if(!Number.isFinite(self.value)) {
        return rt_value(self.value>0 ? "inf" : "-inf", "string");
      }
      return rt_value(""+self.value, "string");
    }
  ),
  tonumber: rt_function(
    "tonumber", null,
    [],
    function(self) {
      return self;
    }
  )
});
const rt_proto_boolean = rt_object(rt_proto_object, {
  tostring: rt_function(
    "tostring", null,
    [], function(self) {
      return rt_value(self.value ? "true" : "false", "string");
    }
  )
});

class ReturnSignal extends SyntaxError {
  constructor(val = rt_nil) {
    super("return-statement ouside function body");
    this.value = val;
  }
}

const rt_h_break = new SyntaxError("break-statement outside loop");
const rt_h_continue = new SyntaxError("continue-statement outside loop");

const rt_rni = new Map([
  ["core.math/sqrt:1", (self, x) => {
    if(x.kind!=="number") return rt_nan;
    return rt_value(Math.sqrt(x.value), "number");
  }],
  ["core.math/exp:1", (self, x) => {
    if(x.kind!=="number") return rt_nan;
    return rt_value(Math.exp(x.value), "number");
  }],
  ["core.math/log:2", (self, base, x) => {
    if(base.kind!=="number" || x.kind!=="number") return rt_nanb
    if(base.value<=0 || base.value===1 || x.value<=0) return rt_nan;
    return rt_value(Math.log(x.value)/Math.log(base.value), "number");
  }],
  ["core.math/ln:1", (self, x) => {
    if(x.kind!=="number" || x.value<=0) return rt_nan;
    return rt_value(Math.log(x.value), "number");
  }],
  ["core.math/lb:1", (self, x) => {
    if(x.kind!=="number" || x.value<=0) return rt_nan;
    return rt_value(Math.log2(x.value), "number");
  }],
  ["core.math/lg:1", (self, x) => {
    if(x.kind!=="number" || x.value<=0) return rt_nan;
    return rt_value(Math.log10(x.value), "number");
  }],
  ["core.math/cos:1", (self, x) => {
    if(x.kind!=="number") return rt_nan;
    return rt_value(Math.cos(x.value), "number");
  }],
  ["core.math/sin:1", (self, x) => {
    if(x.kind!=="number") return rt_nan;
    return rt_value(Math.sin(x.value), "number");
  }],
  ["core.math/floor:1", (self, x) => {
    if(x.kind!=="number") return rt_nan;
    return rt_value(Math.floor(x.value), "number");
  }],
  ["core.math/ceil:1", (self, x) => {
    if(x.kind!=="number") return rt_nan;
    return rt_value(Math.ceil(x.value), "number");
  }],
  ["core.math/trunc:1", (self, x) => {
    if(x.kind!=="number") return rt_nan;
    return rt_value(Math.trunc(x.value), "number");
  }],
  ["core.random/rf:0", (self) => {
    return rt_value(Math.random(), "number");
  }],
  ["core.random/rf:1", (self, x) => {
    if(x.kind!=="number") return rt_nan;
    return rt_value(x.value*Math.random(), "number");
  }],
  ["core.random/ri:1", (self, x) => {
    if(x.kind!=="number") return rt_nan;
    return rt_value(Math.floor((x.value+1)*Math.random()), "number");
  }],
  ["core.random/ri:2", (self, min, max) => {
    if(min.kind!=="number" || max.kind!=="number") return rt_nan;
    return rt_value(Math.floor(min.value+(max.value-min.value+1)*Math.random()), "number");
  }],
]);

function evaluate_node(node, scope) {
  if(!node) return rt_nil;
  
  switch(node.kind) {
    case NodeKind.Native: {
      const nat = rt_rni.get(node.name);
      if(!nat) {
        throw new Error(`no native '${node.name}'`);
      }
      scope.declare(node.name, nat);
      return rt_nil;
    }
    case NodeKind.Export: {
      const stmt = node.stmt;
      switch(stmt.kind) {
        case NodeKind.FunctionDef: {
          evaluate_node(stmt, scope);
          scope.add_export(stmt.name, scope.get(stmt.name));
          break;
        }
        case NodeKind.VarDef: {
          for(const def of stmt.defs) {
            const init = evaluate_node(def.init, scope);
            scope.declare(def.name, init, node.is_const);
            scope.add_export(def.name, init);
          }
          break;
        }
      }
      return rt_nil;
    }
    case NodeKind.Import: {
      const m_name = node.path.join(".");
      if(node.path.length===1) {
        const cache = cache_import.get(node.path[0]);
        if(!cache) {
          throw new Error(`no module '${m_name}' found`);
        }
        for(const [name, val] of Object.entries(cache.properties)) {
          scope.declare(name, val);
        }
        return rt_nil;
      }
      
      let current = cache_import.get(node.path[0]);
      if(!current) {
        throw new Error(`no module '${m_name}' found`);
      }
      for(let i = 1; i<node.path.length; ++i) {
        current = current.properties[node.path[i]];
        if(!current) {
          throw new Error(`no module '${m_name}' found`);
        }
      }
      scope.declare(node.path.at(-1), current);
      return rt_nil;
    }
    case NodeKind.Package: {
      scope.root.package_name = node.path;
      return rt_nil;
    }
    
    case NodeKind.Program: {
      for(const stmt of node.body) {
        evaluate_node(stmt, scope);
      }
      return rt_nil;
    }
    case NodeKind.Lambda: {
      return rt_function("", scope, node.params, node.body);
    }
    case NodeKind.FunctionDef: {
      let body;
      if(node.is_native) {
        let m_name = scope.root.package_name.join(".");
        m_name += "/"+node.name+":"+node.params.length;
        if(!rt_rni.has(m_name)) {
          throw new Error(`can't resolve native method '${m_name}'`);
        }
        body = rt_rni.get(m_name);
      } else body = node.body;
      
      const org = scope.get(node.name, false);
      if(!org) {
        scope.declare(node.name, rt_function(
          node.name, scope,
          node.params, body
        ));
        return rt_nil;
      }
      if(!org._is_func) {
        throw new Error(`can't overload ${node.kind}'`);
      }
      if(org.signs[node.params.length]) {
        throw new Error(`redefinition of '${node.name}' with ${node.params.length} parameters`);
      }
      org.signs[node.params.length] = {
        params: node.params, body
      };
      ++org.signs.size;
      return rt_nil;
    }
    case NodeKind.Block: {
      for(const stmt of node.stmts) {
        evaluate_node(stmt, scope);
      }
      return rt_nil;
    }
    case NodeKind.ExprStmt: {
      evaluate_node(node.expr, scope);
      return rt_nil;
    }
    case NodeKind.VarDef: {
      for(const def of node.defs) {
        const init = evaluate_node(def.init, scope);
        scope.declare(def.name, init, node.is_const);
      }
      return rt_nil;
    }
    case NodeKind.VarAssign: {
      const right = evaluate_node(node.right, scope);
      if(node.op==="=") {
        if(node.left.kind===NodeKind.IndexExpr) {
          const obj = evaluate_node(node.left.object, scope);
          const prop = evaluate_node(node.left.property, scope);
          rt_index_set(obj, prop, right);
          return rt_nil;
        } else if(node.left.kind===NodeKind.MemberExpr) {
          const obj = evaluate_node(node.left.object, scope);
          rt_index_set(obj, node.left.property, right);
          return rt_nil;
        }
        scope.assign(node.left.name, right);
        return rt_nil;
      }
      const left = evaluate_node(node.left, scope);
      const val = rt_binop(left, right, node.op.slice(0, -1));
      if(node.left.kind===NodeKind.IndexExpr) {
        const obj = evaluate_node(node.left.object, scope);
        const prop = evaluate_node(node.left.property, scope);
        rt_index_set(obj, prop, val);
        return rt_nil;
      } else if(node.left.kind===NodeKind.MemberExpr) {
        const obj = evaluate_node(node.left.object, scope);
        rt_index_set(obj, node.left.property, val);
        return rt_nil;
      }
      scope.assign(node.left.name, val);
      return rt_nil;
    }
    case NodeKind.ForStmt: {
      const cycles = rt_tonumber(evaluate_node(node.cycles, scope));
      
      const counter = node.counter ?? false;
      const iota = node.iota ? rt_tonumber(evaluate_node(node.iota, scope)) : 0;
      const step = node.step ? rt_tonumber(evaluate_node(node.step, scope)) : 1;
      
      if(node.is_const) {
        for(let i = 0; i<cycles; ++i) {
          try {
            const lscope = new Scope(scope);
            if(counter) {
              lscope.declare(counter, rt_value(iota+i*step, "number"), true);
            }
            evaluate_node(node.body, lscope);
          } catch(e) {
            if(e===rt_h_break) break;
            if(e===rt_h_continue) continue;
            throw e;
          }
        }
        return rt_nil;
      }
      
      for(let i = iota; i<cycles; i += step) {
        try {
          const lscope = new Scope(scope);
          if(counter) {
            lscope.declare(counter, rt_value(i, "number"), true);
          }
          evaluate_node(node.body, lscope);
        } catch(e) {
          if(e===rt_h_break) break;
          if(e===rt_h_continue) continue;
          throw e;
        }
      }
      return rt_nil;
    }
    case NodeKind.IfStmt: {
      const cond = evaluate_node(node.condition, scope);
      if(rt_is_truthy(cond)) {
        evaluate_node(node.body, new Scope(scope));
      } else if(node.alt) {
        if(node.alt.kind===NodeKind.ElseStmt) {
          evaluate_node(node.alt.body, new Scope(scope));
        } else {
          evaluate_node(node.alt, scope);
        }
      }
      return rt_nil;
    }
    case NodeKind.WhileStmt: {
      let ft = node.run_first;
      while(true) {
        if(ft) ft = false;
        else {
          const cond = evaluate_node(node.condition, scope);
          if(!rt_is_truthy(cond)) break;
        }
        
        try {
          evaluate_node(node.body, new Scope(scope));
        } catch(e) {
          if(e===rt_h_break) break;
          if(e===rt_h_continue) continue;
          throw e;
        }
      }
      return rt_nil;
    }
    
    case NodeKind.Break: {
      throw rt_h_break;
    }
    case NodeKind.Continue: {
      throw rt_h_continue;
    }
    case NodeKind.Return: {
      if(!node.value) {
        throw new ReturnSignal();
      }
      const val = evaluate_node(node.value, scope);
      throw new ReturnSignal(val);
    }
    
    case NodeKind.ArrayExpr: {
      const idxs = node.items
        .map(a => evaluate_node(a, scope));
      return rt_array_obj(idxs);
    }
    case NodeKind.CallExpr: {
      const args = node.args.map(a => evaluate_node(a, scope));
      if(node.callee.kind===NodeKind.MemberExpr) {
        const obj = evaluate_node(node.callee.object, scope);
        const val = rt_index(obj, node.callee.property);
        return rt_invoke(val, obj, ...args);
      }
      const callee = evaluate_node(node.callee, scope);
      return rt_invoke(callee, rt_nil, ...args);
    }
    case NodeKind.New: {
      const args = node.args.map(a => evaluate_node(a, scope));
      const callee = evaluate_node(node.callee, scope);
      
      if(callee.kind!=="object" && !callee.signs) {
        rt_error(`${callee.kind} is not a constructor`);
      }
      const new_obj = rt_object(callee.properties.prototype);
      rt_invoke(callee, new_obj, ...args);
      return new_obj;
    }
    case NodeKind.IndexExpr: {
      const obj = evaluate_node(node.object, scope);
      const prop = evaluate_node(node.property, scope);
      return rt_index(obj, prop);
    }
    case NodeKind.MemberExpr: {
      const obj = evaluate_node(node.object, scope);
      return rt_index(obj, node.property);
    }
    case NodeKind.PathExpr:
    case NodeKind.MemberExpr: {
      const obj = evaluate_node(node.object, scope);
      return rt_index(obj, node.property);
    }
    case NodeKind.Ternary: {
      const cond = evaluate_node(node.cond, scope);
      if(rt_is_truthy(cond)) {
        return evaluate_node(node.a, scope);
      }
      return evaluate_node(node.b, scope);
    }
    case NodeKind.BinaryExpr: {
      const left = evaluate_node(node.left, scope);
      const right = evaluate_node(node.right, scope);
      return rt_binop(left, right, node.op);
    }
    case NodeKind.UnaryExpr: {
      const expr = evaluate_node(node.expr, scope);
      return rt_unop(expr, node.op);
    }
    case NodeKind.BoolLiteral: {
      return rt_value(node.value, "boolean");
    }
    case NodeKind.NaNLiteral: return rt_nan;
    case NodeKind.NilLiteral: return rt_nil;
    case NodeKind.NumberLiteral: {
      return rt_value(node.value, "number");
    }
    case NodeKind.StringLiteral: {
      return rt_value(node.value, "string");
    }
    case NodeKind.TemplateString: {
      let res = "";
      for(let i = 0; i<node.quasis.length; ++i) {
        res += node.quasis[i];
        if(i<node.exprs.length) {
          const expr = evaluate_node(node.exprs[i], scope);
          res += rt_tostring(expr);
        }
      }
      return rt_value(res, "string");
    }
    case NodeKind.Identifier: {
      return scope.get(node.name);
    }
    default: {
      console.log(node);
      throw new Error();
    }
  }
}

function raw_prompt() {
  Deno.stdin.setRaw(true);
  const buf = new Uint8Array(1024);
  let input = "";
  try {
    while(true) {
      const n = Deno.stdin.readSync(buf);
      if(n===null || n===0) break;
      const char = new TextDecoder().decode(buf.subarray(0, n));
      if(char==="\x03") {
        process.stdout.write("^C\n");
        Deno.exit(130);
      }
      if(char==="\x04") {
        process.stdout.write("^D\n");
        break;
      }
      if(char==="\r" || char==="\n") {
        process.stdout.write("\n");
        break;
      }
      if(char==="\x7f" || char==="\x08") {
        if(input.length>0) {
          input = input.slice(0, -1);
          process.stdout.write("\x08 \x08");
        }
        continue;
      }
  
      if(char.charCodeAt(0)<32 && char!=="\t") continue;
      input += char;
      process.stdout.write(char);
    }
  } finally {
    Deno.stdin.setRaw(false);
  }
  if(!input.length) return null;
  return input;
}

function rt_prettyprint(value) {
  if(value.kind==="object" && !value._is_func) {
    if(value.proto===rt_proto_array) {
      const len = rt_tonumber(value.properties.len);
      if(len===0) return "[]";
      let a = "";
      for(let i = 0; i<len;) {
        a += rt_prettyprint(value.properties[i] ?? rt_nil);
        if(++i<len) a += ", ";
      }
      return "["+a+"]";
    }
    const entries = Object.entries(value.properties);
    if(entries.length===0) return "{}";
    let a = "";
    for(const [key, prop] of entries) {
      a += `${key}: ${rt_prettyprint(prop)}\n`;
    }
    return "{\n"+a.slice(0, -1).replace(/^/gm, "  ")+"\n}";
  }
  
  let val = rt_tostring(value);
  
  switch(value.kind) {
    case "boolean":
    case "number":
    {
      return `\x1b[33m${val}\x1b[0m`;
    }
    case "string": {
      val = val.replaceAll("\\", "\x1b[35m\\\\\x1b[32m");
      val = val.replaceAll("`", "\x1b[35m\\\`\x1b[32m");
      val = val.replaceAll("\n", "\x1b[35m\\n\x1b[32m");
      val = val.replaceAll("\t", "\x1b[35m\\t\x1b[32m");
      val = val.replaceAll("\r", "\x1b[35m\\r\x1b[32m");
      return `\x1b[32m\`${val}\`\x1b[0m`;
    }
  }
  return `\x1b[31m${val}\x1b[0m`;
}

global_scope.declare("sys", rt_object(rt_proto_object, {
  out: rt_object(rt_proto_object, {
    rows: rt_function(
      "rows", null,
      [],
      function(self) {
        return rt_value(process.stdout.rows, "number");
      }
    ),
    cols: rt_function(
      "cols", null,
      [],
      function(self) {
        return rt_value(process.stdout.columns, "number");
      }
    )
  }),
  sleep: rt_function(
    "sleep", null,
    ["ms"], function(self, ms) {
      ms = rt_tonumber(ms);
      if(ms<0) {
        rt_error("can't sleep for negative milliseconds");
      }
      const sab = new SharedArrayBuffer(4);
      const int32 = new Int32Array(sab);
      Atomics.wait(int32, 0, 0, ms);
    }
  ),
  exit: rt_function(
    "exit", null, 
    [], function(self) {
      Deno.exit(0);
    },
    ["code"], function(self, code) {
      const val = rt_tonumber(code);
      Deno.exit(val);
    }
  ),
  writeln: rt_function(
    "writeln", null, 
    ["data"], function(self, data) {
      process.stdout.write(rt_tostring(data)+"\n");
    }
  ),
  write: rt_function(
    "write", null, 
    ["data"], function(self, data) {
      process.stdout.write(rt_tostring(data));
    }
  ),
  read: rt_function(
    "read", null, 
    [], function(self) {
      const out = raw_prompt();
      if(!out) return rt_nil;
      return rt_value(out, "string");
    }
  ),
  log: rt_function("log", null, 
    ["value"], function(self, value) {
      process.stdout.write(rt_prettyprint(value)+"\n");
    }
  )
}));

function cache_import_all(root) {
  const queue = [root];
  while(queue.length) {
    const dir = queue.pop();
    for(const node of Deno.readDirSync(dir)) {
      const final_path = path.join(dir, node.name);
      if(node.isDirectory) {
        queue.push(final_path);
        continue;
      }
      if(!node.isFile || !final_path.endsWith(".rp")) continue;
      
      const source = Deno.readTextFileSync(final_path);
      
      const scope = interpret_source(false, source, [], final_path);
      if (!scope.package_name || !scope.package_name.length) continue;
      
      const parts = scope.package_name;
      
      if(parts.length===1) {
        const module = rt_object(rt_nil, ...scope.exports);
        cache_import.set(parts[0], module);
        global_scope.declare(parts[0], module);
        continue;
      }
      
      const root_name = parts[0];
      let root_module = cache_import.get(root_name);
      if(!root_module) {
        root_module = rt_object(rt_nil);
        cache_import.set(root_name, root_module);
        global_scope.declare(root_name, root_module);
      }
      let current = root_module;
      for(let i = 1; i<parts.length-1; ++i) {
        const part = parts[i];
        let next_obj = current.properties[part]; 
        if (!next_obj) {
          next_obj = rt_object(rt_nil);
          current.properties[part] = next_obj;
        }
        current = next_obj;
      }
      
      const prop = current.properties[parts.at(-1)];
      
      if(!prop) {
        const module = rt_object(rt_nil);
        for(const [name, val] of scope.exports) {
          module.properties[name] = val;
        }
        current.properties[parts.at(-1)] = module;
        continue;
      }
      
      for(const [name, val] of scope.exports) {
        prop.properties[name] = val;
      }
    }
  }
}
cache_import_all(path.join(import.meta.dirname, "core"));
// cache_import_all(path.join(import.meta.dirname, ".."));

export function interpret_source(is_main, code, args, path) {
  try {
    const program = new Parser().parse(code);
    analyzeAST(program);
  
    const scope = new Scope();
  
    evaluate_node(program, scope);
    
    if(!is_main) return scope;
    
    const main = scope.get("main", false);
    if(!main || !main._is_func) {
      rt_error("can't find 'main' function");
    }
    if(main.signs.size!==1) {
      rt_error("'main' function must have one signature");
    }
    if(main.signs[0]) {
      rt_invoke(main, rt_nil);
    } else {
      args = rt_array_obj(args.map(a => rt_value(a, "string")));
      rt_invoke(main, rt_nil, args);
    }
    return scope;
  } catch(e) {
    console.log(`\x1b[1;31merror: ${e.message}\n  at ${path}\x1b[0m`);
    console.log(`\x1b[2;38;5;244m${e.stack.slice(e.name.length+e.message.length+3).replace(/^    /gm, "  ")}\x1b[0m`);
    Deno.exit(1);
  }
}